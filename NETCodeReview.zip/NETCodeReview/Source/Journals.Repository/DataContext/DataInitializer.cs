﻿namespace Journals.Repository.DataContext
{
    internal static class DataInitializer
    {
        internal static void Initialize(JournalsContext context)
        {
        }
    }
}