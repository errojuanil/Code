//JavaScriptsourcecode

var urlToFetchData = "https://discoverfinancial.sharepoint.com/sites/DevBTPrjArtfcts/_api/web/Lists/GetByTitle('Projects')/Items";
var urlToAuthenticate = "https://discoverfinancial.sharepoint.com/sites/DevBTPrjArtfcts";
function GetSAMLToken()
{
    var dfd = $.Deferred();

    var SoapReq = '<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing" xmlns:u="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">' +
                    '<s:Header>'+           
                        '<a:Action s:mustUnderstand="1">http://schemas.xmlsoap.org/ws/2005/02/trust/RST/Issue</a:Action>'+
                        '<a:ReplyTo>'+
                            '<a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>'+
                        '</a:ReplyTo>'+
                        '<a:To s:mustUnderstand="1">https://fedsvcs.discoverfinancial.com/adfs/ls/</a:To>'+
                        '<o:Security s:mustUnderstand="1" xmlns:o="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">' +
                            '<o:UsernameToken>'+
                                '<o:Username>maheshsherkar@discover.com</o:Username>'+
                                '<o:Password>Bitwise201505</o:Password>'+
                            '</o:UsernameToken>'+
                        '</o:Security>'+
                    '</s:Header>'+
                    '<s:Body>'+
                        '<t:RequestSecurityToken xmlns:t="http://schemas.xmlsoap.org/ws/2005/02/trust">'+
                            '<wsp:AppliesTo xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy"><a:EndpointReference>'+
                                '<a:Address>' + urlToAuthenticate + '</a:Address>' +
                                '</a:EndpointReference>'+
                            '</wsp:AppliesTo>'+
                            '<t:KeyType>http://schemas.xmlsoap.org/ws/2005/05/identity/NoProofKey</t:KeyType>'+
                            '<t:RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</t:RequestType>'+
                            '<t:TokenType>urn:oasis:names:tc:SAML:1.0:assertion</t:TokenType>'+
                        '</t:RequestSecurityToken>'+
                    '</s:Body>'+
                '</s:Envelope>';


    var url = 'https://fedsvcs.discoverfinancial.com/adfs/services/trust/2005/usernamemixed';

    var call = jQuery.ajax({
        type: 'POST',
        url: url,
        contentType: 'text/xml',
        dataType: 'xml',
        data: SoapReq,
        crossDomain: true

    });

    call.done(function (data, status, request)
    {
        var xmlText = new XMLSerializer().serializeToString(data);
        if (xmlText.indexOf('Authentication Failure') == -1) {
            var xmlData = $(xmlText, {});
            var secToken = xmlData.find('#Compact0').text();
            $('.xmlData').html(secToken);
            //alert('DOne');
            dfd.resolve(secToken);
        }
        else {
            xmlText = xmlText.replace(/<psf:/g, '<');
            var xmlData = $(xmlText, {});
            var errMsg = xmlData.find('text').text();
            alert(errMsg);
            dfd.reject();
        }
    }).fail(function (data, status, request) {
        dfd.reject();
        alert('fail.');
    });


    return dfd.promise();
}

function GetAccessToken(sToken) {
    var dfd = $.Deferred();

    var url = 'https://discoverfinancial.sharepoint.com/_forms/default.aspx?wa=wsignin1.0';

    var call = jQuery.ajax({
        type: 'POST',
        url: url,
        ContentType: 'text/html',
        dataType: 'html',
        data: sToken,
        crossDomain: true

    });

    call.done(function (data, status, request) {
        //var xmlText = new XMLSerializer().serializeToString(data);
        dfd.resolve();
    }).fail(function (data, status, request) {
        dfd.reject();
        alert('fail. GetAccessToken()')
    });


    return dfd.promise()
}

function GetRequestDigest() {
    var dfd = $.Deferred();



    var url = 'https://discoverfinancial.sharepoint.com/sites/DevBTPrjArtfcts/_api/contextinfo';

    var call = jQuery.ajax({
        type: 'POST',
        url: url,
        ContentType: 'text/xml',
        dataType: 'xml',
        crossDomain: true

    });

    call.done(function (data, status, request) {
        //var xmlText = new XMLSerializer().serializeToString(data);
        var xmlText = new XMLSerializer().serializeToString(data);
        xmlText = xmlText.replace(/<d:/g, '<');
        var xmlData = $(xmlText, {});
        var reqDigest = xmlData.find('formdigestvalue').text();
        //$('.xmlData').html(reqDigest);
        dfd.resolve(reqDigest);
    }).fail(function (data, status, request) {
        dfd.reject();
        alert('fail. GetRequestDigest()')
    });


    return dfd.promise()
}

function GetData() {
   
    var call = jQuery.ajax({

        url: urlToFetchData,

        headers: {
            'accept': 'application/json;odata=verbose'
        },
        type: 'GET',

        dataType: "json",
        crossDomain:true

    });

    call.done(function (data) {
       // alert("Data Fetched succesfully");
        if(data)
        {
            var html = "";
            for (var i = 0; i < data.d.results.length; i++) {
                html += "<tr><td>" + data.d.results[i].Title + "</td></tr>";
            }
            $("#MenuTable").append(html);
        }

    }).fail(function (jqxHR, textStatus, errorThrown) {
        alert("error=> " + textStatus);
    });

}

$(document).ready(function () {
    jQuery.support.cors = true;
    //GetData();
    GetSAMLToken().done(function(secToken){
    	GetAccessToken(secToken).done(function(){
    		GetRequestDigest().done(function(reqDigest){
    			GetData();
    		});
    	});
    });
});
