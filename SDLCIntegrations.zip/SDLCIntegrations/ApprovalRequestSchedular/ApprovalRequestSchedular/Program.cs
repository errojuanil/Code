﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.SharePoint.Client;
using System.Globalization;

namespace ApprovalRequestSchedular
{
    class Program
    {

        static ConfigData configData = new ConfigData();
         
        static void Main(string[] args)
        {
            try
            {
                #region Initialization
                LogHelper.sb = new StringBuilder();
               
                List<RequestRecord> RequestDataSource = new List<RequestRecord>();

                #endregion Initialization

                Console.WriteLine("-Scheduler Started: ");         
          

                ConfigHelper config = ConfigHelper.ParseConfigXML();
                initializeConfiguration(config.configParams);
                checkConfiguration();


                O365AuthHelper O365Auth = new O365AuthHelper(configData.siteUrl, configData.userName, configData.Password);
                SharePointOnlineCredentials onlineCredentials = O365Auth.getOnlineCredentials();
                var targetSite = new Uri(configData.siteUrl);
                #region Get Data From Approval Request
                using (ClientContext clientContext = new ClientContext(targetSite))
               {
                   try
                   {
                    DateTime LastTimeStampSchedulerExecuted = DateTime.Today;
                    CamlQuery camlQuery = new CamlQuery();
                    List ApprovalRequestList = null;
                    if (!(configData.LastTimastamp != null && configData.LastTimastamp != ""))
                    {
                        //LastTimeStampSchedulerExecuted = new DateTime(LastTimeStampSchedulerExecuted.Year, LastTimeStampSchedulerExecuted.Month, LastTimeStampSchedulerExecuted.Day, 0, 0, 0);
                        configData.LastTimastamp = LastTimeStampSchedulerExecuted.ToString();
                    }
                    

                    clientContext.Credentials = onlineCredentials;
                    ApprovalRequestList = clientContext.Web.Lists.GetByTitle(Constants.APPROVAL_REQUEST_LIST_NAME);               
                    
                    camlQuery.ViewXml = "<View>" +
                    "<Query>" +
                    "<Where>" +
                     "<And>" +
                            "<And>" +                               
                                "<Eq><FieldRef Name='IsDeleted' /><Value Type='Boolean'>0</Value></Eq>" +                            
                                "<And>" +
                                "<Geq><FieldRef Name='Modified' /><Value Type='DateTime' IncludeTimeValue='TRUE'>" + configData.LastTimastamp + "</Value></Geq>" +
                                "<Leq><FieldRef Name='Modified' /><Value Type='DateTime' IncludeTimeValue='TRUE'>" + configData.toDate + "</Value></Leq>" +
                                "</And>" +
                            "</And>" +

                            "<IsNotNull><FieldRef Name='ProjectNo' /></IsNotNull>" +
                    "</And>" +
                    "</Where>" +
                    "</Query>" +
                    "</View>";

                    

                   
                        ListItemCollection RequestCollection = ApprovalRequestList.GetItems(camlQuery);
                        clientContext.Load<ListItemCollection>(RequestCollection, items => items.Include(item => item.Id,
                            item => item["Status"],
                            item => item["IdeaNo"],
                            item => item["ProjectNo"],
                            item => item["Modified"]));//
                        clientContext.ExecuteQuery();

                        int i = 0;
                        foreach (ListItem item in RequestCollection)
                        {
                            
                            try
                            {
                                FieldLookupValue projId = null;
                                string ModifiedDate = "";
                                if (item["ProjectNo"] != null)
                                    projId = item["ProjectNo"] as FieldLookupValue;
                                else
                                    projId = item["IdeaNo"] as FieldLookupValue;


                              
                                ModifiedDate = Convert.ToDateTime(item["Modified"], CultureInfo.InvariantCulture).ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss");
                           
                                RequestDataSource.Add(new RequestRecord(projId.LookupValue, item.Id.ToString(), item["Status"].ToString(), ModifiedDate));
                                i++;
                            }
                            catch (Exception ex)
                            {
                                AddExceptionEmail(clientContext, ex.Message, ex.StackTrace);
                            }

                        }
                        Console.WriteLine("-Fetching Request data done");
                     


                        if (RequestDataSource != null && RequestDataSource.Count != 0)
                        {
                            try
                            {
                                XMLHelper.SaveFile(RequestDataSource,configData.outputfileLocation);
                                Console.WriteLine("- Ouput File Saved.");
                             
                            }
                            catch (Exception ex)
                            {

                                throw;
                            }
                            
                             
                        }
                        else
                        {
                            Console.WriteLine("-No Records found matching the criteria");                            

                        }
                        Console.WriteLine("-Number Of Records Exported: " + i);
                      
                        ConfigHelper.updateLastDateTimeStamp("LastTimeSchedulerExecuted", Constants.CONFIG_XML_PATH);
                    }
                    catch (Exception ex)
                    {
                        AddExceptionEmail(clientContext, ex.Message, ex.StackTrace);

                    }
               }
                #endregion
            }
            catch (Exception ex)
            {
                Console.WriteLine("-Exception: " + ex.Message);
                LogHelper.sb.AppendLine("-Exception: " + ex.Message);
                
            }
            finally
            {              
                LogHelper.CreateAndWriteToFile(configData.logFilePath);
               
            }
        }

        /// <summary>
        /// Read Password entered by user and store it in a string variable
        /// </summary>
        /// <returns>Password in String</returns>
        private static string ReadPassword()
        {
            string pwd = string.Empty;
            ConsoleKeyInfo keyInfo = new ConsoleKeyInfo();
            while (keyInfo.Key != ConsoleKey.Enter)
            {

                keyInfo = Console.ReadKey(true);
                if (keyInfo.Key != ConsoleKey.Enter)
                    pwd += keyInfo.KeyChar.ToString();
            }
            return pwd;
        }
        /// <summary>
        /// Initialize parameters to the values from Config file
        /// </summary>
        /// <param name="configParams"></param>
        private static void initializeConfiguration(Dictionary<string, string> configParams)
        {
            string siteUrl = configParams.Where(x => x.Key == "siteUrl").FirstOrDefault().Value;
            configData.siteUrl = configParams.Where(x => x.Key == "siteUrl").FirstOrDefault().Value;
            configData.userName = configParams.Where(x => x.Key == "userName").FirstOrDefault().Value;
            configData.Password = SecureTextHelper.Decrypt(configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value);
            configData.LastTimastamp = configParams.Where(x => x.Key == "LastTimeSchedulerExecuted").FirstOrDefault().Value;
            configData.logFilePath = configParams.Where(x => x.Key == "logFilePath").FirstOrDefault().Value;
            configData.errorAdmins = configParams.Where(x => x.Key == "ErrorAdmins").FirstOrDefault().Value;
            configData.emailsListName = configParams.Where(x => x.Key == "EmailsListName").FirstOrDefault().Value;
            configData.outputfileLocation = configParams.Where(x => x.Key == "OutputFileLocation").FirstOrDefault().Value;
            configData.toDate = configParams.Where(x => x.Key == "ToDate").FirstOrDefault().Value; 
            if(String.IsNullOrEmpty(configData.toDate) || configData.toDate=="#")
            {
                configData.toDate = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ");
            }
        }
        /// <summary>
        /// Check Configuration and prompt user if anything is blank
        /// </summary>
        private static void checkConfiguration()
        {
           
            Console.WriteLine("-Checking Configuration...");
         
            if (ConfigHelper.isConfigured(configData))
            {
                Console.WriteLine("Already Configured. Moving On...");
        
            }
            else
            {
                Console.WriteLine("App not configured. Please specify below details to configure App.");
         
                XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
                foreach (KeyValuePair<string, string> configString in ConfigHelper.UnConfiguredStrings)
                {

                    if (configString.Key != "LastTimastamp")
                    {
                    Console.WriteLine("Enter " + configString.Key + ": ");
                    XElement configElement = xDoc.Descendants("param").Where(x => x.Attribute("key").Value == configString.Value).FirstOrDefault();
                    
                        if (configString.Key == "Password")
                        {
                            string pwd = ReadPassword();
                            configElement.SetAttributeValue("value", SecureTextHelper.Encrypt(pwd));
                            configData.Password = pwd;
                        }
                        else
                        {
                            string val = Console.ReadLine();
                            configElement.SetAttributeValue("value", val);
                            configData.GetType().GetProperty(configString.Key).SetValue(configData, val, null);
                        } 
                    }
                }
                xDoc.Save(Constants.CONFIG_XML_PATH);
                Console.WriteLine("Configuration Done!!");
          
            }
         
        }

        /// <summary>
        /// Add Emails log to EmailLogs list in SharePoint. The EmailLogs list has a workflow which sends email to the person mentioned in "To" field.
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="web"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        private static void AddExceptionEmail(ClientContext clientContext, string subject, string body)
        {
            try
            {
                Web web = clientContext.Web;
                List emailsLog = web.Lists.GetByTitle(configData.emailsListName);
                ListItemCreationInformation itemInfo = new ListItemCreationInformation();
                string[] arrAdmin = configData.errorAdmins.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

                if (arrAdmin.Length > 0)
                {
                    foreach (string admin in arrAdmin)
                    {
                        User user = web.SiteUsers.GetByEmail(admin);
                        clientContext.Load(user);
                        clientContext.ExecuteQuery();
                        ListItem newItem = emailsLog.AddItem(itemInfo);
                        newItem["To"] = user.Id;
                        newItem["Body"] = body;
                        newItem["Title"] = subject;
                        newItem.Update();
                    }
                    clientContext.ExecuteQuery();
                }
            }
            catch (Exception ex)
            {
                LogHelper.sb.AppendLine("Error Message: " + ex.Message + "\nError Stack Trace" + ex.StackTrace);
            }


        }      



    }
    class RequestRecord
    {

        public string prj_id { get; set; }
        public string req_id { get; set; }
        public string status { get; set; }
        public string approval_date { get; set; }
        public RequestRecord(string Prj_id, string Req_id, string Status, string Approval_date)
        {
            prj_id = Prj_id;
            req_id = Req_id;
            status = Status;
            approval_date = Approval_date;
        }

    }
}