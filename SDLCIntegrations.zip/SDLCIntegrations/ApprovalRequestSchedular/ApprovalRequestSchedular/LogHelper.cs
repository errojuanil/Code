﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApprovalRequestSchedular
{
    class LogHelper
    {
        public static StringBuilder sb { get; set; }
        
        /// <summary>
        /// Creates file and write data into the file
        /// </summary>
        /// <param name="logFilePath"></param>
        public static void CreateAndWriteToFile(string logFilePath)
        {
            string path = logFilePath + "Logs.txt";
            if (!String.IsNullOrEmpty(sb.ToString()))
            {
                File.AppendAllText(path, "[" + DateTime.Now.ToLongTimeString() + "]" + sb.ToString());
            }
        }
    }
}
