﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.IO;

namespace ApprovalRequestSchedular
{
    class XMLHelper
    {
        public static void SaveFile(List<RequestRecord> RequestDataSource,string outputFileLocation)
        {
            if (RequestDataSource.Count > 0)
            {
                string Filepath = outputFileLocation + Constants.CSV_OUTPUT_FILENAME_PREFIX + DateTime.Now.ToString("MMddyyyy") + "." + Constants.CSV_FILE_EXTENTION;
                string delemiter = ",";
                StringBuilder filecontentStrBuilder = new StringBuilder();
                if (!File.Exists(Filepath))
                {
                    try
                    {

                        File.Create(Filepath).Close();
                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine("-Exception while File creation: " + ex.Message);
                        throw;
                    }
                }
                else
                {
                    File.WriteAllText(Filepath, String.Empty);
                }
                foreach (RequestRecord record in RequestDataSource)
                {
                    string RecordArr = record.prj_id + delemiter + record.req_id + delemiter + record.status + delemiter + record.approval_date;
                    filecontentStrBuilder.AppendLine(RecordArr);                                        
                }
                try
                {
                    Console.WriteLine("-Creating CSV output file...");                   
                    File.AppendAllText(Filepath, filecontentStrBuilder.ToString());
                    
                }
                catch (Exception ex)
                {
                     Console.WriteLine("-Exception while Saving File: "+ex.Message);
                     LogHelper.sb.AppendLine("-Exception while Saving File: " + ex.Message);
                     throw;
                }

            }
        }


    }
}
