﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Xml.Linq;
using System.Reflection;

namespace ApprovalRequestSchedular
{
    class ConfigHelper
    {
        public Dictionary<string, string> configParams { get; set; }
        public static Dictionary<string, string> UnConfiguredStrings { get; private set; }

        /// <summary>
        /// Parse config file parameters
        /// </summary>
        /// <returns></returns>
        public static ConfigHelper ParseConfigXML()
        {
            Console.WriteLine("-Loading Config XML from path " + Constants.CONFIG_XML_PATH);

            XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
            Console.WriteLine("-Config XML loaded Sucessfully!!");


            ConfigHelper config = new ConfigHelper();

            Console.WriteLine("-Getting Config parameters..");

            config.configParams = getConfigParams(xDoc);
            Console.WriteLine("-Getting Config parameters Done.");

            return config;
        }
       
        public static Dictionary<string, string> getConfigParams(XDocument xDoc)
        {
            Dictionary<string, string> configParams = (from p in xDoc.Descendants("param")
                                                       select new KeyValuePair<string, string>
                                                           (p.Attribute("key").Value,
                                                             p.Attribute("value").Value
                                                           ))
                    .ToDictionary(x => x.Key, x => x.Value);
            return configParams;
        }
        public static void updateLastDateTimeStamp(string datetimeStampNode, string path)
        {
            //LogHelper.sb.AppendLine("-Entering Method updateLastDateTimeStamp()");
            string datetimeStamp = File.GetLastWriteTime(path).ToString(Constants.CSV_APPROVAL_DATE_FORMAT);
            XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
            XElement configElement = xDoc.Descendants("param").Where(x => x.Attribute("key").Value == datetimeStampNode).FirstOrDefault();
            configElement.SetAttributeValue("value", datetimeStamp);
            xDoc.Save(Constants.CONFIG_XML_PATH);
            // LogHelper.sb.AppendLine("-Leaving Method updateLastDateTimeStamp()");
        }

        public static bool isConfigured(ConfigData configData)
        {
            var _isConfigured = true;
            //Console.Write(AppDomain.CurrentDomain.BaseDirectory + "XMLs\\Config.xml");
            PropertyInfo[] configProperties = configData.GetType().GetProperties();
            UnConfiguredStrings = new Dictionary<string, string>();
            foreach (PropertyInfo configProperty in configProperties)
            {
                KeyValuePair<string, string> param = new KeyValuePair<string, string>(configProperty.Name, configProperty.GetValue(configData, null).ToString());


                if (string.IsNullOrEmpty(param.Value) && param.Key != "Password" && param.Key != "LastTimeSchedulerExecuted")
                    {
                        _isConfigured = false;
                        UnConfiguredStrings.Add(param.Key, param.Key);
                    }
                    else if (param.Key == "Password")
                    {
                        if (string.IsNullOrEmpty(param.Value))
                        {
                            _isConfigured = false;
                            UnConfiguredStrings.Add("Password", "pwd");
                        }
                    }                   
                
            }

            return _isConfigured;
        }
    }
    public class ConfigData
    {
        public string siteUrl { get; set; }
        public string userName { get; set; }
        public string Password { get; set; }
        public string LastTimastamp { get; set; }
        public string logFilePath { get; set; }
        public string errorAdmins { get; set; }
        public string emailsListName { get; set; }
        public string outputfileLocation { get; set; }
        public string toDate { get; set; }
    }
}
