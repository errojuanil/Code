﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ApprovalRequestSchedular
{
    class Constants
    {
        public static string APPROVAL_REQUEST_LIST_NAME = "Approval Requests";
        public static string CSV_OUTPUT_FILE_LOCATION = AppDomain.CurrentDomain.BaseDirectory + "Data\\";
        public static string CSV_OUTPUT_FILENAME_PREFIX = "sp_approval_requests_";
        public static string CSV_APPROVAL_DATE_FORMAT = "yyyy-MM-ddThh:mm:ss";
        public static string CSV_FILE_EXTENTION = "txt";

        public static string CONFIG_XML_PATH = AppDomain.CurrentDomain.BaseDirectory + "XMLs\\Config.xml";
        public const string DATE_TIME_STANDARD_FORMAT = "MM/dd/yyyy hh:mm:ss tt";
        public const string DATE_STANDARD_FORMAT = "MM/dd/yyyy";
        public const string TIME_STANDARD_FORMAT = "hh:mm:ss tt";
    }
}
