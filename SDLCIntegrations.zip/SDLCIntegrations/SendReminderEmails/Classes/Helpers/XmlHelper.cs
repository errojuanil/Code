﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClarityDataImporter.Classes.Helpers
{
    public class XmlHelper
    {
        public static List<spDataItem> getData(ClientContext clientContext,string path, string xmlNode, List<spDataColumn> mappedColumns,string lastUpdated)
        {
            List<spDataItem> data = new List<spDataItem>();
            try
            {
                if (System.IO.File.Exists(path))
                {
                    DateTime lastUpdateDate = new DateTime();
                    if (!string.IsNullOrEmpty(lastUpdated))
                        lastUpdateDate = DateTime.ParseExact(lastUpdated, Classes.Constants.DATE_TIME_STANDARD_FORMAT, CultureInfo.CurrentCulture);
                    if (lastUpdateDate < System.IO.File.GetLastWriteTime(path) || string.IsNullOrEmpty(lastUpdated))
                    {
                        XDocument xDoc = XDocument.Load(path);
                        if (xDoc != null)
                        {
                            data = xDoc.Descendants(xmlNode).Select(c => new spDataItem()
                            {
                                columns = GetAllColumnsValue(c, mappedColumns)
                            }).ToList();
                        }
                        else
                            EmailHelper.sendNotification(clientContext,  Constants.CANNOT_READ_TITLE, string.Format(Constants.CANNNOT_READ_MESSAGE,path));
                    }
                    else
                        EmailHelper.sendNotification(clientContext, Constants.FILE_NOT_UPDATED_TITLE, string.Format(Constants.FILE_NOT_UPDATED_MESSAGE,path,lastUpdated));
                }
                else
                    EmailHelper.sendNotification(clientContext, Constants.FILE_NOT_FOUND_TITLE, string.Format(Constants.FILE_NOT_FOUND_MESSAGE,path));
            }
            catch (Exception ex)
            {
                EmailHelper.sendNotification(clientContext, Constants.SYSTEM_EX_READ_TITLE,string.Format(Constants.SYSTEM_EX_READ_MESSAGE,path,ex.Message));
            }

            return data;
            
        }

        private static List<spDataColumn> GetAllColumnsValue(XElement c, List<spDataColumn> mappedColumns)
        {

            return mappedColumns.Select(x => new spDataColumn()
            {
                Name = x.Name,
                InternalName = x.InternalName,
                Type = x.Type,
                SrcXmlNode = x.SrcXmlNode,
                value = c.Descendants(x.SrcXmlNode).FirstOrDefault().Value
            }).ToList();
        }

        public static Dictionary<string,string> getConfigParams(XDocument xDoc){
            Dictionary<string,string> configParams= (from p in xDoc.Descendants("param")
                    select new KeyValuePair<string, string>
                        (p.Attribute("key").Value,
                          p.Attribute("value").Value
                        ))
                    .ToDictionary(x => x.Key, x => x.Value);
           

            return configParams;
        }

        public static ConfigHelper ParseConfigXML()
        {
            Console.WriteLine("Loading Config XML from path " + Constants.CONFIG_XML_PATH);
            //LogHelper.sb.sb.AppendLine("Loading Config XML from path " + Constants.CONFIG_XML_PATH);
            XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
            Console.WriteLine("Config XML loaded Sucessfully!!");
            //LogHelper.sb.sb.AppendLine("Config XML loaded Sucessfully!!");

            ConfigHelper config = new ConfigHelper();

            Console.WriteLine("Getting Config parameters..");
            //LogHelper.sb.sb.AppendLine("Getting Config parameters..");
            config.configParams = getConfigParams(xDoc);
            Console.WriteLine("Getting Config parameters Done.");
            //LogHelper.sb.sb.AppendLine("Getting Config parameters Done.");

            //config.IdeaColumns = getColumns(xDoc,"IdeaColumns");
            //config.ProjectColumns = getColumns(xDoc, "ProjectColumns");

            return config;
        }

        private static List<spDataColumn> getColumns(XDocument xDoc, string nodeName)
        {
            return (from ct in xDoc.Descendants(nodeName).FirstOrDefault().Descendants("Column")
                    select new spDataColumn
                    {
                        Name = ct.Attribute("Name") != null ? ct.Attribute("Name").Value != null ? ct.Attribute("Name").Value : string.Empty : string.Empty,
                        InternalName = ct.Attribute("InternalName") != null ? ct.Attribute("InternalName").Value != null ? ct.Attribute("InternalName").Value : string.Empty : string.Empty,
                        Type = ct.Attribute("Type") != null ? ct.Attribute("Type").Value != null ? ct.Attribute("Type").Value : string.Empty : string.Empty,
                        SrcXmlNode = ct.Attribute("SrcXmlNode") != null ? ct.Attribute("SrcXmlNode").Value != null ? ct.Attribute("SrcXmlNode").Value : string.Empty : string.Empty
                    }).ToList();
        }
    }
}
