﻿using ClarityDataImporter.Classes;
using ClarityDataImporter.Classes.Helpers;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SendReminderEmails
{
    class Program
    {
        static string _siteUrl = string.Empty;
        static string _userName = string.Empty;
        static string _password = string.Empty;
        static string _emailsListName = string.Empty;
        static string _emailTemplateListName = string.Empty;
        static string _reminderTemplateName = string.Empty;
        static string _reminderTemplateNamePast = string.Empty;
        static string _approvaltaskListName = string.Empty;
        static string _approvalrequestListName = string.Empty;
        static string _docTypeListName = string.Empty;
        static string _adminEmailIds = string.Empty;
        static string _errorAdmins = string.Empty;
        static string _logFilePath = string.Empty;

        static void Main(string[] args)
        {

            checkConfiguration();
                ConfigHelper config = XmlHelper.ParseConfigXML();
                initializeConfiguration(config.configParams);
                O365AuthHelper O365Auth = new O365AuthHelper(_siteUrl, _userName, _password);                
                var targetSite = new Uri(_siteUrl);
                using (ClientContext clientContext = new ClientContext(targetSite))
                {
                    try
                    {
                        SharePointOnlineCredentials onlineCredentials = O365Auth.getOnlineCredentials();
                        clientContext.Credentials = onlineCredentials;
                        ListItemCollection requestsDue = GetRequestsForDueDate(clientContext);
                        ListItemCollection requestsPast = GetRequestsForPastDate(clientContext);
                        ListItem emailTemplateDue = GetEmailTemplate(clientContext,_reminderTemplateName);
                        ListItem emailTemplatePast = GetEmailTemplate(clientContext, _reminderTemplateNamePast);
                        GetTasksDetails(clientContext, requestsDue, emailTemplateDue);
                        GetTasksDetails(clientContext, requestsPast, emailTemplatePast);
                    }
                    catch (Exception ex)
                    {
                        AddExceptionEmail(clientContext, "Error Occured - Clarity data to SharePoint :" + ex.Message, ex.StackTrace);
                    }
                }
                //Console.ReadKey();
            

        }
        /// <summary>
        /// Check Configuration and prompt user if anything is blank
        /// </summary>
        private static void checkConfiguration()
        {
            if (ConfigHelper.IsConfigured)
            {
                Console.WriteLine("Already Configured. Moving On...");
            }
            else
            {
                Console.WriteLine("App not configured. Please specify below details to configure App.");
                //LogHelper.sb.AppendLine("App not configured. Getting Configuration Details");
                XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
                foreach (KeyValuePair<string, string> configString in ConfigHelper.UnConfiguredStrings)
                {
                    Console.WriteLine("Enter " + configString.Key + ": ");
                    XElement configElement = xDoc.Descendants("param").Where(x => x.Attribute("key").Value == configString.Value).FirstOrDefault();
                    if (configString.Key == "Password")
                        configElement.SetAttributeValue("value", SecureTextHelper.Encrypt(ReadPassword()));
                    else
                        configElement.SetAttributeValue("value", Console.ReadLine());
                }
                xDoc.Save(Constants.CONFIG_XML_PATH);
                Console.WriteLine("Configuration Done!!");
                //LogHelper.sb.AppendLine("Configuration Done!!");
            }
        }

        /// <summary>
        /// Read Password entered by user and store it in a string variable
        /// </summary>
        /// <returns>Password in String</returns>
        private static string ReadPassword()
        {
            string pwd = string.Empty;
            ConsoleKeyInfo keyInfo = new ConsoleKeyInfo();
            while (keyInfo.Key != ConsoleKey.Enter)
            {

                keyInfo = Console.ReadKey(true);
                if (keyInfo.Key != ConsoleKey.Enter)
                    pwd += keyInfo.KeyChar.ToString();
            }
            return pwd;
        }

        /// <summary>
        /// Get all Requests which are less than 2 days from the current date and are not deleted requests and Status = In Review
        /// </summary>
        /// <param name="clientContext"></param>
        /// <returns></returns>
        private static ListItemCollection GetRequestsForDueDate(ClientContext clientContext)
        {
            ListItemCollection listItems = null;
            try
            {
                var list = clientContext.Web.Lists.GetByTitle(_approvalrequestListName);
                //var list = clientContext.Web.Lists.GetByTitle("ApprovalHHH");
                CamlQuery query = new CamlQuery();
                string dueDate = DateTime.Today.AddDays(2).ToString("yyyy-MM-ddTHH:mm:ssZ");
                query.ViewXml = string.Format("<View><Query><Where><And><Eq><FieldRef Name='Status'/>" +
                                                "<Value Type='Choice'>In Review</Value></Eq>" +
                                                "<And><Eq><FieldRef Name='IsDeleted' /><Value Type='Boolean'>0</Value></Eq>" +
                                                "<And><Leq><FieldRef Name='DueDate' /><Value Type='DateTime'>" + dueDate + "</Value></Leq>" +
                                                "<Geq><FieldRef Name='DueDate' /><Value Type='DateTime'>" + DateTime.Today.ToString("yyyy-MM-ddTHH:mm:ssZ") + "</Value></Geq>" +                                                
                                                "</And></And></And></Where></Query></View>");
                listItems = list.GetItems(query);
                clientContext.Load(listItems);
                clientContext.ExecuteQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listItems;
        }
        /// <summary>
        /// Get all requests which has past due date and are not deleted requests and Status = In Review
        /// </summary>
        /// <param name="clientContext"></param>
        /// <returns></returns>
        private static ListItemCollection GetRequestsForPastDate(ClientContext clientContext)
        {
            ListItemCollection listItems = null;
            try
            {
                var list = clientContext.Web.Lists.GetByTitle(_approvalrequestListName);
                //var list = clientContext.Web.Lists.GetByTitle("ApprovalHHH");
                CamlQuery query = new CamlQuery();              
                query.ViewXml = string.Format("<View><Query><Where><And><Eq><FieldRef Name='Status'/>" +
                                                "<Value Type='Choice'>In Review</Value></Eq>" +
                                                "<And><Lt><FieldRef Name='DueDate' /><Value Type='DateTime'>" + DateTime.Today.ToString("yyyy-MM-ddTHH:mm:ssZ") + "</Value></Lt>" +                                               
                                                "<Eq><FieldRef Name='IsDeleted' /><Value Type='Boolean'>0</Value></Eq>" +
                                                "</And></And></Where></Query></View>");
                listItems = list.GetItems(query);
                clientContext.Load(listItems);
                clientContext.ExecuteQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listItems;
        }

        /// <summary>
        /// Get Email templates from Email Templates list
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="templateName"></param>
        /// <returns></returns>
        private static ListItem GetEmailTemplate(ClientContext clientContext,string templateName)
        {
            var list = clientContext.Web.Lists.GetByTitle(_emailTemplateListName);
            CamlQuery query = new CamlQuery();            
            query.ViewXml = string.Format("<View><Query><Where><Eq><FieldRef Name='Title'/>" +
                                            "<Value Type='Text'>" + templateName + "</Value></Eq>" +                                           
                                            "</Where></Query></View>");
            ListItemCollection listItems = list.GetItems(query);
            clientContext.Load(listItems);
            clientContext.ExecuteQuery();
            if (listItems.Count == 0)
                return null;
            else
                return listItems.FirstOrDefault();
        }
        /// <summary>
        /// Get Task data related to Request from SharePoint list 
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="requests"></param>
        /// <param name="emailTemplate"></param>
        private static void GetTasksDetails(ClientContext clientContext, ListItemCollection requests,ListItem emailTemplate)
        {
            var list = clientContext.Web.Lists.GetByTitle(_approvaltaskListName);
           
            
            
            CamlQuery query = new CamlQuery();
            foreach (ListItem request in requests)
            {
                query.ViewXml = string.Format("<View><Query><Where><And><And><Eq><FieldRef Name='RequestNumber' LookupId='TRUE' /><Value Type='Lookup'>" + request["ID"] + "</Value></Eq>" +
                                           "<Eq><FieldRef Name='Status'/>" +
                                           "<Value Type='Choice'>In Review</Value></Eq></And>" +
                                           "<Eq><FieldRef Name='IsDraft'/><Value Type='Boolean'>0</Value></Eq>" +
                                           "</And></Where></Query></View>");
                ListItemCollection listItems = list.GetItems(query);
                clientContext.Load(listItems);
                clientContext.ExecuteQuery();
                foreach (ListItem listItem in listItems)
                {
                    if (listItems.Count != 0)
                        AddEmailAlert(clientContext, request, listItem, emailTemplate);
                }
            }
            clientContext.ExecuteQuery();
        }

        /// <summary>
        /// Get Document Type from Document Type ID. 
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="requests"></param>
        /// <param name="emailTemplate"></param>
        private static string GetDocTypeById(ClientContext clientContext, int DocTypeId)
        {
            var list = clientContext.Web.Lists.GetByTitle(_docTypeListName);

            CamlQuery query = new CamlQuery();

            query.ViewXml = string.Format("<View><Query><Where><Eq><FieldRef Name='ID'/>" +
                                           "<Value Type='Counter'>" + DocTypeId + "</Value></Eq>" +
                                           "</Where></Query></View>");
            ListItemCollection listItems = list.GetItems(query);
            clientContext.Load(listItems);
            clientContext.ExecuteQuery();

            var docType = string.Empty;
            if (listItems.Count!=0)
                docType=listItems[0]["Title"].ToString();

            return docType;
        }

        /// <summary>
        /// Create Email message for approvers
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="request"></param>
        /// <param name="taskDetails"></param>
        /// <param name="emailTemplate"></param>
        private static void AddEmailAlert(ClientContext clientContext, ListItem request, ListItem taskDetails, ListItem emailTemplate)
        {
            List emailList = clientContext.Web.Lists.GetByTitle(_emailsListName);
            ListItemCreationInformation itemInfo = new ListItemCreationInformation();
            ListItem email = emailList.AddItem(itemInfo);

            string clarityNo = String.Empty;
            string clarityName = String.Empty;


            if (request["ProjectNo"] != null)
            {
                clarityNo = ((FieldLookupValue)(request["ProjectNo"])).LookupValue;
                clarityName = ((FieldLookupValue)(request["ProjectNo_x003a_Project_x0020_Na"])).LookupValue;
            }
            else
            {
                clarityNo = ((FieldLookupValue)(request["IdeaNo"])).LookupValue;
                clarityName = ((FieldLookupValue)(request["IdeaNo_x003a_Idea_x0020_Name"])).LookupValue;
            }

            string initiatorName = ((FieldLookupValue)(request["Initiator"])).LookupValue;
            string requestID = "<a href='/URL/SitePages/ApprovalRequest.aspx?RequestID=" + Convert.ToString(request["ID"]) + "'>" + Convert.ToString(request["ID"]) + "</a>";
            string approvalDate = Convert.ToDateTime(request["DueDate"]).ToShortDateString();

            string DocType = GetDocTypeById(clientContext, Convert.ToInt32(request["DocTypeID"]));

            string subject = Convert.ToString(emailTemplate["Subject"]).Replace("$$ClarityNO$$", clarityNo).Replace("$$ApprovalDueDate$$", approvalDate);
            email["Title"] = subject.Replace("$$DocumentType$$", DocType);
            email["To"] = ((Microsoft.SharePoint.Client.FieldLookupValue)(taskDetails["ApproverName"])).LookupId;
            email["Body"] = Convert.ToString(emailTemplate["Body"]).Replace("$$RequestID$$", Convert.ToString(request["ID"])).Replace("$$ClarityNO$$", clarityNo).Replace("$$ClarityName$$", clarityName).Replace("$$CreatedBy$$", initiatorName).Replace("$$ApprovalDueDate$$", approvalDate).Replace("$$ID$$", requestID).Replace("$$DocumentType$$",DocType);
            
            email.Update();
        }

      
        /// <summary>
        /// get User ID by passing user's login name
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        private static int GetUserId(ClientContext clientContext, string userName)
        {
            var web = clientContext.Web;
            var theUser = web.EnsureUser(userName);
            clientContext.Load(theUser);
            clientContext.ExecuteQuery();

            return theUser.Id;
        }


        /// <summary>
        /// Initialize configuration
        /// </summary>
        /// <param name="configParams"></param>
        private static void initializeConfiguration(Dictionary<string, string> configParams)
        {
            //LogHelper.sb.AppendLine("Entering Method initializeConfiguration()");
            _logFilePath = configParams.Where(x => x.Key == "logFilePath").FirstOrDefault().Value;
            _siteUrl = configParams.Where(x => x.Key == "siteUrl").FirstOrDefault().Value;
            _userName = configParams.Where(x => x.Key == "userName").FirstOrDefault().Value;
            _password = SecureTextHelper.Decrypt(configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value);
            //_password = configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value;
          
            _emailsListName = configParams.Where(x => x.Key == "EmailsListName").FirstOrDefault().Value;
            _approvalrequestListName = configParams.Where(x => x.Key == "ApprovalRequestListName").FirstOrDefault().Value;
            _approvaltaskListName = configParams.Where(x => x.Key == "ApprovalTasksListName").FirstOrDefault().Value;
            _docTypeListName = configParams.Where(x => x.Key == "DocumentTypeListName").FirstOrDefault().Value;
            _emailTemplateListName = configParams.Where(x => x.Key == "EmailTemplateListName").FirstOrDefault().Value;
            _reminderTemplateName = configParams.Where(x => x.Key == "ReminderTemplateName").FirstOrDefault().Value;
            _reminderTemplateNamePast = configParams.Where(x => x.Key == "ReminderTemplateNamePast").FirstOrDefault().Value;
            _adminEmailIds = configParams.Where(x => x.Key == "adminIds").FirstOrDefault().Value;
            //LogHelper.sb.AppendLine("Site Url: "+_siteUrl+", UserName: "+_userName+", Idea List Name: "+_ideaListName+", Project List Name: "+_projectListName);
            //LogHelper.sb.AppendLine("Idea XML File Path: " + _ideaSrcFilePath + ", Project XML File Path: " + _projectSrcFilePath + ", Idea XML Date: " + _ideaFileDateStamp + ", Project XML Date: " + _projectFileDateStamp);

            //LogHelper.sb.AppendLine("Leaving Method initializeConfiguration()");
            _errorAdmins = configParams.Where(x => x.Key == "ErrorAdmins").FirstOrDefault().Value;
        }

        /// <summary>
        /// Write logs to text file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string WriteToLogFile(string data)
        {
            try
            {
                FileStream fs = new FileStream(_logFilePath + "Logs.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("[" + DateTime.Now.ToLongTimeString() + "]" + data);
                sw.Close();
                fs.Close();
                return "log written successfully";
            }
            catch
            {
                return "failed to write loag";
            }
        }

        /// <summary>
        /// Add Emails log to EmailLogs list in SharePoint. The EmailLogs list has a workflow which sends email to the person mentioned in "To" field.
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="web"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        private static void AddExceptionEmail(ClientContext clientContext, string subject, string body)
        {
            try
            {
                Web web = clientContext.Web;
                List emailsLog = web.Lists.GetByTitle(_emailsListName);
                ListItemCreationInformation itemInfo = new ListItemCreationInformation();
                string[] arrAdmin = _errorAdmins.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

                if (arrAdmin.Length > 0)
                {
                    foreach (string admin in arrAdmin)
                    {
                        User user = web.SiteUsers.GetByEmail(admin);
                        clientContext.Load(user);
                        clientContext.ExecuteQuery();
                        ListItem newItem = emailsLog.AddItem(itemInfo);
                        newItem["To"] = user.Id;
                        newItem["Body"] = body;
                        newItem["Title"] = subject;
                        newItem.Update();
                    }
                    clientContext.ExecuteQuery();
                }
            }
            catch (Exception ex)
            {
                WriteToLogFile("Error Message: " + ex.Message + "\nError Stack Trace" + ex.StackTrace);
            }


        }      
    }
}
