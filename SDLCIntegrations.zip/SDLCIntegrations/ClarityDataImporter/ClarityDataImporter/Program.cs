﻿using ClarityDataImporter.Classes;
using ClarityDataImporter.Classes.Helpers;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace ClarityDataImporter
{
    class Program
    {
        static string _siteUrl = string.Empty;
        static string _userName = string.Empty;
        static string _password = string.Empty;
        static string _ideaListName = string.Empty;
        static string _projectListName = string.Empty;
        static string _ideaSrcFilePath = string.Empty;
        static string _projectSrcFilePath = string.Empty;
        static string _ideaFileDateStamp = string.Empty;
        static string _projectFileDateStamp = string.Empty;
        static string _adminid = string.Empty;
        static string _archiverid = string.Empty;
        static string _overwrite = string.Empty;
        static string _emailsListName = string.Empty;
        static string _errorAdmins = string.Empty;
        static string _logFilePath = string.Empty;


        static void Main(string[] args)
        {
                                    
            checkConfiguration();

            ConfigHelper config = XmlHelper.ParseConfigXML();
            initializeConfiguration(config.configParams);

            O365AuthHelper O365Auth = new O365AuthHelper(_siteUrl, _userName, _password);
            SharePointOnlineCredentials  onlineCredentials = O365Auth.getOnlineCredentials();
            
             var targetSite = new Uri(_siteUrl);


             using (ClientContext clientContext = new ClientContext(targetSite))
             {

                 clientContext.Credentials = onlineCredentials;   
                 List<spDataItem> ideaData = XmlHelper.getData(clientContext,_ideaSrcFilePath, "Record", config.IdeaColumns, _ideaFileDateStamp);
                 List<spDataItem> projectData = XmlHelper.getData(clientContext,_projectSrcFilePath, "Record", config.ProjectColumns, _projectFileDateStamp);

                 Web web = clientContext.Web;
                 var ideaList = web.Lists.GetByTitle(_ideaListName);
                 var projectList = web.Lists.GetByTitle(_projectListName);

                 ListItemCreationInformation itemInfo = new ListItemCreationInformation();


                 
                 try
                 {
                     var ideaFields = ideaList.Fields;
                     var projectFields = projectList.Fields;
                     clientContext.Load(ideaFields);
                     clientContext.Load(projectFields);
                     clientContext.ExecuteQuery();
                   
                     foreach (var idea in ideaData)
                     {

                         ListItem newItem = GetSPListItem(clientContext, idea, _ideaListName);
                         if (newItem == null)
                         {
                             newItem = ideaList.AddItem(itemInfo);
                         }
                         setAdditionalColumnProperties(clientContext, idea.columns, ideaFields);
                         foreach (var column in idea.columns)
                         {
                             SetListItemValues(newItem, column);
                         }
                         newItem.Update();

                     }
                     clientContext.ExecuteQuery();
                     Console.WriteLine("\nIdea Data updated");

                     if (ideaData.Count != 0)
                     {

                         if (config.configParams.Where(x => x.Key == "backup_clarityIdeaSrcFileLocation").FirstOrDefault().Value == "#")
                         {
                             ConfigHelper.upDateDateTimeStamp("clarityIdeaSrcFileLocation", _ideaSrcFilePath);
                         }
                         else
                         {
                             ConfigHelper.upDateDateTimeStamp("backup_clarityIdeaSrcFileLocation", _ideaSrcFilePath);
                         }
                     }
                     else
                     {
                         AddExceptionEmail(clientContext, web, "Idea file is blank", "Idea XML file from Clarity is blank. Ideas XML file path - " + _ideaSrcFilePath + "\n" + _siteUrl);
                     }
                    
                    

                     Boolean overwrite;
                     foreach (var project in projectData)
                     {
                         overwrite = true;
                         ListItem newItem = GetSPListItem(clientContext, project, _projectListName);
                         if (newItem == null)
                         {
                             newItem = projectList.AddItem(itemInfo);

                         }
                         else
                         {
                             overwrite = Convert.ToBoolean(newItem[_overwrite]);
                         }
                         if (overwrite)
                         {
                             setAdditionalColumnProperties(clientContext, project.columns, projectFields);
                             foreach (var column in project.columns)
                             {
                                 SetListItemValues(newItem, column);
                             }
                             newItem.Update();
                         }
                        
                     }
                     clientContext.ExecuteQuery();
                     if (projectData.Count != 0)
                     {
                         if (config.configParams.Where(x => x.Key == "backup_clarityPrjSrcFileLocation").FirstOrDefault().Value == "#")
                         {
                             ConfigHelper.upDateDateTimeStamp("clarityPrjSrcFileLocation", _projectSrcFilePath);
                         }
                         else
                         {
                             ConfigHelper.upDateDateTimeStamp("backup_clarityPrjSrcFileLocation", _projectSrcFilePath);
                         }
                     }
                     else
                     {
                         AddExceptionEmail(clientContext, web, "Project file is blank", "Project XML file from Clarity is blank. Projects XML file path - " + _projectSrcFilePath + "\n" + _siteUrl);
                     }

                     
                     

                     Console.WriteLine("\nProject Updated\nDone");
                 }
                 catch (Exception ex)
                 {
                     AddExceptionEmail(clientContext,web, "Error Occured - Clarity data to SharePoint :" + ex.Message, ex.StackTrace);
                 }
                 //Console.ReadKey();                
                
             }
        }


       
        /// <summary>
        /// Add Emails log to EmailLogs list in SharePoint. The EmailLogs list has a workflow which sends email to the person mentioned in "To" field.
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="web"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        private static void AddExceptionEmail(ClientContext clientContext, Web web, string subject, string body)
        {
            try
            {
                List emailsLog = clientContext.Web.Lists.GetByTitle(_emailsListName);
                ListItemCreationInformation itemInfo = new ListItemCreationInformation();
                string[] arrAdmin = _errorAdmins.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

                if (arrAdmin.Length > 0)
                {
                    foreach (string admin in arrAdmin)
                    {
                        User user = web.SiteUsers.GetByEmail(admin);
                        clientContext.Load(user);
                        clientContext.ExecuteQuery();
                        ListItem newItem = emailsLog.AddItem(itemInfo);
                        newItem["To"] = user.Id;
                        newItem["Body"] = body;
                        newItem["Title"] = subject;
                        newItem.Update();
                    }
                    clientContext.ExecuteQuery();
                }
            }
            catch (Exception ex)
            {
                WriteToLogFile("Error Message: " + ex.Message + "\nError Stack Trace" + ex.StackTrace);
            }
            
            
        }      

        /// <summary>
        /// Read Password entered by user and store it in a string variable
        /// </summary>
        /// <returns>Password in String</returns>
        private static string ReadPassword()
        {
            string pwd = string.Empty;
            ConsoleKeyInfo keyInfo = new ConsoleKeyInfo();
            while (keyInfo.Key != ConsoleKey.Enter)
            {
                
                keyInfo = Console.ReadKey(true);
                if (keyInfo.Key != ConsoleKey.Enter)
                    pwd += keyInfo.KeyChar.ToString();
            }
            return pwd;
        }


        /// <summary>
        /// Initialize parameters to the values from Config file
        /// </summary>
        /// <param name="configParams"></param>
        private static void initializeConfiguration(Dictionary<string, string> configParams)
        {
            _logFilePath = configParams.Where(x => x.Key == "logFilePath").FirstOrDefault().Value;
            _siteUrl = configParams.Where(x => x.Key == "siteUrl").FirstOrDefault().Value;
            _userName = configParams.Where(x => x.Key == "userName").FirstOrDefault().Value;
            _password = SecureTextHelper.Decrypt(configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value);         
            _ideaListName = configParams.Where(x => x.Key == "ideaListName").FirstOrDefault().Value;
            _projectListName = configParams.Where(x => x.Key == "projectsListName").FirstOrDefault().Value;
            _emailsListName = configParams.Where(x => x.Key == "EmailsListName").FirstOrDefault().Value;

            _ideaSrcFilePath = configParams.Where(x => x.Key == "backup_clarityIdeaSrcFileLocation").FirstOrDefault().Value;
            _projectSrcFilePath = configParams.Where(x => x.Key == "backup_clarityPrjSrcFileLocation").FirstOrDefault().Value;

            if (_ideaSrcFilePath=="#")
            {
                _ideaSrcFilePath = GenerateSourcePath("clarityIdeaSrcFileLocation", configParams);
            }
            if (_projectSrcFilePath=="#")
            {
                _projectSrcFilePath = GenerateSourcePath("clarityPrjSrcFileLocation", configParams);
            }

            _ideaFileDateStamp = configParams.Where(x => x.Key == "ideaFileLastUpdated").FirstOrDefault().Value;
            _projectFileDateStamp = configParams.Where(x => x.Key == "projectFileLastUpdated").FirstOrDefault().Value;
            _adminid = configParams.Where(x => x.Key == "adminId").FirstOrDefault().Value;
            _archiverid = configParams.Where(x => x.Key == "archiverId").FirstOrDefault().Value;
            _overwrite = configParams.Where(x => x.Key == "overwrite").FirstOrDefault().Value;
            _errorAdmins = configParams.Where(x => x.Key == "ErrorAdmins").FirstOrDefault().Value;           
        }


        /// <summary>
        /// Generate Source path of the file based on time
        /// </summary>
        /// <param name="p"></param>
        /// <param name="configParams"></param>
        /// <returns></returns>
        private static string GenerateSourcePath(string p,Dictionary<string, string> configParams)
        {
            string time;
            DateTime t1 = Convert.ToDateTime("12:00:00 PM");
            DateTime t2 = Convert.ToDateTime("04:00:00 PM");
            string currentDate = DateTime.Now.ToString("dd");

            if (DateTime.Now > t1 && DateTime.Now < t2)
            {
                time = "1200";
            }
            else if (DateTime.Now < t1)
            {
                time = "1600";
                currentDate = DateTime.Now.AddDays(-1).ToString("dd");
            }
            else
            {
                time = "1600";
            }

            string path = configParams.Where(x => x.Key == p).FirstOrDefault().Value + DateTime.Now.ToString("MM") + currentDate + DateTime.Today.Year + time + ".xml"; ;
            return path;
        }

        /// <summary>
        /// Check Configuration and prompt user if anything is blank
        /// </summary>
        private static void checkConfiguration()
        {           
            if (ConfigHelper.IsConfigured)
            {
                Console.WriteLine("Already Configured. Moving On...");               
            }
            else
            {
                Console.WriteLine("App not configured. Please specify below details to configure App.");              
                XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
                foreach (KeyValuePair<string, string> configString in ConfigHelper.UnConfiguredStrings)
                {
                    Console.WriteLine("Enter " + configString.Key + ": ");
                    XElement configElement = xDoc.Descendants("param").Where(x => x.Attribute("key").Value == configString.Value).FirstOrDefault();
                    if (configString.Key == "Password")
                        configElement.SetAttributeValue("value", SecureTextHelper.Encrypt(ReadPassword()));
                    else
                        configElement.SetAttributeValue("value", Console.ReadLine());
                }
                xDoc.Save(Constants.CONFIG_XML_PATH);
                Console.WriteLine("Configuration Done!!");         
            }
        }

        /// <summary>
        /// Set List Item values based on column type
        /// </summary>
        /// <param name="item"></param>
        /// <param name="column"></param>
        private static void SetListItemValues(ListItem item, spDataColumn column)
        {
            switch (column.Type)
            {
                case "Lookup": 
                    if (column.lookupId != 0)
                    {
                        FieldLookupValue lv = new FieldLookupValue();
                        lv.LookupId = column.lookupId;
                        item[column.InternalName] = lv;
                    }
                    break;
                case "Person or Group": FieldUserValue uv = new FieldUserValue();
                    uv.LookupId = column.lookupId;                    
                    item[column.InternalName] = uv;
                    if (column.InternalName == "ProjectManager" || column.InternalName == "Archiver")
                    {
                        item[_archiverid] = "," + uv.LookupId + ",";
                    }
                    break;
                case "Date and Time":
                    if (column.value != "Null")
                    {
                        DateTime date = DateTime.ParseExact(column.value, "MM/dd/yyyy", CultureInfo.CurrentCulture);
                        date = new DateTime(date.Year, date.Month, date.Day, 12, 0, 0);
                        item[column.InternalName] = date.ToString();
                    }
                    break;
                default: item[column.InternalName] = column.value;
                    break;
            }

        }

        /// <summary>
        /// Set additional column properties
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="columns"></param>
        /// <param name="listFields"></param>
        private static void setAdditionalColumnProperties(ClientContext clientContext, List<spDataColumn> columns, FieldCollection listFields)
        {
            foreach (spDataColumn column in columns)
            {
                if (column.Type == "Lookup")
                {
                    Field field = listFields.Where(f => f.InternalName == column.InternalName).FirstOrDefault();
                    FieldLookup lookUpField = (FieldLookup)field;
                    column.lookupId = GetLookupId(clientContext, new Guid(lookUpField.LookupList), lookUpField.LookupField, column.value);
                }
                else if (column.Type == "Person or Group")
                {
                    if (column.value != "")
                    {
                        column.lookupId = GetUserId(clientContext, column.value);
                    }
                }

            }
        }

        /// <summary>
        /// Get Lookup column IDs from master list
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="lookupListId"></param>
        /// <param name="lookupFieldInternalName"></param>
        /// <param name="lookupValue"></param>
        /// <returns></returns>
        private static int GetLookupId(ClientContext clientContext, Guid lookupListId, string lookupFieldInternalName, string lookupValue)
        {
            var lookupSourceList = clientContext.Web.Lists.GetById(lookupListId);
            CamlQuery query = new CamlQuery();
            query.ViewXml = string.Format("<View><Query><Where><Eq><FieldRef Name='{0}'/>" +
                                            "<Value Type='Text'>{1}</Value></Eq></Where></Query></View>", lookupFieldInternalName, lookupValue);
            var listItems = lookupSourceList.GetItems(query);
            clientContext.Load(listItems);
            clientContext.Load(lookupSourceList);
            clientContext.ExecuteQuery();

            if (listItems.Count != 0)
                return listItems.FirstOrDefault().Id;
            else if (lookupSourceList.Title != _ideaListName)
            {
                ListItemCreationInformation itemInfo = new ListItemCreationInformation();
                ListItem newItem = lookupSourceList.AddItem(itemInfo);
                newItem[lookupFieldInternalName] = lookupValue;
                newItem.Update();
                clientContext.ExecuteQuery();
                return newItem.Id;
            }
            else
                return 0;
           // return listItems.FirstOrDefault().Id;
        }

        /// <summary>
        /// Get user id. If the User is not in LDAP, replace them with adminID
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        private static int GetUserId(ClientContext clientContext, string userName)
        {
            var web = clientContext.Web;
            User theUser = web.EnsureUser(userName);
            int uid= Convert.ToInt32(_adminid);
            try
            {
                clientContext.Load(theUser);
                clientContext.ExecuteQuery();
                uid = theUser.Id;
            }
            catch (Exception ex)
            {
                
            }
            return uid;
        }

        
        /// <summary>
        /// GET list item filtered on Title field
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="dataItem"></param>
        /// <param name="listName"></param>
        /// <returns></returns>
        private static ListItem GetSPListItem(ClientContext clientContext, spDataItem dataItem,string listName)
        {
            var list = clientContext.Web.Lists.GetByTitle(listName);
            CamlQuery query = new CamlQuery();
            query.ViewXml = string.Format("<View><Query><Where><Eq><FieldRef Name='Title'/>" +
                                            "<Value Type='Text'>{0}</Value></Eq></Where></Query></View>", dataItem.columns.Where(x=>x.InternalName=="Title").FirstOrDefault().value);
            var listItems = list.GetItems(query);
            clientContext.Load(listItems);
            clientContext.ExecuteQuery();
            if (listItems.Count == 0)
                return null;
            else
                return listItems.FirstOrDefault();
        }

        /// <summary>
        /// Write Logs in a text file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string WriteToLogFile(string data)
        {
            try
            {
                FileStream fs = new FileStream(_logFilePath + "Logs.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("[" + DateTime.Now.ToLongTimeString() + "]" + data);
                sw.Close();
                fs.Close();
                return "log written successfully";
            }
            catch
            {
                return "failed to write loag";
            }
        }
    }
}
