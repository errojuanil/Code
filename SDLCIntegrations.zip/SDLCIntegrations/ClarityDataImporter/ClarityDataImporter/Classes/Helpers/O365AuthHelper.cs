﻿using Microsoft.SharePoint.Client;
using System.Security;

namespace ClarityDataImporter.Classes.Helpers
{
    public class O365AuthHelper
    {
        readonly string _hostUrl;
        readonly string _username;
        readonly string _password;

        public O365AuthHelper(string hostUrl, string username, string password)
        {
            _hostUrl = hostUrl;
            _username = username;
            _password = password;
        }

        public SharePointOnlineCredentials getOnlineCredentials()
        {
            SecureString securePassword = new SecureString();
            foreach (char c in _password)
            {
                securePassword.AppendChar(c);
            }
            SharePointOnlineCredentials creds = new SharePointOnlineCredentials(_username, securePassword);
            return creds;
        }
    }
}
