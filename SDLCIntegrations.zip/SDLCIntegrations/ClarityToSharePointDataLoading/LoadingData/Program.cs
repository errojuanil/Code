﻿using LoadingData.Classes;
using LoadingData.Classes.Helpers;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using SP = Microsoft.SharePoint.Client;

namespace LoadingData
{
    class Program
    {
        static string message;
       
        static string _siteUrl = string.Empty;
        static string _userName = string.Empty;
        static string _password = string.Empty;
        static string sessionId = string.Empty;
        static string _emailsListName = string.Empty;
        static string _workFlowHistoryListName = string.Empty;
        static string _adminEmailIds = string.Empty;
        static string _errorAdmins = string.Empty;
        static string _logFilePath = string.Empty;
        
        static void Main(string[] args)
        {

            OnDemandHelper objOnDemand = new OnDemandHelper();
            // Reading Xml file to get the input parameters like Url, User Name
            checkConfiguration();
            ConfigHelper config = XmlHelper.ParseConfigXML();
            initializeConfiguration(config.configParams);
            O365AuthHelper O365Auth = new O365AuthHelper(_siteUrl, _userName, _password);
            var targetSite = new Uri(_siteUrl);
            using (ClientContext clientContext = new ClientContext(targetSite))
            {
                try
                {
                    // Connecting to O365 Site
                    SharePointOnlineCredentials onlineCredentials = O365Auth.getOnlineCredentials();

                    clientContext.Credentials = onlineCredentials;

                    Web oWebsite = clientContext.Web;
                    ListCollection collList = oWebsite.Lists;

                    // Accessing SharePoint list by name. 
                    List oList = collList.GetByTitle("TestDataLoad");

                                   
                 
                  // Objects used to connect to OnDemand Dev Clarity
                 ProjectService.Auth ws1 = new ProjectService.Auth();
                 ProjectService.DFS_SP_PRJ_SFTPQueryResult objPrjQueryResults = new ProjectService.DFS_SP_PRJ_SFTPQueryResult();
                 ProjectService.DFS_SP_PRJ_SFTPQuery objPrjDataQuery = new ProjectService.DFS_SP_PRJ_SFTPQuery();
                 ProjectService.DFS_SP_PRJ_SFTPQueryPortClient objPrjClient = new ProjectService.DFS_SP_PRJ_SFTPQueryPortClient();
                 ws1.Username = objOnDemand.vClarityAdmin;
                 ws1.Password = objOnDemand.vClarityAdminPassword;
                 sessionId = objPrjClient.WrappedLogin(objOnDemand.vClarityAdmin, objOnDemand.vClarityAdminPassword, "clarity");
                 objPrjDataQuery.Code = "DFS_SP_PRJ_SFTP";
                 objPrjQueryResults = objPrjClient.Query(ws1, objPrjDataQuery);
                 for (int i = 0; i <= objPrjQueryResults.Records.Count() - 1; i++)
                 {
                     //Add a new item in the List

                     ListItemCreationInformation listCreationInformation = new ListItemCreationInformation();
                     ListItem itemToAdd = oList.AddItem(listCreationInformation);
                     string vPrjID = objPrjQueryResults.Records[i].prj_id;
                     itemToAdd["Project_x0020_Number"] = vPrjID;
                     
                     string vPrjName = objPrjQueryResults.Records[i].prj_name;
                     itemToAdd["Title"] = vPrjName;

                     string vPrjManager = objPrjQueryResults.Records[i].prj_mgr;
                     itemToAdd["ProjectManager"] = vPrjManager;

                     string vPrjMgrEmail = objPrjQueryResults.Records[i].prj_mgr_email;
                     itemToAdd["ManagerEmail"] = vPrjMgrEmail;

                     
                     itemToAdd.Update();
                     clientContext.ExecuteQuery();
                     //DateTime vCreated = Convert.ToDateTime(objPrjQueryResults.Records[i].created);



                 }

                    
                
                    Console.WriteLine("Addition Completed.. ");
                    Console.ReadKey();

                }
                catch (Exception ex)
                {
                    Console.Write("Addition program not successful..");

                }
            }

        }
        /// <summary>
        /// Check Configuration and prompt user if anything is blank
        /// </summary>
        private static void checkConfiguration()
        {
            if (ConfigHelper.IsConfigured)
            {
                Console.WriteLine("Already Configured. Moving On...");
            }
            else
            {
                Console.WriteLine("App not configured. Please specify below details to configure App.");
                //LogHelper.sb.AppendLine("App not configured. Getting Configuration Details");
                XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
                foreach (KeyValuePair<string, string> configString in ConfigHelper.UnConfiguredStrings)
                {
                    Console.WriteLine("Enter " + configString.Key + ": ");
                    XElement configElement = xDoc.Descendants("param").Where(x => x.Attribute("key").Value == configString.Value).FirstOrDefault();
                    if (configString.Key == "Password")
                        configElement.SetAttributeValue("value", SecureTextHelper.Encrypt(ReadPassword()));
                    else
                        configElement.SetAttributeValue("value", Console.ReadLine());
                }
                xDoc.Save(Constants.CONFIG_XML_PATH);
                Console.WriteLine("Configuration Done!!");
                //LogHelper.sb.AppendLine("Configuration Done!!");
            }
        }

        /// <summary>
        /// Read Password entered by user and store it in a string variable
        /// </summary>
        /// <returns>Password in String</returns>
        private static string ReadPassword()
        {
            string pwd = string.Empty;
            ConsoleKeyInfo keyInfo = new ConsoleKeyInfo();
            while (keyInfo.Key != ConsoleKey.Enter)
            {

                keyInfo = Console.ReadKey(true);
                if (keyInfo.Key != ConsoleKey.Enter)
                    pwd += keyInfo.KeyChar.ToString();
            }
            return pwd;
        }


        /// <summary>
        /// get User ID by passing user's login name
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        private static int GetUserId(ClientContext clientContext, string userName)
        {
            var web = clientContext.Web;
            var theUser = web.EnsureUser(userName);
            clientContext.Load(theUser);
            clientContext.ExecuteQuery();

            return theUser.Id;
        }


        /// <summary>
        /// Initialize configuration
        /// </summary>
        /// <param name="configParams"></param>
        private static void initializeConfiguration(Dictionary<string, string> configParams)
        {
            //LogHelper.sb.AppendLine("Entering Method initializeConfiguration()");
            //_logFilePath = configParams.Where(x => x.Key == "logFilePath").FirstOrDefault().Value;
            _siteUrl = configParams.Where(x => x.Key == "siteUrl").FirstOrDefault().Value;
            _userName = configParams.Where(x => x.Key == "userName").FirstOrDefault().Value;
            _password = SecureTextHelper.Decrypt(configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value);
            //_password = configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value;

           
            _errorAdmins = configParams.Where(x => x.Key == "ErrorAdmins").FirstOrDefault().Value;
        }

        /// <summary>
        /// Write logs to text file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string WriteToLogFile(string data)
        {
            try
            {
                FileStream fs = new FileStream(_logFilePath + "Logs.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("[" + DateTime.Now.ToLongTimeString() + "]" + data);
                sw.Close();
                fs.Close();
                return "log written successfully";
            }
            catch
            {
                return "failed to write log";
            }
        }


    }
}
