﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Xml.Linq;

namespace LoadingData.Classes.Helpers
{
    public class ConfigHelper
    {

        public Dictionary<string, string> configParams { get; set; }

        public List<spDataColumn> IdeaColumns { get; set; }

        public List<spDataColumn> ProjectColumns { get; set; }

        public static Dictionary<string , string> UnConfiguredStrings { get; private set; }
        //public static List<string> UnConfiguredStrings { get; private set; }

        private static bool _isConfigured;
        public static bool IsConfigured
        {
            get {
                _isConfigured = true;
                //Console.Write(AppDomain.CurrentDomain.BaseDirectory + "XMLs\\Config.xml");
                ConfigHelper config = XmlHelper.ParseConfigXML();
                UnConfiguredStrings = new Dictionary<string, string>();

                foreach (KeyValuePair<string, string> param in config.configParams) 
                {
                    if (!(param.Key == "ideaFileLastUpdated" || param.Key == "projectFileLastUpdated"))
                    {
                        if (string.IsNullOrEmpty(param.Value) && param.Key != "pwd")
                        {
                            _isConfigured = false;
                            UnConfiguredStrings.Add(param.Key, param.Key);
                        }
                        else if (param.Key == "pwd")
                        {
                            if (string.IsNullOrEmpty(param.Value))
                            {
                                _isConfigured = false;
                                UnConfiguredStrings.Add("Password", param.Key);
                            }
                            else
                            {
                                try
                                {
                                    string pass = SecureTextHelper.Decrypt(param.Value);
                                }
                                catch (Exception ex)
                                {
                                    _isConfigured = false;
                                    UnConfiguredStrings.Add("Password", param.Key);
                                }
                            }
                        }
                    }
                }

                return _isConfigured;

            }
            private set
            {
                value = _isConfigured;
            }
        }

        public ConfigHelper()
        {

        }

        public static void upDateDateTimeStamp(string datetimeStampNode,string path)
        {
            string datetimeStamp = File.GetLastWriteTime(path).ToString(Classes.Constants.DATE_TIME_STANDARD_FORMAT);
            XDocument xDoc = XDocument.Load(Classes.Constants.CONFIG_XML_PATH);
            XElement configElement=xDoc.Descendants("param").Where(x => x.Attribute("key").Value == datetimeStampNode).FirstOrDefault();
            configElement.SetAttributeValue("lastUpdated", datetimeStamp);
            xDoc.Save(Classes.Constants.CONFIG_XML_PATH);
        }

    }

    public class spDataColumn
    {
        public string Name { get; set; }
        public string InternalName { get; set; }
        public string Type { get; set; }
        public string SrcXmlNode { get; set; }
        public string value { get; set; }
        public int lookupId { get; set; }
    }

    public class spDataItem
    {
        public List<spDataColumn> columns { get; set; }
    }
}
