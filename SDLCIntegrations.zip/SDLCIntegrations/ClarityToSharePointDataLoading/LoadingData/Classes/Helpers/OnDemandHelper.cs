﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadingData.Classes.Helpers
{
    class OnDemandHelper
    {
        public string vClarityAdmin = "askclarity@discover.com";
        public string vClarityAdminPassword = "clarityoddev";
    }
}
