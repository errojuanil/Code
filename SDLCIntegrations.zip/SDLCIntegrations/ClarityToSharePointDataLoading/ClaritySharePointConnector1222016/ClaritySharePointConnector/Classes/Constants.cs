﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaritySharePointConnector.Classes
{
    public class Constants
    {
        public static string CONFIG_XML_PATH = AppDomain.CurrentDomain.BaseDirectory + "XMLs\\Config.xml";
        public const string DATE_TIME_STANDARD_FORMAT = "MM/dd/yyyy hh:mm:ss";
        public const string DATE_STANDARD_FORMAT = "MM/dd/yyyy";
        public const string TIME_STANDARD_FORMAT = "hh:mm:ss";

       

        #region NotificationMessages
        public const string EMAIL_SUBJECT = "Clarity Data Importer Error: {0}";
        public const string EMAIL_BODY = "Hi All, Please find below error details while importing data from Clarity: {0}."+
                                        "To Know more check the log file. Thanks, EPMO SharePoint";

        #region Titles
        public const string CANNOT_READ_TITLE = "CannotReadXMLFile";
        public const string FILE_NOT_UPDATED_TITLE = "XMLFileNotUpdated";
        public const string FILE_NOT_FOUND_TITLE = "XMLFileNotFound";
        public const string SYSTEM_EX_READ_TITLE = "SystemExceptionXMLRead";
        public const string SYSTEM_EX_TITLE = "SystemException";
        #endregion

        #region Messages
        public const string CANNNOT_READ_MESSAGE = "The XML Source File at path '{0}' is not readable.";
        public const string FILE_NOT_UPDATED_MESSAGE = "The XML Source File at path '{0}' is not modified since last imported on {1}.";
        public const string FILE_NOT_FOUND_MESSAGE = "The XML Source File at path '{0}' not found.";
        public const string SYSTEM_EX_READ_MESSAGE = "The XML Source File at path '{0}' threw Execption: {1} while reading.";
        public const string SYSTEM_EX_MESSAGE = "System Execption: {}";
        #endregion

        #endregion
    }
}
