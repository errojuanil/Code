﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaritySharePointConnector.Classes.Helpers
{
    public class LogHelper
    {
        public static StringBuilder sb { get; set; }
        /// <summary>
        /// Not Used
        /// </summary>
        public static void CreateAndWriteToFile()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory.ToString() + "log" + DateTime.Now.ToString("MMdddyyhhmmss") + ".txt";
            File.AppendAllText(path, sb.ToString());
        }
    }
}
