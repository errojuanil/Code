﻿using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace ClaritySharePointConnector.Classes.Helpers
{
    public class EmailHelper
    {
        /// <summary>
        /// Not Used
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="errorTitle"></param>
        /// <param name="errorDescription"></param>
        /// <returns></returns>
        public static bool sendNotification(ClientContext clientContext,string errorTitle,string errorDescription)
        {
            try
            {
                /*UserCollection users = clientContext.Web.SiteUsers.Where(x => x.IsSiteAdmin) as UserCollection;
                clientContext.Load(users);
                clientContext.ExecuteQuery();

                EmailProperties properties = new EmailProperties();
                properties.To = adminids.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                properties.Subject = string.Format(Constants.EMAIL_SUBJECT, errorTitle);
                properties.Body = string.Format(Constants.EMAIL_BODY, errorDescription);
                Utility.SendEmail(clientContext, properties);        
                */


                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
        }
    }
}
