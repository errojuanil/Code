﻿using ClaritySharePointConnector.Classes;
using ClaritySharePointConnector.Classes.Helpers;
using Microsoft.SharePoint.Client;
using System;
using System.Configuration;
using System.Net;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using SP = Microsoft.SharePoint.Client;

namespace LoadingData
{
    class Program
    {

        static string _siteUrl = string.Empty;
        static string _userName = string.Empty;
        static string _password = string.Empty;
        static string _sessionId = string.Empty;
        static string _emailsListName = string.Empty;
        static string _siteCollectionURL = string.Empty;
        static string _clarityAdmin = string.Empty;
        static string _clarityAdminPassword = string.Empty;
        static string _nsqlProjectDataQuery = string.Empty;
        static string _nsqlTeamMembersQuery = string.Empty;
        static string _partitionCode = string.Empty;
        static string _clarityServerURL = string.Empty;
        static string _adminEmailIds = string.Empty;
        static string _errorAdmins = string.Empty;
        static string _logFilePath = string.Empty;
        static string _siteTemplateId = string.Empty;
        static string _siteMode = string.Empty;
        static string _domain = string.Empty;
        static string _emailDomain1 = string.Empty;
        static string _emailDomain2 = string.Empty;
        static string _ownerGroupId = string.Empty;
        static string _memberGroupId = string.Empty;
        static string _visitorGroupId = string.Empty;

        /// <summary>
        /// The Main method.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {

            // Reading Xml file to get the input parameters like Url, User Name
            checkConfiguration();
            ConfigHelper config = XmlHelper.ParseConfigXML();
            initializeConfiguration(config.configParams);
            O365AuthHelper O365Auth = new O365AuthHelper(_siteUrl, _userName, _password);
            var targetSite = new Uri(_siteUrl);
            using (ClientContext clientContext = new ClientContext(targetSite))
            {
                try
                {
                    if (_siteMode == "online")
                    {
                        SharePointOnlineCredentials onlineCredentials = O365Auth.getOnlineCredentials();

                        clientContext.Credentials = onlineCredentials;

                        // The SharePoint web at the URL.
                        Web oWebsite = clientContext.Web;

                        // We want to retrieve the web's properties.
                        clientContext.Load(oWebsite);

                        // Execute the query to the server.
                        clientContext.ExecuteQuery();

                        // web properties, such as title. 
                        System.Console.WriteLine(oWebsite.Title);


                        // The below objects used to connect to OnDemand Dev Clarity
                        CGProjectService.Auth psAuth = new CGProjectService.Auth();
                        CGProjectService.CG_SP_PRJQueryResult objPrjQueryResults = new CGProjectService.CG_SP_PRJQueryResult();
                        CGProjectService.CG_SP_PRJQuery objPrjDataQuery = new CGProjectService.CG_SP_PRJQuery();
                        CGProjectService.CG_SP_PRJQueryPortClient objPrjClient = new CGProjectService.CG_SP_PRJQueryPortClient();

                        // Passing OD credentials to Service objects
                        psAuth.Username = _clarityAdmin;
                        //ConfigurationManager.AppSettings["vClarityAdmin"];
                        psAuth.Password = _clarityAdminPassword;
                        //ConfigurationManager.AppSettings["vClarityAdminPassword"];

                        _sessionId = objPrjClient.WrappedLogin(psAuth.Username, psAuth.Password, "clarity");

                        // Mentioning the ID of the Query
                        objPrjDataQuery.Code = _nsqlProjectDataQuery;
                        //ConfigurationManager.AppSettings["nsqlProjectDataQuery"];

                        // Retrieving the data from OnDemand query through service
                        objPrjQueryResults = objPrjClient.Query(psAuth, objPrjDataQuery);



                        // Loop to reading Project information one by one from OnDemand
                        for (int i = 0; i <= objPrjQueryResults.Records.Count() - 1; i++)
                        {
                            string vPrjID = objPrjQueryResults.Records[i].prj_id;
                            string vPrjName = objPrjQueryResults.Records[i].prj_name;

                            string vPrjManager = objPrjQueryResults.Records[i].prj_mgr;

                            string vPrjMgrEmail = objPrjQueryResults.Records[i].prj_mgr_email;


                            bool isExistingSite = IsExistingSite(oWebsite, clientContext, _siteUrl + vPrjID);
                            if (isExistingSite)
                            {
                                updateProjectSiteDetails(onlineCredentials, _siteUrl + vPrjID, vPrjID, vPrjName, vPrjMgrEmail);
                                updateTeamAccessDetails(onlineCredentials);


                            }
                            else
                            {
                                bool isSiteCreationSuccessful = createNewProjectSite(onlineCredentials, _siteUrl, vPrjID, vPrjName, vPrjMgrEmail);
                                if (isSiteCreationSuccessful)
                                {
                                    updateSharePointURLinClarity(_siteUrl + vPrjID, vPrjID, vPrjName);
                                }

                            }

                        }


                    }
                    if (_siteMode == "onpremise")
                    {

                        var onPremiseCredentials = new NetworkCredential(_userName, _password, _domain);
                        clientContext.Credentials = onPremiseCredentials;


                        // The SharePoint web at the URL.
                        Web oWebsite = clientContext.Web;

                        // We want to retrieve the web's properties.
                        clientContext.Load(oWebsite);

                        // Execute the query to the server.
                        clientContext.ExecuteQuery();

                        // web properties, such as title. 
                        System.Console.WriteLine(oWebsite.Title);
                        //createNewProjectSite(onPremiseCredentials, _siteUrl, "TestFriday5", "TestFriday5", "kunal.nagpure@capgemini.com");

                        // The below objects used to connect to OnDemand Dev Clarity
                        CGProjectService.Auth psAuth = new CGProjectService.Auth();
                        CGProjectService.CG_SP_PRJQueryResult objPrjQueryResults = new CGProjectService.CG_SP_PRJQueryResult();
                        CGProjectService.CG_SP_PRJQuery objPrjDataQuery = new CGProjectService.CG_SP_PRJQuery();
                        CGProjectService.CG_SP_PRJQueryPortClient objPrjClient = new CGProjectService.CG_SP_PRJQueryPortClient();

                        // Passing OD credentials to Service objects
                        psAuth.Username = _clarityAdmin;
                        //ConfigurationManager.AppSettings["vClarityAdmin"];
                        psAuth.Password = _clarityAdminPassword;
                        //ConfigurationManager.AppSettings["vClarityAdminPassword"];

                        _sessionId = objPrjClient.WrappedLogin(psAuth.Username, psAuth.Password, "clarity");

                        // Mentioning the ID of the Query
                        objPrjDataQuery.Code = _nsqlProjectDataQuery;
                        //ConfigurationManager.AppSettings["nsqlProjectDataQuery"];

                        // Retrieving the data from OnDemand query through service
                        objPrjQueryResults = objPrjClient.Query(psAuth, objPrjDataQuery);



                        // Loop to reading Project information one by one from OnDemand
                        for (int i = 0; i <= objPrjQueryResults.Records.Count() - 1; i++)
                        {
                            string vPrjID = objPrjQueryResults.Records[i].prj_id;
                            string vPrjName = objPrjQueryResults.Records[i].prj_name;

                            string vPrjManager = objPrjQueryResults.Records[i].prj_mgr;

                            string vPrjMgrEmail = objPrjQueryResults.Records[i].prj_mgr_email;


                            bool isExistingSite = IsExistingSite(oWebsite, clientContext, _siteUrl + vPrjID);

                            if (isExistingSite)
                            {

                                WriteToLogFile(vPrjID + ": Update: Connected to SharePoint Main Site: " + _siteUrl);
                                WriteToLogFile("Project Details updation and Team details updation started for " + vPrjID);

                                updateProjectSiteDetails(onPremiseCredentials, _siteUrl + vPrjID, vPrjID, vPrjName, vPrjMgrEmail);
                                updateTeamAccessDetails(onPremiseCredentials);
                               // WriteToLogFile(vPrjID + ": Project Details updation and Team details updation completed for " + vPrjID);

                            }
                            else
                            {
                                WriteToLogFile("New: Connected to SharePoint Main Site: " + _siteUrl);
                                WriteToLogFile("Project site creation started for" + vPrjID);

                                bool isSiteCreationSuccessful = createNewProjectSite(onPremiseCredentials, _siteUrl, vPrjID, vPrjName, vPrjMgrEmail);
                                if (isSiteCreationSuccessful)
                                {
                                    updateSharePointURLinClarity(_siteUrl + vPrjID, vPrjID, vPrjName);
                                   // WriteToLogFile("Project site creation completed for" + vPrjID);
                                }

                            }

                        }

                    }
                }
                catch (Exception ex)
                {

                    WriteToLogFile("ERROR from Main Method: " + ex);

                }
            }

        }
        /// <summary>
        /// This function to create a new project
        /// </summary>
        /// <param name="onlineCredentials"></param>
        /// <param name="mainURL"></param>
        /// <param name="vPrjID"></param>
        /// <param name="vPrjName"></param>
        /// <param name="vPrjManager"></param>
        private static bool createNewProjectSite(SharePointOnlineCredentials onlineCredentials, string mainURL, string vPrjID, string vPrjName, string vPrjManager)
        {
            bool res = false;

            WebCreationInformation webCreation = new WebCreationInformation();
            webCreation.Url = vPrjID;
            ClientContext clientContext = new ClientContext(mainURL);
            clientContext.Credentials = onlineCredentials;

            webCreation.Title = vPrjID + " " + vPrjName;
            webCreation.UseSamePermissionsAsParentSite = false;
            webCreation.WebTemplate = _siteTemplateId;
            //ConfigurationManager.AppSettings["siteTemplateId"].ToString();
            Web newWeb = clientContext.Web.Webs.Add(webCreation);
            clientContext.Load(newWeb, w => w.Title);

            clientContext.ExecuteQuery();


            // Retrieing SharePoint Group information
            Group ownerGroup = clientContext.Web.SiteGroups.GetById(Convert.ToInt32(_ownerGroupId));

            //create the user object
            UserCreationInformation teamMember = new UserCreationInformation();
            User member = newWeb.EnsureUser(vPrjManager);
            // User member = newWeb.EnsureUser("rpatel4@discover.com");




            ownerGroup.Users.AddUser(member);

            clientContext.ExecuteQuery();

            WriteToLogFile(vPrjID + " Project Site creation completed successfully. ");


            return res = true;


        }
        private static bool createNewProjectSite(NetworkCredential onPremiseCredentials, string mainURL, string vPrjID, string vPrjName, string vPrjManager)
        {
            bool res = false;
            ClientContext clientContext = new ClientContext(mainURL);
            try
            {
                WebCreationInformation webCreation = new WebCreationInformation();
                webCreation.Url = vPrjID;

                clientContext.Credentials = onPremiseCredentials;
                clientContext.RequestTimeout = 1000 * 60 * 3;

                webCreation.Title = vPrjID + " " + vPrjName;
                webCreation.UseSamePermissionsAsParentSite = false;

                webCreation.WebTemplate = _siteTemplateId;

                Web newWeb = clientContext.Web.Webs.Add(webCreation);
                clientContext.Load(newWeb, w => w.Title);

                try
                {
                    clientContext.ExecuteQuery();
                }
                catch (Exception ex)
                {
                    if (ex.Message == "The operation has timed out")
                    {
                        clientContext.ExecuteQuery();
                    }
                }
                

                ClientContext clientContextSubsite = new ClientContext(mainURL + vPrjID);
                clientContextSubsite.Credentials = onPremiseCredentials;
                Web subSite = clientContextSubsite.Web;

                createNewGroup(vPrjID, vPrjID + " Project Manager", vPrjID + " Project Manager group", "Full Control", clientContextSubsite);

                createNewGroup(vPrjID, vPrjID + " Visitors", vPrjID + " Visitors group", "Read", clientContextSubsite);
                createNewGroup(vPrjID, vPrjID + " Members", vPrjID + " Members group", "Contribute", clientContextSubsite);
                createNewGroup(vPrjID, vPrjID + " Owners", vPrjID + " Owners group", "Full Control", clientContextSubsite);



                // Adding User to Owner Group
                if ((vPrjManager != null) || (vPrjManager != string.Empty))
                {
                    if ((vPrjManager.Contains("capgemini")) || (vPrjManager.Contains("igate")))
                    {
                        assignUserToGroup(vPrjID, vPrjManager, vPrjID + " Project Manager", clientContextSubsite);

                    }
                }
                // End of Adding User to Owner Group

            }

            catch (Exception ex)
            {

                WriteToLogFile(vPrjID + ":Error from createNewProjectSite: " + ex);

            }
            return res = true;
        }



        /// <summary>
        /// This function used to create groups
        /// </summary>
        /// <param name="groupTitle"></param>
        /// <param name="groupDescription"></param>
        /// <param name="groupPermission"></param>
        /// <param name="clientContextSubsite"></param>
        private static void createNewGroup(string vPrjID, string groupTitle, string groupDescription, string groupPermission, ClientContext clientContextSubsite)
        {
            try
            {
                GroupCreationInformation ObjGroup = new GroupCreationInformation();

                ObjGroup.Title = groupTitle;

                ObjGroup.Description = groupDescription;

                Principal objPrincipal = clientContextSubsite.Web.SiteGroups.Add(ObjGroup);
                //Get a role.             
                RoleDefinition rdRead = clientContextSubsite.Web.RoleDefinitions.GetByName(groupPermission);

                //create the role definition binding collection 
                RoleDefinitionBindingCollection rdbRead = new RoleDefinitionBindingCollection(clientContextSubsite);

                //add the role definition to the collection 
                rdbRead.Add(rdRead);

                //create a RoleAssigment with the group and role definition 
                clientContextSubsite.Web.RoleAssignments.Add(objPrincipal, rdbRead);

                //execute the query to add everything 
                clientContextSubsite.ExecuteQuery();
                WriteToLogFile(groupTitle + ": Group is created successfully. ");
            }
            catch (Exception ex)
            {
                WriteToLogFile(vPrjID + ": Error from createNewGroup: " + ex);

            }

        }
        /// <summary>
        /// Assigning a user to a group...
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="groupName"></param>
        /// <param name="clientContextSubsite"></param>
        private static void assignUserToGroup(string vPrjID, string userName, string groupName, ClientContext clientContextSubsite)
        {
            try
            {
                if ((userName != null) || (userName != string.Empty))
                {
                    if ((userName.Contains(_emailDomain1)) || (userName.Contains(_emailDomain2)))
                    {
                        Web subSite = clientContextSubsite.Web;
                        User currentUser = subSite.EnsureUser(userName);
                        Group projectManagerGroup = clientContextSubsite.Web.SiteGroups.GetByName(groupName);
                        projectManagerGroup.Users.AddUser(currentUser);

                        clientContextSubsite.Load(currentUser);
                        clientContextSubsite.Load(projectManagerGroup);
                        clientContextSubsite.ExecuteQuery();
                        WriteToLogFile(groupName + ": Access provided to the User: " + userName + " successfully");
                    }
                }
            }
            catch (Exception ex)
            {
                WriteToLogFile(vPrjID + ": Error from assignUserToGroup: " + ex);
            }

        }

        /// <summary>
        /// This function is used to update the URL in the Clarity server.
        /// </summary>
        /// <param name="siteURL"></param>
        /// <param name="prjID"></param>
        /// <param name="prjName"></param>
        private static void updateSharePointURLinClarity(string currentSiteURL, string prjID, string prjName)
        {
            try
            {
                string strEnv = null;
                string strAuth = null;
                string projectid = prjID;
                string projectname = prjName;



                System.Net.WebClient manualWebClient = new System.Net.WebClient();
                manualWebClient.Headers.Add("Content-Type", "application/soap+xml;  charset=utf-8");

                manualWebClient.Headers.Add("SOAPAction", "http://www.niku.com/xog/Object/WriteCustomObjectInstance");
                if (string.IsNullOrEmpty(_sessionId))
                {

                    strAuth = " <obj:Username>" + _clarityAdmin + "</obj:Username> <obj:Password>" + _clarityAdminPassword + "</obj:Password>";
                }
                else
                {
                    strAuth = " <obj:SessionID>" + _sessionId + "</obj:SessionID> ";
                }

                strEnv = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:obj=\"http://www.niku.com/xog/Object\">" + System.Environment.NewLine + " <soapenv:Header> " + System.Environment.NewLine + "<obj:Auth> " + System.Environment.NewLine + "<obj:TenantID>clarity</obj:TenantID>" + System.Environment.NewLine + strAuth + System.Environment.NewLine + "</obj:Auth>" + System.Environment.NewLine + "</soapenv:Header>" + System.Environment.NewLine + "<soapenv:Body>" + System.Environment.NewLine + "  <NikuDataBus xsi:noNamespaceSchemaLocation=\"../xsd/nikuxog_project.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" + System.Environment.NewLine + "\t<Header action=\"write\" externalSource=\"NIKU\" objectType=\"project\" version=\"13.3.0.286\"/>" + System.Environment.NewLine + "<Projects>" + System.Environment.NewLine + "<Project projectID=\"" + projectid + "\" name=\"" + projectname + "\" > " + System.Environment.NewLine + "\t<CustomInformation>" + System.Environment.NewLine + " \t\t <ColumnValue name=\"partition_code\">" + _partitionCode + "</ColumnValue>" + System.Environment.NewLine + "  <ColumnValue name=\"cg_inv_doc_url\">" + currentSiteURL + "</ColumnValue>" + " <ColumnValue name=\"cg_sp_flag\">false</ColumnValue>" + System.Environment.NewLine + " </CustomInformation>" + System.Environment.NewLine + "  </Project>" + System.Environment.NewLine + " </Projects>" + System.Environment.NewLine + "    </NikuDataBus>" + System.Environment.NewLine + " </soapenv:Body>" + System.Environment.NewLine + "</soapenv:Envelope>";

                byte[] bytArguments1 = System.Text.Encoding.ASCII.GetBytes(strEnv);
                byte[] bytRetData1 = manualWebClient.UploadData(_clarityServerURL + "/niku/xog", "POST", bytArguments1);


                WriteToLogFile(prjID + " SharePoint site URL and SharePoint flag successfully updated in the Clarity. ");

            }
            catch (Exception ex)
            {

                WriteToLogFile(prjID + ": Error from updateSharePointURLinClarity. " + ex);
            }
        }


        /// <summary>
        /// This function will updates the 
        /// </summary>
        /// <param name="onlineCredentials"></param>
        /// <param name="subSiteURL"></param>
        private static void updateProjectSiteDetails(SharePointOnlineCredentials onlineCredentials, string subSiteURL, string vPrjID, string vPrjName, string vPrjManager)
        {
            try
            {
                // Connecting to existing subsite
                ClientContext subSiteContext = new ClientContext(subSiteURL);

                subSiteContext.Credentials = onlineCredentials;

                Web web = subSiteContext.Web;
                web.Title = vPrjID + " " + vPrjName;
                // oWebsite.Description = "New Description";

                // Retrieing SharePoint Group information
                Group oOwnerGroup = subSiteContext.Web.SiteGroups.GetById(Convert.ToInt32(_ownerGroupId));

                // Creation object for User
                // UserCreationInformation teamMember = new UserCreationInformation();
                User member = web.EnsureUser(vPrjManager);
                //User member = web.EnsureUser("rpatel4@discover.com");

                // Removing access of existing user on the site.
                oOwnerGroup.Users.AddUser(member);
                web.Update();

                // Execute the query to server.
                subSiteContext.ExecuteQuery();

                WriteToLogFile(vPrjID + " :Project Site details updated successfully. ");
                
            }

            catch (Exception ex)
            {

                WriteToLogFile(vPrjID + " :Error from updateProjectSiteDetails. " + ex);
            }

        }
        private static void updateProjectSiteDetails(NetworkCredential onPremiseCredentials, string subSiteURL, string vPrjID, string vPrjName, string vPrjManager)
        {
            //vPrjManager = "abhijit.tarkunde@capgemini.com";
            // Connecting to existing subsite

            ClientContext subSiteContext = new ClientContext(subSiteURL);
            try
            {

                subSiteContext.Credentials = onPremiseCredentials;

                Web web = subSiteContext.Web;
                web.Title = vPrjID + " " + vPrjName;

                // Updating details of new Project Manager
                if ((vPrjManager != null) || (vPrjManager != string.Empty))
                {
                    if ((vPrjManager.Contains(_emailDomain1)) || (vPrjManager.Contains(_emailDomain2)))
                    {
                        // Creation object for User
                        User teamMember = web.EnsureUser(vPrjManager);
                        // Retrieing SharePoint Group information
                        Group projectManagerGroup = subSiteContext.Web.SiteGroups.GetByName(vPrjID + " Project Manager");

                        GroupCollection collGroup = subSiteContext.Web.SiteGroups;
                        subSiteContext.Load(collGroup,
                                        groups => groups.Include(
                                         group => group.Title,
                                          group => group.Id,
                                           group => group.Users.Include(
                                            user => user.Title,
                                             user => user.LoginName)));

                        subSiteContext.ExecuteQuery();


                        // foreach (Group oGroup in collGroup)
                        //{
                        bool isGroupExists = GroupExists(collGroup, vPrjID + " Project Manager", subSiteContext);
                        if (isGroupExists)
                        {

                            //Getting existing project manager from a group and removing.
                            UserCollection collUser = projectManagerGroup.Users;
                            subSiteContext.Load(collUser);

                            subSiteContext.ExecuteQuery();
                            foreach (User member in collUser)
                            {
                               
                                if ((member.Email) != null)
                                {
                                    if ((member.Email) != vPrjManager)
                                    {
                                        removeUserFromGroup(vPrjID + " Project Manager", member, projectManagerGroup, subSiteContext);
                                        assignUserToGroup(vPrjID, vPrjManager, vPrjID + " Project Manager", subSiteContext);
                                    }

                                }//end of for each Getting existing members from a group and removing.

                            }

                        }
                        else
                        {
                            // creating new PM group and assing the project Manager
                            createNewGroup(vPrjID, vPrjID + " Project Manager", vPrjID + " Project Manager group", "Full Control", subSiteContext);
                            assignUserToGroup(vPrjID, vPrjManager, vPrjID + " Project Manager", subSiteContext);
                        }

                        // }
                        //createNewGroup(vPrjID, vPrjID + " Project Manager", vPrjID + " Project Manager group", "Full Control", subSiteContext);
                       

                        // projectManagerGroup.Users.AddUser(teamMember);
                        //WriteToLogFile(vPrjID + ":Project Site new Project Manager " + vPrjManager + " details updated successfully. ");

                    }
                }

                web.Update();

                // Execute the query to server.
                subSiteContext.ExecuteQuery();

                WriteToLogFile(vPrjID + " :Project Site details updated successfully. ");
                
            }
            catch (ServerException)
            {
                createNewGroup(vPrjID, vPrjID + " Project Manager", vPrjID + " Project Manager group", "Full Control", subSiteContext);
                assignUserToGroup(vPrjID, vPrjManager, vPrjID + " Project Manager", subSiteContext);
                
            }

            catch (Exception ex)
            {

                WriteToLogFile(vPrjID + " :Error from updateProjectSiteDetails. " + ex);
            }

        }
        public static bool GroupExists(GroupCollection collGroup, string name, ClientContext subSiteContext)
        {
            subSiteContext.Load(collGroup,
                                        groups => groups.Include(
                                         group => group.Title,
                                          group => group.Id));

            subSiteContext.ExecuteQuery();

            if (string.IsNullOrEmpty(name) ||

                (name.Length > 255) ||

                (collGroup == null) ||

                (collGroup.Count == 0))

                return false;

            else

                return true;
        }


        /// <summary>
        /// Removing the existing user from a group..
        /// </summary>
        private static void removeUserFromGroup(string projectGroupName, User userName, Group groupName, ClientContext clientContextSubsite)
        {
            try
            {
                groupName.Users.Remove(userName);
                clientContextSubsite.Load(userName);
                clientContextSubsite.Load(groupName);
                clientContextSubsite.ExecuteQuery();
                WriteToLogFile(projectGroupName + " : Access removed to the User: " + userName + " successfully");
            }
            catch (Exception ex)
            {
                WriteToLogFile(projectGroupName + ": Error from removeUserFromGroup. " + ex);

            }
        }
        /// <summary>
        /// This function updates the Team members access details of a Project Site.
        /// </summary>
        private static void updateTeamAccessDetails(SharePointOnlineCredentials onlineCredentials)
        {
            try
            {
                // Objects to connect with TeamMembersService
                CGTeamMembersService.Auth tmAuth = new CGTeamMembersService.Auth();
                CGTeamMembersService.CG_SP_TEAM_SECQueryResult objTmQueryResults = new CGTeamMembersService.CG_SP_TEAM_SECQueryResult();
                CGTeamMembersService.CG_SP_TEAM_SECQuery objTmDataQuery = new CGTeamMembersService.CG_SP_TEAM_SECQuery();
                CGTeamMembersService.CG_SP_TEAM_SECQueryPortClient objTmClient = new CGTeamMembersService.CG_SP_TEAM_SECQueryPortClient();

                tmAuth.Username = _clarityAdmin;
                //ConfigurationManager.AppSettings["vClarityAdmin"];
                tmAuth.Password = _clarityAdminPassword;
                //ConfigurationManager.AppSettings["vClarityAdminPassword"];

                _sessionId = objTmClient.WrappedLogin(tmAuth.Username, tmAuth.Password, "clarity");
                objTmDataQuery.Code = _nsqlTeamMembersQuery;
                //ConfigurationManager.AppSettings["nsqlTeamMembersQuery"];
                objTmQueryResults = objTmClient.Query(tmAuth, objTmDataQuery);


                for (int i = 0; i <= objTmQueryResults.Records.Count() - 1; i++)
                {
                    string PRJID = objTmQueryResults.Records[i].prj_id;

                    string TEMAIL = objTmQueryResults.Records[i].team_email;
                    string Perm = objTmQueryResults.Records[i].sp_permission;

                    // Connecting to existing subsite
                    ClientContext subSiteContext = new ClientContext(_siteUrl + PRJID);
                    //(ConfigurationManager.AppSettings["SiteCollectionURL"] + PRJID);
                    subSiteContext.Credentials = onlineCredentials;
                    Web web = subSiteContext.Web;


                    // Creation object for User
                    //UserCreationInformation teamMember = new UserCreationInformation();
                    User teamMember = web.EnsureUser(TEMAIL);
                    //User teamMember = web.EnsureUser("stallur@discover.com");


                    //Check the Permission details of the user
                    if (objTmQueryResults.Records[i].sp_permission == "Full")
                    {
                        Group oOwnerGroup = subSiteContext.Web.SiteGroups.GetById(Convert.ToInt32(_ownerGroupId));
                        oOwnerGroup.Users.AddUser(teamMember);
                    }
                    else if (objTmQueryResults.Records[i].sp_permission == "Contribute")
                    {
                        Group omemberGroup = subSiteContext.Web.SiteGroups.GetById(Convert.ToInt32(_memberGroupId));
                        omemberGroup.Users.AddUser(teamMember);
                    }
                    else if (objTmQueryResults.Records[i].sp_permission == "Read")
                    {
                        Group ovisitorGroup = subSiteContext.Web.SiteGroups.GetById(Convert.ToInt32(_visitorGroupId));
                        ovisitorGroup.Users.AddUser(teamMember);
                    }

                    web.Update();

                    // Execute the query to server.
                    subSiteContext.ExecuteQuery();

                    WriteToLogFile(PRJID + " Project's Team members details updated successfully.");
                }
            }
            catch (Exception ex)
            {

                WriteToLogFile("Error from updateTeamAccessDetails. " + ex);
            }

            //End of Team service
        }
        /// <summary>
        /// updateTeamAccessDetails for Onpremise User
        /// </summary>
        /// <param name="onPremiseCredentials"></param>
        private static void updateTeamAccessDetails(NetworkCredential onPremiseCredentials)
        {
            try
            {
                // Objects to connect with TeamMembersService
                CGTeamMembersService.Auth tmAuth = new CGTeamMembersService.Auth();
                CGTeamMembersService.CG_SP_TEAM_SECQueryResult objTmQueryResults = new CGTeamMembersService.CG_SP_TEAM_SECQueryResult();
                CGTeamMembersService.CG_SP_TEAM_SECQuery objTmDataQuery = new CGTeamMembersService.CG_SP_TEAM_SECQuery();
                CGTeamMembersService.CG_SP_TEAM_SECQueryPortClient objTmClient = new CGTeamMembersService.CG_SP_TEAM_SECQueryPortClient();

                tmAuth.Username = _clarityAdmin;
                //ConfigurationManager.AppSettings["vClarityAdmin"];
                tmAuth.Password = _clarityAdminPassword;
                //ConfigurationManager.AppSettings["vClarityAdminPassword"];

                _sessionId = objTmClient.WrappedLogin(tmAuth.Username, tmAuth.Password, "clarity");
                objTmDataQuery.Code = _nsqlTeamMembersQuery;
                //ConfigurationManager.AppSettings["nsqlTeamMembersQuery"];
                objTmQueryResults = objTmClient.Query(tmAuth, objTmDataQuery);

                for (int i = 0; i <= objTmQueryResults.Records.Count() - 1; i++)
                {
                    string PRJID = objTmQueryResults.Records[i].prj_id;

                    string TEMAIL = objTmQueryResults.Records[i].team_email;
                    string Perm = objTmQueryResults.Records[i].sp_permission;
                    string permFlag = objTmQueryResults.Records[i].sp_permission_flag;


                    // Connecting to existing subsite
                    ClientContext subSiteContext = new ClientContext(_siteUrl + PRJID);
                    subSiteContext.Credentials = onPremiseCredentials;
                    Web web = subSiteContext.Web;


                    // Creation object for User and updating user permissions
                    if ((TEMAIL != null) || (TEMAIL != string.Empty))
                    {
                        if ((TEMAIL.Contains(_emailDomain1)) || (TEMAIL.Contains(_emailDomain2)))
                        {
                            User teamMember = web.EnsureUser(TEMAIL);
                            
                            if ((permFlag == "TRUE") || (permFlag == "True"))
                            {

                                //Check the Permission details of the user
                                if (objTmQueryResults.Records[i].sp_permission == "Full")
                                {
                                    assignUserToGroup(PRJID, TEMAIL, PRJID + " Owners", subSiteContext);
                                    // Group ownerGroup = subSiteContext.Web.SiteGroups.GetByName(PRJID + " Owners");
                                    //ownerGroup.Users.AddUser(teamMember);

                                    // subSiteContext.Load(teamMember);
                                    // subSiteContext.Load(ownerGroup);
                                    // subSiteContext.ExecuteQuery();
                                    //WriteToLogFile(PRJID + " :Full Access provided to " + TEMAIL + " successfully");
                                }
                                else if (objTmQueryResults.Records[i].sp_permission == "Contribute")
                                {
                                    assignUserToGroup(PRJID, TEMAIL, PRJID + " Members", subSiteContext);

                                    // Group omemberGroup = subSiteContext.Web.SiteGroups.GetByName(PRJID + " Members");
                                    //omemberGroup.Users.AddUser(teamMember);

                                    //subSiteContext.Load(teamMember);
                                    //subSiteContext.Load(omemberGroup);
                                    //subSiteContext.ExecuteQuery();
                                    //WriteToLogFile(PRJID + " :Contributor Access provided to " + TEMAIL + " successfully");

                                }
                                else if (objTmQueryResults.Records[i].sp_permission == "Read")
                                {
                                    // Adding User to Visitors Group
                                    assignUserToGroup(PRJID, TEMAIL, PRJID + " Visitors", subSiteContext);
                                    //Group VisitorsGroup = subSiteContext.Web.SiteGroups.GetByName(PRJID + " Visitors");
                                    //VisitorsGroup.Users.AddUser(teamMember);

                                    //subSiteContext.Load(teamMember);
                                    //subSiteContext.Load(VisitorsGroup);
                                    //subSiteContext.ExecuteQuery();
                                    // WriteToLogFile(PRJID + " :Read Access provided to " + TEMAIL + " successfully");

                                }
                            }
                            if ((permFlag == "FALSE") || (permFlag == "False"))
                            {
                                if (objTmQueryResults.Records[i].sp_permission == "Full")
                                {
                                    Group ownerGroup = subSiteContext.Web.SiteGroups.GetByName(PRJID + " Owners");
                                    removeUserFromGroup(PRJID + " Owners", teamMember, ownerGroup, subSiteContext);

                                }
                                else if (objTmQueryResults.Records[i].sp_permission == "Contribute")
                                {
                                    Group omemberGroup = subSiteContext.Web.SiteGroups.GetByName(PRJID + " Members");
                                    removeUserFromGroup(PRJID + " Members", teamMember, omemberGroup, subSiteContext);


                                }
                                else if (objTmQueryResults.Records[i].sp_permission == "Read")
                                {
                                    Group visitorsGroup = subSiteContext.Web.SiteGroups.GetByName(PRJID + " Visitors");
                                    removeUserFromGroup(PRJID + " Visitors", teamMember, visitorsGroup, subSiteContext);


                                }

                            }

                        }

                    }

                    web.Update();
                    WriteToLogFile(PRJID + " Project's Team members details updated successfully.");
                }
            }
            catch (Exception ex)
            {

                WriteToLogFile("Error from updateTeamAccessDetails. " + ex);
            }

            //End of Team service
        }

        /// <summary>
        /// This function is used to check; whether current site is existing or not
        /// </summary>
        /// <param name="oWebsite"></param>
        /// <param name="clientContext"></param>
        /// <param name="siteURL"></param>
        /// <returns></returns>
        private static bool IsExistingSite(Web oWebsite, ClientContext clientContext, string siteURL)
        {
            bool res = false;
            clientContext.Load(oWebsite, website => website.Webs, website => website.Title);
            clientContext.ExecuteQuery();
            foreach (Web existingWebsite in oWebsite.Webs)
            {
                if (existingWebsite.Url.Equals(siteURL))
                {
                    res = true;


                }
            }
            return res;

        }
        /// <summary>
        /// Check Configuration and prompt user if anything is blank
        /// </summary>
        private static void checkConfiguration()
        {
            try
            {
                if (ConfigHelper.IsConfigured)
                {
                    Console.WriteLine("Already Configured. Moving On...");
                }
                else
                {
                    Console.WriteLine("App not configured. Please specify below details to configure App.");
                    //LogHelper.sb.AppendLine("App not configured. Getting Configuration Details");
                    XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
                    foreach (KeyValuePair<string, string> configString in ConfigHelper.UnConfiguredStrings)
                    {
                        Console.WriteLine("Enter " + configString.Key + ": ");
                        XElement configElement = xDoc.Descendants("param").Where(x => x.Attribute("key").Value == configString.Value).FirstOrDefault();
                        if (configString.Key == "Password")
                            configElement.SetAttributeValue("value", SecureTextHelper.Encrypt(ReadPassword()));
                        else
                            configElement.SetAttributeValue("value", Console.ReadLine());
                    }
                    xDoc.Save(Constants.CONFIG_XML_PATH);
                    Console.WriteLine("Configuration Done!!");
                    WriteToLogFile("Configuration Done!!");
                }
            }
            catch (Exception ex)
            {
                WriteToLogFile("ERROR from checkConfiguration " + ex);
            }
        }

        /// <summary>
        /// Read Password entered by user and store it in a string variable
        /// </summary>
        /// <returns>Password in String</returns>
        private static string ReadPassword()
        {
            string pwd = string.Empty;
            ConsoleKeyInfo keyInfo = new ConsoleKeyInfo();
            while (keyInfo.Key != ConsoleKey.Enter)
            {

                keyInfo = Console.ReadKey(true);
                if (keyInfo.Key != ConsoleKey.Enter)
                    pwd += keyInfo.KeyChar.ToString();
            }
            return pwd;
        }


        /// <summary>
        /// get User ID by passing user's login name
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        private static int GetUserId(ClientContext clientContext, string userName)
        {
            var web = clientContext.Web;
            var theUser = web.EnsureUser(userName);
            clientContext.Load(theUser);
            clientContext.ExecuteQuery();

            return theUser.Id;
        }


        /// <summary>
        /// Initialize configuration
        /// </summary>
        /// <param name="configParams"></param>
        private static void initializeConfiguration(Dictionary<string, string> configParams)
        {

            _siteMode = configParams.Where(x => x.Key == "siteMode").FirstOrDefault().Value;
            _domain = configParams.Where(x => x.Key == "domain").FirstOrDefault().Value;
            _emailDomain1 = configParams.Where(x => x.Key == "emailDomain1").FirstOrDefault().Value;
            _emailDomain2 = configParams.Where(x => x.Key == "emailDomain2").FirstOrDefault().Value;
            _logFilePath = configParams.Where(x => x.Key == "logFilePath").FirstOrDefault().Value;
            _siteUrl = configParams.Where(x => x.Key == "siteUrl").FirstOrDefault().Value;
            _userName = configParams.Where(x => x.Key == "userName").FirstOrDefault().Value;
            _password = SecureTextHelper.Decrypt(configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value);
            //_password = configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value;
            _siteCollectionURL = configParams.Where(x => x.Key == "siteCollectionURL").FirstOrDefault().Value;
            _clarityAdmin = configParams.Where(x => x.Key == "clarityAdmin").FirstOrDefault().Value;
            _clarityAdminPassword = configParams.Where(x => x.Key == "clarityAdminPassword").FirstOrDefault().Value;
            _nsqlProjectDataQuery = configParams.Where(x => x.Key == "nsqlProjectDataQuery").FirstOrDefault().Value;
            _nsqlTeamMembersQuery = configParams.Where(x => x.Key == "nsqlTeamMembersQuery").FirstOrDefault().Value;
            _partitionCode = configParams.Where(x => x.Key == "partitionCode").FirstOrDefault().Value;
            _clarityServerURL = configParams.Where(x => x.Key == "clarityServerURL").FirstOrDefault().Value;
            _siteTemplateId = configParams.Where(x => x.Key == "siteTemplateId").FirstOrDefault().Value;
            _ownerGroupId = configParams.Where(x => x.Key == "ownerGroupId").FirstOrDefault().Value;
            _memberGroupId = configParams.Where(x => x.Key == "memberGroupId").FirstOrDefault().Value;
            _visitorGroupId = configParams.Where(x => x.Key == "visitorGroupId").FirstOrDefault().Value;
            _errorAdmins = configParams.Where(x => x.Key == "ErrorAdmins").FirstOrDefault().Value;

        }

        /// <summary>
        /// Write logs to text file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string WriteToLogFile(string data)
        {
            try
            {

                FileStream fs = new FileStream(_logFilePath + "logs.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("[" + DateTime.Now + "]" + data);
                sw.Close();
                fs.Close();
                return "log written successfully";
            }
            catch
            {
                return "failed to write log";
            }
        }


    }
}
