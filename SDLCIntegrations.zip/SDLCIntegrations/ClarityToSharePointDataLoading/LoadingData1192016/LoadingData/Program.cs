﻿using LoadingData.Classes;
using LoadingData.Classes.Helpers;
using Microsoft.SharePoint.Client;
using System;
using System.Configuration;
using System.Net;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using SP = Microsoft.SharePoint.Client;

namespace LoadingData
{
    class Program
    {
        static string message;
       
        static string _siteUrl = string.Empty;
        static string _userName = string.Empty;
        static string _password = string.Empty;
        static string sessionId = string.Empty;
        static string _emailsListName = string.Empty;
        
        static string _adminEmailIds = string.Empty;
        static string _errorAdmins = string.Empty;
        static string _logFilePath = string.Empty;

         /// <summary>
        /// The Main method.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            
            OnDemandHelper objOnDemand = new OnDemandHelper();
            // Reading Xml file to get the input parameters like Url, User Name
            checkConfiguration();
            ConfigHelper config = XmlHelper.ParseConfigXML();
            initializeConfiguration(config.configParams);
            O365AuthHelper O365Auth = new O365AuthHelper(_siteUrl, _userName, _password);
            var targetSite = new Uri(_siteUrl);
            using (ClientContext clientContext = new ClientContext(targetSite))
            {
                try
                {
                    // Connecting to O365 Site
                    SharePointOnlineCredentials onlineCredentials = O365Auth.getOnlineCredentials();
                    clientContext.Credentials = onlineCredentials;
                    Web oWebsite = clientContext.Web;

                    // The below objects used to connect to OnDemand Dev Clarity
                    ProjectService.Auth psAuth = new ProjectService.Auth();
                    ProjectService.DFS_SP_PRJ_SFTPQueryResult objPrjQueryResults = new ProjectService.DFS_SP_PRJ_SFTPQueryResult();
                    ProjectService.DFS_SP_PRJ_SFTPQuery objPrjDataQuery = new ProjectService.DFS_SP_PRJ_SFTPQuery();
                    ProjectService.DFS_SP_PRJ_SFTPQueryPortClient objPrjClient = new ProjectService.DFS_SP_PRJ_SFTPQueryPortClient();
                                         
                    // Passing OD credentials to Service objects
                    psAuth.Username = ConfigurationManager.AppSettings["vClarityAdmin"];
                    psAuth.Password = ConfigurationManager.AppSettings["vClarityAdminPassword"];

                    sessionId = objPrjClient.WrappedLogin(psAuth.Username, psAuth.Password, "clarity");

                    // Mentioning the ID of the Query
                    objPrjDataQuery.Code = ConfigurationManager.AppSettings["nsqlProjectDataQuery"];

                    // Retrieving the data from OnDemand query through service
                    objPrjQueryResults = objPrjClient.Query(psAuth, objPrjDataQuery);

                    
                    // Loop to reading Project information one by one from OnDemand
                    for (int i = 0; i <= objPrjQueryResults.Records.Count() - 1; i++)
                    {
                        string vPrjID = objPrjQueryResults.Records[i].prj_id;
                        string vPrjName = objPrjQueryResults.Records[i].prj_name;
                         
                        string vPrjManager = objPrjQueryResults.Records[i].prj_mgr;
                                                
                        string vPrjMgrEmail = objPrjQueryResults.Records[i].prj_mgr_email;


                        bool isExistingSite = IsExistingSite(oWebsite, clientContext, ConfigurationManager.AppSettings["SiteCollectionURL"] + vPrjID);
                        if (isExistingSite)
                        {
                            updateProjectSiteDetails(onlineCredentials, ConfigurationManager.AppSettings["SiteCollectionURL"] + vPrjID, vPrjID, vPrjName, vPrjManager);
                            updateTeamAccessDetails(onlineCredentials);
                            
                            
                        }
                        else
                        {
                           bool isSiteCreationSuccessful= createNewProjectSite(onlineCredentials, ConfigurationManager.AppSettings["SiteCollectionURL"], vPrjID, vPrjName, vPrjManager);
                           if (isSiteCreationSuccessful)
                           {
                               //updateSharePointURLinClarity(ConfigurationManager.AppSettings["SiteCollectionURL"] + vPrjID);
                           }
                            
                        }
                        
                     }
                    
                  
                    
                    //Console.Write(newWeb.Title); 
                                    

                }
                catch (Exception ex)
                {
                    Console.Write("Not Successful."+"ERROR: "+ex);

                }
            }

        }
        /// <summary>
        /// This function to create a new project
        /// </summary>
        /// <param name="onlineCredentials"></param>
        /// <param name="mainURL"></param>
        /// <param name="vPrjID"></param>
        /// <param name="vPrjName"></param>
        /// <param name="vPrjManager"></param>
        private static bool createNewProjectSite(SharePointOnlineCredentials onlineCredentials, string mainURL, string vPrjID, string vPrjName, string vPrjManager)
        {
            bool res = false;
            WebCreationInformation webCreation = new WebCreationInformation();
            webCreation.Url = vPrjID;
            ClientContext clientContext = new ClientContext(mainURL);
            clientContext.Credentials = onlineCredentials;
            
            webCreation.Title = vPrjID + " " + vPrjName;
            webCreation.UseSamePermissionsAsParentSite = false;
            webCreation.WebTemplate = ConfigurationManager.AppSettings["siteTemplateId"].ToString();
            Web newWeb = clientContext.Web.Webs.Add(webCreation);
            clientContext.Load(newWeb, w => w.Title);
            
            clientContext.ExecuteQuery();


            // Retrieing SharePoint Group information
            Group ownerGroup = clientContext.Web.SiteGroups.GetById(Convert.ToInt32(ConfigurationManager.AppSettings["ownerGroupId"]));

            //create the user object
            UserCreationInformation teamMember = new UserCreationInformation();
            //User member = newWeb.EnsureUser(ConfigurationManager.AppSettings["userEmail"]);
            User member = newWeb.EnsureUser("rpatel4@discover.com");

            //newWeb.BreakRoleInheritance(false, true);

            //add it to the group 
            ownerGroup.Users.AddUser(member);
            clientContext.ExecuteQuery();
            Console.WriteLine("Project's Site creation completed successfully. ");
            return res = true;
                        
        }
        
        private static void updateSharePointURLinClarity(string siteURL)
        {
            string strEnv = null;
            string strAuth = null;
            System.Net.WebClient manualWebClient = new System.Net.WebClient();
            manualWebClient.Headers.Add("Content-Type", "application/soap+xml;  charset=utf-8");
            manualWebClient.Headers.Add("SOAPAction", "http://www.niku.com/xog/Object/WriteCustomObjectInstance");
            if (string.IsNullOrEmpty(sessionId))
            {

                strAuth = " <obj:Username>" + ConfigurationManager.AppSettings["vClarityAdmin"] + "</obj:Username> <obj:Password>" + ConfigurationManager.AppSettings["vClarityAdminPassword"] + "</obj:Password>";
            }
            else
            {
                strAuth = " <obj:SessionID>" + sessionId + "</obj:SessionID> ";
            }
           // strEnv1 = "<soapenv:Envlope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:obj=\"http://www.niku.com/xog/Object\">" + System.Environment.NewLine + " <soapenv:Header> " + System.Environment.NewLine + "<obj:Auth> " + System.Environment.NewLine + "<obj:TenantID>clarity</obj:TenantID>" + System.Environment.NewLine + strAuth + System.Environment.NewLine + "</obj:Auth>" + System.Environment.NewLine + "</soapenv:Header>" + System.Environment.NewLine + "<soapenv:Body>" + System.Environment.NewLine + "      <obj:WriteCustomObjectInstance>" + System.Environment.NewLine + "   <NikuDataBus xsi:noNamespaceSchemaLocation=\"../xsd/nikuxog_project.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" + System.Environment.NewLine + "\t<Header action=\"write\" externalSource=\"NIKU\" objectType=\"customObjectInstance\" version=\"13.3.0.286\">" + System.Environment.NewLine + "\t\t<args name=\"overrideAutoNumbering\" value=\"false\"/>" + System.Environment.NewLine + "\t</Header>" + System.Environment.NewLine + "     <customObjectInstances objectCode=\"cg_rally_staging\">" + System.Environment.NewLine + "               <instance instanceCode=\"" + cstgCode + "\" objectCode=\"cg_rally_staging\">" + System.Environment.NewLine + "       \t     <CustomInformation>" + System.Environment.NewLine + "      \t\t          <ColumnValue name=\"partition_code\">" + cstgCode + "</ColumnValue>" + System.Environment.NewLine + "                     <ColumnValue name=\"cg_inv_doc_url\">true</ColumnValue>" + System.Environment.NewLine + "                  </CustomInformation>" + System.Environment.NewLine + "               </instance>" + System.Environment.NewLine + "            </customObjectInstances>" + System.Environment.NewLine + "        </NikuDataBus>" + System.Environment.NewLine + "     </obj:WriteCustomObjectInstance>" + System.Environment.NewLine + "   </soapenv:Body>" + System.Environment.NewLine + "</soapenv:Envelope>";

           // strEnv = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:obj=\"http://www.niku.com/xog/Object\">" + System.Environment.NewLine + " <soapenv:Header> " + System.Environment.NewLine + "<obj:Auth> " + System.Environment.NewLine + "<obj:TenantID>clarity</obj:TenantID>" + System.Environment.NewLine + strAuth + System.Environment.NewLine + "</obj:Auth>" + System.Environment.NewLine + "</soapenv:Header>" + System.Environment.NewLine + "<soapenv:Body>" + System.Environment.NewLine + "      <obj:WriteProject>" + System.Environment.NewLine + "   <NikuDataBus xsi:noNamespaceSchemaLocation=\"../xsd/nikuxog_project.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" + System.Environment.NewLine + "\t<Header action=\"write\" externalSource=\"NIKU\" objectType=\"project\" version=\"13.3.0.286\">" + System.Environment.NewLine +"<Projects>"+ System.Environment.NewLine+"<Project projectID=\"" + l_project_code + "\" name=\"" + l_project_name + "\" > " + System.Environment.NewLine + " <Tasks>" + System.Environment.NewLine + "                  <Task taskID=\"" + l_task_id + "\" name=\"" + l_task_name + "\" outlineLevel=\"" + l_outline_level + "\" start=\"" + l_task_start + "\" finish=\"" + l_task_end + "\">" + System.Environment.NewLine + "                \t\t<Assignments>" + System.Environment.NewLine + "               \t\t\t<TaskLabor start=\"" + l_task_start + "\" finish=\"" + l_task_end + "\" resourceID=\"" + l_res_uname + "\" ></TaskLabor> " + System.Environment.NewLine + "              \t\t\t</Assignments>" + System.Environment.NewLine + "                 </Task>" + System.Environment.NewLine + "              </Tasks>" + System.Environment.NewLine + "               </Project>" + System.Environment.NewLine +"\t<CustomInformation>" + System.Environment.NewLine + " \t\t <ColumnValue name=\"partition_code\">" + cstgCode + "</ColumnValue>" +System.Environment.NewLine + "  <ColumnValue name=\"cg_inv_doc_url\">" + cstgCode +"</ColumnValue>" + System.Environment.NewLine + " </CustomInformation>" + System.Environment.NewLine +" </Projects>" + System.Environment.NewLine + "    </NikuDataBus>" + System.Environment.NewLine + "     </obj:WriteProject>" + System.Environment.NewLine + "   </soapenv:Body>" + System.Environment.NewLine + "</soapenv:Envelope>";
           
        }
        
        /// <summary>
        /// This function will updates the 
        /// </summary>
        /// <param name="onlineCredentials"></param>
        /// <param name="subSiteURL"></param>
        private static void updateProjectSiteDetails(SharePointOnlineCredentials onlineCredentials, string subSiteURL, string vPrjID, string vPrjName, string vPrjManager)
        {
            
            // Connecting to existing subsite
            ClientContext subSiteContext = new ClientContext(subSiteURL);

            subSiteContext.Credentials = onlineCredentials;

            Web web = subSiteContext.Web;
            web.Title = vPrjID + " " + vPrjName;
            // oWebsite.Description = "New Description";

            // Retrieing SharePoint Group information
            Group oOwnerGroup = subSiteContext.Web.SiteGroups.GetById(Convert.ToInt32(ConfigurationManager.AppSettings["ownerGroupId"]));

            // Creation object for User
           // UserCreationInformation teamMember = new UserCreationInformation();
            //User member = web.EnsureUser(vPrjManager);
            User member = web.EnsureUser("rpatel4@discover.com");

            // Removing access of existing user on the site.
            oOwnerGroup.Users.AddUser(member);
            web.Update();

            // Execute the query to server.
            subSiteContext.ExecuteQuery();
            Console.WriteLine("Project Site details updated successfully.");
            
        }
        /// <summary>
        /// This function updates the Team members access details of a Project Site.
        /// </summary>
        private static void updateTeamAccessDetails(SharePointOnlineCredentials onlineCredentials)
        {
            // Objects to connect with TeamMembersService
            TeamMembersService.Auth tmAuth = new TeamMembersService.Auth();
            TeamMembersService.CG_SP_TEAM_SECQueryResult objTmQueryResults = new TeamMembersService.CG_SP_TEAM_SECQueryResult();
            TeamMembersService.CG_SP_TEAM_SECQuery objTmDataQuery = new TeamMembersService.CG_SP_TEAM_SECQuery();
            TeamMembersService.CG_SP_TEAM_SECQueryPortClient objTmClient = new TeamMembersService.CG_SP_TEAM_SECQueryPortClient();

            tmAuth.Username = ConfigurationManager.AppSettings["vClarityAdmin"];
            tmAuth.Password = ConfigurationManager.AppSettings["vClarityAdminPassword"];
            sessionId = objTmClient.WrappedLogin(tmAuth.Username, tmAuth.Password, "clarity");
            objTmDataQuery.Code = ConfigurationManager.AppSettings["nsqlTeamMembersQuery"];
            objTmQueryResults = objTmClient.Query(tmAuth, objTmDataQuery);

            for (int i = 0; i <= objTmQueryResults.Records.Count() - 1; i++)
            {
                string PRJID = objTmQueryResults.Records[i].prj_id;
                
                string TEMAIL = objTmQueryResults.Records[i].team_email;
                string Perm = objTmQueryResults.Records[i].sp_permission;
                
                // Connecting to existing subsite
                ClientContext subSiteContext = new ClientContext(ConfigurationManager.AppSettings["SiteCollectionURL"]+PRJID);
                subSiteContext.Credentials = onlineCredentials;
                Web web = subSiteContext.Web;
                

                // Creation object for User
                //UserCreationInformation teamMember = new UserCreationInformation();
                //User teamMember = web.EnsureUser(TEMAIL);
                User teamMember = web.EnsureUser("stallur@discover.com");

                
                //Check the Permission details of the user
                if (objTmQueryResults.Records[i].sp_permission == "full")
                {
                    Group oOwnerGroup = subSiteContext.Web.SiteGroups.GetById(Convert.ToInt32(ConfigurationManager.AppSettings["ownerGroupId"]));
                    oOwnerGroup.Users.AddUser(teamMember);
                }
                else if (objTmQueryResults.Records[i].sp_permission == "Contribute")
                {
                    Group omemberGroup = subSiteContext.Web.SiteGroups.GetById(Convert.ToInt32(ConfigurationManager.AppSettings["memberGroupId"]));
                    omemberGroup.Users.AddUser(teamMember);
                }
                else if (objTmQueryResults.Records[i].sp_permission == "Read")
                {
                    Group ovisitorGroup = subSiteContext.Web.SiteGroups.GetById(Convert.ToInt32(ConfigurationManager.AppSettings["visitorGroupId"]));
                    ovisitorGroup.Users.AddUser(teamMember);
                }

                web.Update();

                // Execute the query to server.
                subSiteContext.ExecuteQuery();
                Console.WriteLine("Team members details updated successfully.");
                
            }

            //End of Team service
        }
       
        /// <summary>
        /// This function is used to check; whether current site is existing or not
        /// </summary>
        /// <param name="oWebsite"></param>
        /// <param name="clientContext"></param>
        /// <param name="siteURL"></param>
        /// <returns></returns>
        private static bool IsExistingSite(Web oWebsite, ClientContext clientContext, string siteURL)
        {
            bool res=false;
            clientContext.Load(oWebsite, website => website.Webs, website => website.Title);
            clientContext.ExecuteQuery();
            foreach (Web existingWebsite in oWebsite.Webs)
            {
                if (existingWebsite.Url.Equals(siteURL))
                {
                    res = true;


                }
            }
            return res;
            
        }
        /// <summary>
        /// Check Configuration and prompt user if anything is blank
        /// </summary>
        private static void checkConfiguration()
        {
            if (ConfigHelper.IsConfigured)
            {
                Console.WriteLine("Already Configured. Moving On...");
            }
            else
            {
                Console.WriteLine("App not configured. Please specify below details to configure App.");
                //LogHelper.sb.AppendLine("App not configured. Getting Configuration Details");
                XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
                foreach (KeyValuePair<string, string> configString in ConfigHelper.UnConfiguredStrings)
                {
                    Console.WriteLine("Enter " + configString.Key + ": ");
                    XElement configElement = xDoc.Descendants("param").Where(x => x.Attribute("key").Value == configString.Value).FirstOrDefault();
                    if (configString.Key == "Password")
                        configElement.SetAttributeValue("value", SecureTextHelper.Encrypt(ReadPassword()));
                    else
                        configElement.SetAttributeValue("value", Console.ReadLine());
                }
                xDoc.Save(Constants.CONFIG_XML_PATH);
                Console.WriteLine("Configuration Done!!");
                //LogHelper.sb.AppendLine("Configuration Done!!");
            }
        }

        /// <summary>
        /// Read Password entered by user and store it in a string variable
        /// </summary>
        /// <returns>Password in String</returns>
        private static string ReadPassword()
        {
            string pwd = string.Empty;
            ConsoleKeyInfo keyInfo = new ConsoleKeyInfo();
            while (keyInfo.Key != ConsoleKey.Enter)
            {

                keyInfo = Console.ReadKey(true);
                if (keyInfo.Key != ConsoleKey.Enter)
                    pwd += keyInfo.KeyChar.ToString();
            }
            return pwd;
        }


        /// <summary>
        /// get User ID by passing user's login name
        /// </summary>
        /// <param name="clientContext"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        private static int GetUserId(ClientContext clientContext, string userName)
        {
            var web = clientContext.Web;
            var theUser = web.EnsureUser(userName);
            clientContext.Load(theUser);
            clientContext.ExecuteQuery();

            return theUser.Id;
        }


        /// <summary>
        /// Initialize configuration
        /// </summary>
        /// <param name="configParams"></param>
        private static void initializeConfiguration(Dictionary<string, string> configParams)
        {
            //LogHelper.sb.AppendLine("Entering Method initializeConfiguration()");
            //_logFilePath = configParams.Where(x => x.Key == "logFilePath").FirstOrDefault().Value;
            _siteUrl = configParams.Where(x => x.Key == "siteUrl").FirstOrDefault().Value;
            _userName = configParams.Where(x => x.Key == "userName").FirstOrDefault().Value;
            _password = SecureTextHelper.Decrypt(configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value);
            //_password = configParams.Where(x => x.Key == "pwd").FirstOrDefault().Value;

           
            _errorAdmins = configParams.Where(x => x.Key == "ErrorAdmins").FirstOrDefault().Value;
        }

        /// <summary>
        /// Write logs to text file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string WriteToLogFile(string data)
        {
            try
            {
                FileStream fs = new FileStream(_logFilePath + "Logs.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("[" + DateTime.Now.ToLongTimeString() + "]" + data);
                sw.Close();
                fs.Close();
                return "log written successfully";
            }
            catch
            {
                return "failed to write log";
            }
        }


    }
}
