﻿/**
 * @Author: ANIL KUMAR YERROJU
 * @Created on: 07/19/2017
 * @Last Modified: 12/20/2017.
 * @Reason for Modification: Implemented DEC-2017 Changes/Enhancements.
 *							 Commented Date fileds
 *							 Modified the Currency format.
 *							 Implemented new GL drop-downs and new fields for Financial planner and Provisioner		  		
 * @Application: ADC Approval Management Automation.
 * @Page Name: VIEW REQUEST PAGE.
 * @summary: This page used to view the submitted request details and
     use can take appropriate actions based on the status of the request.
 *		     
 **/


var CRUDobj = DDOCS.ListItemManager();
var ViewRequest = {};
ViewRequest.ViewRequestlistName = 'ADC Approval Requests';
ViewRequest.ViewTaksListName = 'ADC Approval Tasks';
ViewRequest.sowStatus = "SOW Status";
ViewRequest.GLListName = "GL List";
ViewRequest.ProvisionerExplanationList = "ProvisionerExplanation";
ViewRequest.SDate;
ViewRequest.EDate;
ViewRequest.FinancialPlanner="FinancialPlanner";
ViewRequest.Provisioner="Provisioner";
//ViewRequest.projectListName = 'Projects';

ViewRequest.CurrentUser = null;

ViewRequest.DraftedRequestData = {};//For the requests which are in  draft mode

/*ViewRequest.backButtonHtml = '<div class="groupbutton">' +
						            '<input type="reset" onclick="history.back();" class="reset" value="Back" name="Submit2">' +
						    	'</div>'; */


ViewRequest.init = function () {

 
    //Hide Main blocks
    $('.padding-block').hide(); $('#groupbutton').hide();
	

		$('#div-additionalVendorPanel1').hide();
		$('#div-totalAmount').hide();
		$('#div-finPlannerControls').hide();
		
		$('#div-FinPlannerGLProposal').hide();
	    $('#div-FinPlannerGLProposalLabel').hide();
	    $('#div-ProvisionerGLDecisionLabel').hide();
  	    $('#div-ProvisionerExplanationLabel').hide();
  	    $('#div-ProvisionerGLDecision').hide();
  	    $('#div-ProvisionerExplanation').hide();

	    
		
		//$('#div-vendorName2').hide();
		//$('#div-rate2').hide();
		//$('#div-headCount2').hide();
		
		//$('#div-additionalVendorPanel2').hide();
		$('#div-additionalVendorPanel3').hide();
		$('#div-sowStatus').hide();
		$('#div-sowStatusLabel').hide();
		$('#div-sowNumber').hide();
		$('#div-sowNumberLabel').hide();
		$('#div-isPlanned').hide();
 	 	$('#div-isPlannedLabel').hide();
		
		//$('#div-planIDLabel').hide();
		//$('#div-toNumberLabel').hide();
		$('#div-planID').hide();
		//$('#div-toNumber').hide();
				
		$('#div-isProvisioned').hide();
       	$('#div-isProvisionedLabel').hide();

		
		$('#div-finPlannerComments').hide();
		$('#div-finPlannerCommentsLabel').hide();
       	
       
        $('#div-nonRequestorControls1').hide(); 
 	    $('#div-nonRequestorControls2').hide(); 
	   // $('#div-nonRequestorControls3').hide(); 
      		
		// Hide buttons
		$('#requestEdit').hide();
		$('#requestApprove').hide();
  	 	$('#requestReject').hide();  	 	
  	 	$('#requestReturn').hide();
  	 	$('#requestSubmit').hide();
    if (document.URL.indexOf("?") >= 0) {
        ViewRequest.RequestID = getQueryStringParameter("RequestID");
        if (getQueryStringParameter("Home"))
            ViewRequest.IsFromAllRequests = true;
        $('.requestId').text(ViewRequest.RequestID);
		 ViewRequest.GetRequestDetails(ViewRequest.RequestID);

        ExecuteOrDelayUntilScriptLoaded(ViewRequest.load, "sp.js");
        
        }
            
		ViewRequest.populateSelectCAMLLookup('#div-sowStatus select', ViewRequest.sowStatus, 'Title', 'null');  
        ViewRequest.populateSelectCAMLLookup('#div-ProvisionerExplanation select', ViewRequest.ProvisionerExplanationList, 'Title', 'null');   
		  
       
  	 	

		
};

// Not used this code.
ViewRequest.load = function () {
   // ViewRequest.GetRequestDetails(ViewRequest.RequestID);
    
    
};


ViewRequest.GetRequestDetails = function (RequestId) {
    var dfd = $.Deferred();
    var ctx = SP.ClientContext.get_current();
    var ApprovalList = ctx.get_web().get_lists().getByTitle(ViewRequest.ViewRequestlistName);
    var RequestItem = ApprovalList.getItemById(RequestId);
    //ViewRequest.isRequestInReview = false;

    ctx.load(RequestItem);
    ctx.executeQueryAsync(
		function (sender, args) {

		    var reqID = RequestItem.get_item("ID");
		    console.log("Req Title -" + RequestItem.get_item("Title"));
	        ViewRequest.DraftedRequestData["reqID"] = reqID ;
	        ViewRequest.DraftedRequestData["Status"] = RequestItem.get_item("Status");
  	        ViewRequest.DraftedRequestData["Requestor"] = RequestItem.get_item("Author").get_lookupValue();
	        ViewRequest.DraftedRequestData["RequestorId"]= RequestItem.get_item("Author").get_lookupId();
	        ViewRequest.DraftedRequestData["RequestedDate"] = RequestItem.get_item("Created");
		    ViewRequest.DraftedRequestData["VP"] = RequestItem.get_item("VP").get_lookupValue();
			ViewRequest.DraftedRequestData["Director"] = RequestItem.get_item("Director").get_lookupValue();
			ViewRequest.DraftedRequestData["DirectorId"]= RequestItem.get_item("Director").get_lookupId();
			ViewRequest.DraftedRequestData["Manager"] = RequestItem.get_item("Manager").get_lookupValue();
   		    ViewRequest.DraftedRequestData["CostCenter"] = RequestItem.get_item("Title");
   		    ViewRequest.DraftedRequestData["CostCenterName"] = RequestItem.get_item("CostCenterName");
			ViewRequest.DraftedRequestData["CostCenterDirector"] = RequestItem.get_item("CostCenterDirector").get_lookupValue();
   		    ViewRequest.DraftedRequestData["CostCenterDirectorId"]= RequestItem.get_item("CostCenterDirector").get_lookupId();
   		    ViewRequest.DraftedRequestData["CCFinancialPlanner"] = RequestItem.get_item("CCFinancialPlanner").get_lookupValue();
		    ViewRequest.DraftedRequestData["CCFinancialPlannerId"]= RequestItem.get_item("CCFinancialPlanner").get_lookupId();
		    ViewRequest.DraftedRequestData["CostCenterVP"] = RequestItem.get_item("CostCenterVP").get_lookupValue();
		    ViewRequest.DraftedRequestData["CostCenterVPId"]= RequestItem.get_item("CostCenterVP").get_lookupId();

			ViewRequest.DraftedRequestData["ProjectName"] = RequestItem.get_item("Clarity_x0020_ProjectName");
   		    ViewRequest.DraftedRequestData["ProjectNumber"] = RequestItem.get_item("Clarity_x0020_ProjectID");
		    ViewRequest.DraftedRequestData["WorkType"] = RequestItem.get_item("Work_x0020_Type");
		    ViewRequest.DraftedRequestData["GLName"] = RequestItem.get_item("GLName");
    		ViewRequest.DraftedRequestData["TONumber"] = RequestItem.get_item("TO_x0020_Number");		   
   		    ViewRequest.DraftedRequestData["PlanID"] = RequestItem.get_item("Plan_x0020_ID");
		  
		    ViewRequest.DraftedRequestData["HeadCount"] = RequestItem.get_item("Head_x0020_Count");
		    ViewRequest.DraftedRequestData["VendorName"] = RequestItem.get_item("Vendor_x0020_Name");
   		    ViewRequest.DraftedRequestData["Rate"] = RequestItem.get_item("Rate");
   		    
   		    // Commented as per DEC-2017 Changes 
   		    //ViewRequest.DraftedRequestData["StartDate"] = RequestItem.get_item("Start_x0020_Date");
   		   //ViewRequest.DraftedRequestData["EndDate"] = RequestItem.get_item("End_x0020_Date");
   		   //ViewRequest.DraftedRequestData["Duration"] = RequestItem.get_item("Duration"); 
   		   
		   // Added as per DEC-2017 Changes   		    
   		   ViewRequest.DraftedRequestData["Duration"] = RequestItem.get_item("DurationVendor1");   		    
   		    ViewRequest.DraftedRequestData["EstMonthlySpend"] = RequestItem.get_item("Estimated_x0020_Monthly_x0020_Sp");
   		    ViewRequest.DraftedRequestData["Amount"] = RequestItem.get_item("Amount");
   		    
   		    //Additional Vendor Details added on 10/10/2017
   		    ViewRequest.DraftedRequestData["HasAdditionalVendor"] = RequestItem.get_item("HasAdditionalVendor");
   		    ViewRequest.DraftedRequestData["HeadCount2"] = RequestItem.get_item("Head_x0020_Count2");
		    ViewRequest.DraftedRequestData["VendorName2"] = RequestItem.get_item("Vendor_x0020_Name2");
   		    ViewRequest.DraftedRequestData["Rate2"] = RequestItem.get_item("Rate2");
   		    
   		    //// Commented as per DEC-2017 Changes 
   		    //ViewRequest.DraftedRequestData["StartDate2"] = RequestItem.get_item("Start_x0020_Date2");
   		    //ViewRequest.DraftedRequestData["EndDate2"] = RequestItem.get_item("End_x0020_Date2");
   		   // ViewRequest.DraftedRequestData["Duration2"] = RequestItem.get_item("Duration2"); 
   		   
   		   // Added as per DEC-2017 Changes     		    
   		    ViewRequest.DraftedRequestData["Duration2"] = RequestItem.get_item("DurationVendor2");   		    
   		    ViewRequest.DraftedRequestData["EstMonthlySpend2"] = RequestItem.get_item("EstMonthlySpend2");
   		    ViewRequest.DraftedRequestData["Amount2"] = RequestItem.get_item("Amount2");

   		    ViewRequest.DraftedRequestData["TotalAmount"] = RequestItem.get_item("TotalAmount");
   		    ViewRequest.DraftedRequestData["RequestorComments"] = RequestItem.get_item("Requestor_x0020_Comments");
	  		ViewRequest.DraftedRequestData["FinPlannerComments"] = RequestItem.get_item("Financial_x0020_Planner_x0020_Co");
	  		
	  		// Added on 12/18/2017 for PSM extra fields.
	  		ViewRequest.DraftedRequestData["FinPGLProposal"] = RequestItem.get_item("FinPGLProposal");
	  		ViewRequest.DraftedRequestData["ProvisionerGLDecision"] = RequestItem.get_item("ProvisionerGLDecision");	  		
	  		ViewRequest.DraftedRequestData["ProvisionerExplanation"] = RequestItem.get_item("ProvisionerExplanation");
	  		
   		    
   		    // Commented all PSM realted fields
	  	 	ViewRequest.DraftedRequestData["HeadCountPlan"] = RequestItem.get_item("Headcount_x0020_Plan_x0020_Updat");
		    ViewRequest.DraftedRequestData["ClarityUpdated"] = RequestItem.get_item("Clarity_x0020_Updated");
		    ViewRequest.DraftedRequestData["IsPlanned"] = RequestItem.get_item("IsPlanned");
  		    ViewRequest.DraftedRequestData["IsProvisioned"] = RequestItem.get_item("IsProvisioned");
		    ViewRequest.DraftedRequestData["SOWStatus"] = RequestItem.get_item("SOW_x0020_Status");		    		    	  	 	
		    ViewRequest.DraftedRequestData["SOWNumber"] = RequestItem.get_item("SOW_x0020_Number"); 

		    
		  
		   ViewRequest.onload(reqID);
		       

		    dfd.resolve();
		},
		function (sender, args) {
		    dfd.reject();
		    console.log("Page:'ViewRequest.aspx' Method:'ViewRequest.GetRequestDetails.' Error:" + args.get_message());

		});
    return dfd.promise();


};//End of GetRequestDetails


ViewRequest.onload = function (requestID) {

    ViewRequest.CurrentDate = new Date();
	ViewRequest.CurrentDate.setHours(0,0,0,0);
	var dd, mm, y;
    var dfdCurrentloggedInUser = SPUser.getCurrent();
    dfdCurrentloggedInUser.done(function (currentUser) {
    
    
    			 // Provisioner PSM's View
   			     IsCurrentUserMemberOfGroup("ADC-Provisioner-PSM", function (isCurrentUserInGroupPSM) {
   				 if(isCurrentUserInGroupPSM&&ViewRequest.DraftedRequestData.Status == 'Approved')
  				 {  //Main Fields
    			 	$('.padding-block').show(); $('#groupbutton').show();
    			 	$('#div-finPlannerControls').show();
					$('#div-FinPlannerGLProposalLabel').show();
					$('#div-ProvisionerGLDecision').show();
  	   				$('#div-ProvisionerExplanation').show();
  	   				ViewRequest.populateSelectCAMLLookup('#div-ProvisionerGLDecision select', ViewRequest.GLListName, 'Title', ViewRequest.Provisioner); 

					$('#div-finPlannerControls').show();
     				$('#div-nonRequestorControls1').show();
     				$('#div-finPlannerCommentsLabel').show(); 
	 				$('#div-nonRequestorControls2').show(); 
	 				//$('#div-nonRequestorControls3').show(); 
      				//$('#div-headCountPlan').show();
      				//$('#div-clarityUpdated').show();
					$('#div-sowNumber').show();
       				$('#div-isProvisioned').show();
       				$('#div-planIDLabel').show();
       				//$('#div-planID').show();
       				$('#div-isPlannedLabel').show();
					$('#div-toNumber').show();
					//$('#div-sowStatusLabel').show();
					$('#div-sowStatus').show();
					
	  				$('#requestSubmit').show();
    			}
    			else if (isCurrentUserInGroupPSM&&ViewRequest.DraftedRequestData.Status == 'Closed')
    			{   //Main Fields
    			 	$('.padding-block').show(); $('#groupbutton').show();
					$('#div-finPlannerControls').show();
					$('#div-FinPlannerGLProposalLabel').show();
					$('#div-ProvisionerGLDecisionLabel').show();
  	   				$('#div-ProvisionerExplanationLabel').show();
    			    $('#div-nonRequestorControls1').show(); 
	 				$('#div-nonRequestorControls2').show();
			 		//$('#div-nonRequestorControls3').show(); 
	 				$('#div-finPlannerCommentsLabel').show(); 
	 				//$('#div-headCountPlanLabel').show();
      				//$('#div-clarityUpdatedLabel').show();
					$('#div-sowNumberLabel').show();
       				$('#div-isProvisionedLabel').show();
       				$('#div-planIDLabel').show();
       				$('#div-isPlannedLabel').show();
					$('#div-toNumberLabel').show();
					$('#div-sowStatusLabel').show();    			
    			}
    	else
    	{
    	  
    // Financial Planner's View.
    IsCurrentUserMemberOfGroup("ADC-FinancialPlanners", function (isCurrentUserInGroupFinPlanner) {
    // Requestor's View
	 if (ViewRequest.DraftedRequestData.RequestorId == currentUser.get_id() && ViewRequest.DraftedRequestData.Status == 'Open') 
	 	{ 
	 	 //Main Fields
    	$('.padding-block').show(); $('#groupbutton').show();
	 	$('#requestEdit').show(); 
	 	$('#requestSubmit').show();
	 		 	
 		}
 		 
 	 else if (ViewRequest.DraftedRequestData.RequestorId != currentUser.get_id() &&(ViewRequest.DraftedRequestData.Status == 'Open'||ViewRequest.DraftedRequestData.Status == 'Returned'))
 	 {
 	  $('.padding-block').hide(); 
	  $('#groupbutton').hide();
	  $('.padding-block').html('Authorized person can view the request details').show();
 	 }
 	 else if (ViewRequest.DraftedRequestData.RequestorId == currentUser.get_id() &&ViewRequest.DraftedRequestData.Status == 'Returned')
	  {
	   //Main Fields
       $('.padding-block').show(); $('#groupbutton').show();
 	   $('#requestEdit').show(); 
	   $('#requestSubmit').show();
	   $('#div-isPlannedLabel').show();
	  	    if(ViewRequest.DraftedRequestData.FinPlannerComments)
	 		 {	  $('#div-finPlannerCommentsLabel').show();
	 		  }	  
	  }  
   	 else if((isCurrentUserInGroupFinPlanner||ViewRequest.DraftedRequestData.CCFinancialPlannerId == currentUser.get_id())&&ViewRequest.DraftedRequestData.Status == 'Pending Financial Planner Approval')
      {
      	$('#div-FinPlannerGLProposal').show();
      	ViewRequest.populateSelectCAMLLookup('#div-FinPlannerGLProposal select', ViewRequest.GLListName, 'Title', ViewRequest.FinancialPlanner);  
      
       //Main Fields
    	$('.padding-block').show(); $('#groupbutton').show();
		
		//$('#div-nonRequestorControls2').show();
		$('#div-finPlannerControls').show();
        $('#div-finPlannerComments').show();
	 	$('#div-isPlanned').show();
	 	$('#requestEdit').show();			
	 	$('#requestApprove').show(); 
   	    $('#requestReturn').show(); 
 		
      }
      
         
     //Scenario: In Fin-Planner group and Current user is tied to CCFinPlanner and CCVP of the Request and Status is in (Approved, Rejected, Closed)
     else if((isCurrentUserInGroupFinPlanner||ViewRequest.DraftedRequestData.CCFinancialPlannerId == currentUser.get_id()||ViewRequest.DraftedRequestData.CostCenterVPId == currentUser.get_id())&&(ViewRequest.DraftedRequestData.Status == 'Approved'||ViewRequest.DraftedRequestData.Status == 'Closed'||ViewRequest.DraftedRequestData.Status == 'Rejected'))
      {
      
      //Main Fields
    	$('.padding-block').show(); $('#groupbutton').show();
		$('#div-finPlannerControls').show();
 	    $('#div-finPlannerCommentsLabel').show();
 	    $('#div-FinPlannerGLProposalLabel').show();
 	    $('#div-isPlannedLabel').show();
      
       }    
       else
         {
         // Review  Committe VP's View
   		    IsCurrentUserMemberOfGroup("ADC-ReviewCommitte-VPs", function (isCurrentUserInGroupVP) {

   		   	 	           	
             	//Scenario: In Review committee group and Current user is tied to CCVP  and CCFinPlanner of the Request and Status is in (Pending Review Committee Approval)
	    		if((isCurrentUserInGroupVP&&isCurrentUserInGroupFinPlanner)||(ViewRequest.DraftedRequestData.CostCenterVPId == currentUser.get_id()||ViewRequest.DraftedRequestData.CCFinancialPlannerId== currentUser.get_id()))
     			 { 
     			  if(ViewRequest.DraftedRequestData.Status == 'Pending Review Committee Approval'&&ViewRequest.DraftedRequestData.IsPlanned==false)
     			    {

     			    //Main Fields
    			    $('.padding-block').show(); $('#groupbutton').show();
				    $('#div-finPlannerControls').show();
 	   			    $('#div-finPlannerCommentsLabel').show();
 	   			    $('#div-FinPlannerGLProposalLabel').show();
	 	    	    $('#div-isPlannedLabel').show();
	 	    	    $('#requestApprove').show(); 
	      	 	    $('#requestReject').show();
    			    
     			    }
     			 }   		      		    
    	 	 	else if((isCurrentUserInGroupVP||ViewRequest.DraftedRequestData.CostCenterVPId == currentUser.get_id())&&ViewRequest.DraftedRequestData.Status == 'Pending Review Committee Approval')
    			 {
    				if(ViewRequest.DraftedRequestData.IsPlanned==false)
 	 		    	 {
 	 		        //Main Fields
    				$('.padding-block').show(); $('#groupbutton').show();
					$('#div-finPlannerControls').show();
 	 		        $('#div-finPlannerCommentsLabel').show();
		 		    $('#div-isPlannedLabel').show();
		    	    $('#requestApprove').show(); 
	      	 	    $('#requestReject').show();
				  	}
 	  	  	 	 } 
 	  	  	 	 
 	  	  	 	//Scenario: In Review committee group and Current user is tied to CCFinPlanner and CCVP of the Request and Status is in (Approved, Rejected, Closed)
    		   else if((isCurrentUserInGroupVP||ViewRequest.DraftedRequestData.CostCenterVPId == currentUser.get_id())&&(ViewRequest.DraftedRequestData.Status == 'Approved'||ViewRequest.DraftedRequestData.Status == 'Closed'||ViewRequest.DraftedRequestData.Status == 'Rejected'))
     			 {
     			 		if(isCurrentUserInGroupFinPlanner||ViewRequest.DraftedRequestData.CCFinancialPlannerId == currentUser.get_id())
       					{   
       					   		             
     		 			//Main Fields
    					$('.padding-block').show(); $('#groupbutton').show();
						$('#div-finPlannerControls').show();
 	   					$('#div-finPlannerCommentsLabel').show();
 	   					$('#div-FinPlannerGLProposalLabel').show();
	 	    			$('#div-isPlannedLabel').show();
	 	    			}
	 	    			else
	 	    			{
	 	    			//Main Fields
    						$('.padding-block').show(); $('#groupbutton').show();
							$('#div-finPlannerControls').show();
		     		  	    $('#div-finPlannerCommentsLabel').show();
		 		  			 $('#div-isPlannedLabel').show();
	 	    			
	 	    			}
	 	    			
             	}
             	
 	//Scenario: In Fin-Planner group and Current user is tied to CCFinPlanner of the Request and Status is in (Pending Review Committee Approval)
     else if((isCurrentUserInGroupFinPlanner||ViewRequest.DraftedRequestData.CCFinancialPlannerId == currentUser.get_id())&&ViewRequest.DraftedRequestData.Status == 'Pending Review Committee Approval')
     {
       if((!isCurrentUserInGroupVP)||(ViewRequest.DraftedRequestData.CostCenterVPId != currentUser.get_id()))
       {
     //Main Fields
    	$('.padding-block').show(); $('#groupbutton').show();
		$('#div-finPlannerControls').show();
 	    $('#div-finPlannerCommentsLabel').show();
 	    $('#div-FinPlannerGLProposalLabel').show();
 	    $('#div-isPlannedLabel').show();
 	    }
     
     } 
	 
   				 else {	
   				        // Admins's/Owner's View.
   						IsCurrentUserMemberOfGroup("ADC Approval Management - Owners", function (isCurrentUserInGroupOwner) {
   	 					if(isCurrentUserInGroupOwner)
   						 {
   						  	$('#div-finPlannerControls').show();
   							 $('#div-finPlannerCommentsLabel').show();
		 		  			 $('#div-isPlannedLabel').show();
		 		  			 //Main Fields
   	 						 $('.padding-block').show(); $('#groupbutton').show(); 
    					 }
    								  
   					    else if (ViewRequest.DraftedRequestData.RequestorId == currentUser.get_id())
   					    {
   					    		$('.padding-block').show(); $('#groupbutton').show(); 
   					    		if(ViewRequest.DraftedRequestData.FinPlannerComments)
	 		 					 {$('#div-isPlannedLabel').show(); $('#div-finPlannerCommentsLabel').show(); }
   					    }
   					    else if (ViewRequest.DraftedRequestData.CostCenterDirectorId == currentUser.get_id()) {$('.padding-block').show(); $('#groupbutton').show(); }
   					    		
    		 						 else 
    		 						  {         $('.padding-block').hide(); 
												$('#groupbutton').hide();
												$('.padding-block').html('Authorized person can view the request details').show();
  				 						    
											
									 //  }// End of else
	 								// }); // end of Review  Committe VP's only Request View
 	 	 						    
	 						  //  }// End of else
	 						// }); // end of Financial Planner's only Request View.   
							
						   } // end of else 
						}); // end of Admins's/Owner's View.	
  	    			 } // end of else
  				}); // end of  Review  Committe VP's View.      	 
   	          } // end of else  
         }); // end of Financial Planner's View.
       } // end of else 
     }); // end of rovisioner PSM's View.
 
  	 $('#div-reqStatus .label2').text(ViewRequest.DraftedRequestData.Status);
  	 //if(ViewRequest.DraftedRequestData.Status=='Closed')	 { 	 $('#div-reqStatus .label2').css("color", "green"); }
	 if(ViewRequest.DraftedRequestData.Status=='Rejected')	 { 	 $('#div-reqStatus .label2').css("color", "red"); }
  	 if(ViewRequest.DraftedRequestData.Status=='Approved')	 { 	 $('#div-reqStatus .label2').css("color", "green"); }
 	 if(ViewRequest.DraftedRequestData.Status=='Pending Review Committee Approval')	 { 	 $('#div-reqStatus .label2').css("color", "green"); }
  	 if(ViewRequest.DraftedRequestData.Status=='Pending Financial Planner Approval')	 { 	 $('#div-reqStatus .label2').css("color", "orange"); }
	 if(ViewRequest.DraftedRequestData.Status=='Returned')	 { 	 $('#div-reqStatus .label2').css("color", "orange"); }
  	 if(ViewRequest.DraftedRequestData.Status=='Open')	 { 	 $('#div-reqStatus .label2').css("color", "blue"); }

     $('#div-requestor .label2').text(ViewRequest.DraftedRequestData.Requestor); 
     
     ViewRequest.ReqDate=ViewRequest.DraftedRequestData.RequestedDate;
     dd = ViewRequest.ReqDate.getDate();
     mm = ViewRequest.ReqDate.getMonth()+1;
     y = ViewRequest.ReqDate.getFullYear();		
     $('#div-requestedDate .label2').text(mm + '/' + dd + '/' + y); 

     $('#div-vp .label2').text(ViewRequest.DraftedRequestData.VP);
     $('#div-director .label2').text(ViewRequest.DraftedRequestData.Director);
     $('#div-manager .label2').text(ViewRequest.DraftedRequestData.Manager);
     $('#div-costCenter .label2').text(ViewRequest.DraftedRequestData.CostCenter);
     $('#div-costCenterName .label2').text(ViewRequest.DraftedRequestData.CostCenterName);
     $('#div-costCenterDirector .label2').text(ViewRequest.DraftedRequestData.CostCenterDirector);
     $('#div-costCenterFinancialPlanner .label2').text(ViewRequest.DraftedRequestData.CCFinancialPlanner);
     $('#div-costCenterVP .label2').text(ViewRequest.DraftedRequestData.CostCenterVP);
     $('#div-projectName .label2').text(ViewRequest.DraftedRequestData.ProjectName);
    
     $('#div-projectId .label2').text(ViewRequest.DraftedRequestData.ProjectNumber);
     $('#div-workType .label2').text(ViewRequest.DraftedRequestData.WorkType);
     $('#div-glName .label2').text(ViewRequest.DraftedRequestData.GLName);
     
      if(ViewRequest.DraftedRequestData.TONumber)
     $('#div-toNumber .label2').text(ViewRequest.DraftedRequestData.TONumber);
     if(ViewRequest.DraftedRequestData.PlanID)
     $('#div-planIDLabel .label2').text(ViewRequest.DraftedRequestData.PlanID);
    
     $('#div-vendorName .label2').text(ViewRequest.DraftedRequestData.VendorName);
     $('#div-headCount .label2').text(ViewRequest.DraftedRequestData.HeadCount);
     
     if(ViewRequest.DraftedRequestData.VendorName.startsWith('Managed'))
     {
     	$('#div-rate').hide();
	 	$('#div-estMonthlySpend').hide();
     }
         
     $('#div-rate .label2').text(ViewRequest.DraftedRequestData.Rate);
     
     /* //Commented date fields as per DEC-2017 Changes
     ViewRequest.SDate=ViewRequest.DraftedRequestData.StartDate;
     dd = ViewRequest.SDate.getDate();
     mm = ViewRequest.SDate.getMonth()+1;
     y = ViewRequest.SDate.getFullYear();		
     $('#div-startDate .label2').text(mm + '/' + dd + '/' + y); 

     ViewRequest.EDate=ViewRequest.DraftedRequestData.EndDate;
     dd = ViewRequest.EDate.getDate();
     mm = ViewRequest.EDate.getMonth()+1;
     y = ViewRequest.EDate.getFullYear();		
     $('#div-endDate .label2').text(mm + '/' + dd + '/' + y); 
     */
	
	
     $('#div-duration .label2').text(ViewRequest.DraftedRequestData.Duration.toFixed(1));
    //$('#div-estMonthlySpend .label2').text(ViewRequest.DraftedRequestData.EstMonthlySpend);
     $('#div-estMonthlySpend .label2').text((Math.round(ViewRequest.DraftedRequestData.EstMonthlySpend)+ "").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,"));
	// $('#div-amount .label2').text(ViewRequest.DraftedRequestData.Amount.toFixed(2));
		//Amount = Math.round(Amount);
	  $('#div-amount .label2').text((Math.round(ViewRequest.DraftedRequestData.Amount)+ "").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,"));
     
     
     //Additional Vendor Details added on 10/10/2017 by Anil Yerroju
     if(ViewRequest.DraftedRequestData.HasAdditionalVendor)
     {

     	$('#div-additionalVendorPanel1').show();
		$('#div-additionalVendorPanel2').show();
		$('#div-additionalVendorPanel3').show();
		$('#div-totalAmount').show();
		
		

     	  $('#div-vendorName2 .label2').text(ViewRequest.DraftedRequestData.VendorName2);
     	  $('#div-headCount2 .label2').text(ViewRequest.DraftedRequestData.HeadCount2);
     
    	 if(ViewRequest.DraftedRequestData.VendorName2.startsWith('Managed'))
    	 {
     		$('#div-rate2').hide();
	 		$('#div-estMonthlySpend2').hide();
     	}
         
    	 $('#div-rate2 .label2').text(ViewRequest.DraftedRequestData.Rate2);
    	 
    	 /* //Commented date fields as per DEC-2017 Changes
     	 ViewRequest.SDate2=ViewRequest.DraftedRequestData.StartDate2;
    	 dd = ViewRequest.SDate2.getDate();
    	 mm = ViewRequest.SDate2.getMonth()+1;
    	 y = ViewRequest.SDate2.getFullYear();		
    	 $('#div-startDate2 .label2').text(mm + '/' + dd + '/' + y); 

    	 ViewRequest.EDate2=ViewRequest.DraftedRequestData.EndDate2;
    	 dd = ViewRequest.EDate2.getDate();
     	 mm = ViewRequest.EDate2.getMonth()+1;
    	 y = ViewRequest.EDate2.getFullYear();		
    	 $('#div-endDate2 .label2').text(mm + '/' + dd + '/' + y); 
    	 */
	
	
     $('#div-duration2 .label2').text(ViewRequest.DraftedRequestData.Duration2.toFixed(1));
    //$('#div-estMonthlySpend2 .label2').text(ViewRequest.DraftedRequestData.EstMonthlySpend2);
    $('#div-estMonthlySpend2 .label2').text((Math.round(ViewRequest.DraftedRequestData.EstMonthlySpend2)+ "").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,"));
	// $('#div-amount2 .label2').text(ViewRequest.DraftedRequestData.Amount2.toFixed(2));
	// $('#div-totalAmount .label2').text(ViewRequest.DraftedRequestData.TotalAmount.toFixed(2));
	
	 $('#div-amount2 .label2').text((Math.round(ViewRequest.DraftedRequestData.Amount2)+ "").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,"));
     $('#div-totalAmount .label2').text((Math.round(ViewRequest.DraftedRequestData.TotalAmount)+ "").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,"));

     	 
     } // End of Additional Vendor Details ...
     
     // Added new PSM-Provisioner and Finplanner fileds on 12/18/2017 by Anil Yerroju
     $('#div-FinPlannerGLProposalLabel .label2').text(ViewRequest.DraftedRequestData.FinPGLProposal);
     $('#div-ProvisionerGLDecisionLabel .label2').text(ViewRequest.DraftedRequestData.ProvisionerGLDecision);
     $('#div-ProvisionerExplanationLabel .label2').text(ViewRequest.DraftedRequestData.ProvisionerExplanation);

     
     
      // Commented all PSM fields
     $('#div-headCountPlanLabel .label2').text(ViewRequest.DraftedRequestData.HeadCountPlan);
     $('#div-clarityUpdatedLabel .label2').text(ViewRequest.DraftedRequestData.ClarityUpdated);
     $('#div-sowNumberLabel .label2').text(ViewRequest.DraftedRequestData.SOWNumber);
     $('#div-toNumberLabel .label2').text(ViewRequest.DraftedRequestData.TONumber);
	 if(ViewRequest.DraftedRequestData.SOWStatus)
     $('#div-sowStatusLabel .label2').text(ViewRequest.DraftedRequestData.SOWStatus);
     
     if(ViewRequest.DraftedRequestData.IsProvisioned ==1)
     $('#div-isProvisionedLabel .label2').text('Yes');
     else 
      $('#div-isProvisionedLabel .label2').text('No');

     
     if(ViewRequest.DraftedRequestData.IsPlanned ==1)
     $('#div-isPlannedLabel .label2').text('Yes');
     else 
      $('#div-isPlannedLabel .label2').text('No');
      
     
	 if(ViewRequest.DraftedRequestData.RequestorComments)
     $('#div-requestorComments .label2').text(ViewRequest.DraftedRequestData.RequestorComments);
     if(ViewRequest.DraftedRequestData.FinPlannerComments)
 	 {
     $('#div-finPlannerCommentsLabel .label2').text(ViewRequest.DraftedRequestData.FinPlannerComments);
     $('#div-finPlannerComments input').val(ViewRequest.DraftedRequestData.FinPlannerComments);
     }
     
     /*// Commented as per DEC-2017 Changes.
     ViewRequest.DueByDate = ViewRequest.DraftedRequestData["EndDate"];
     var dd = ViewRequest.DueByDate.getDate();
     var mm = ViewRequest.DueByDate.getMonth() + 1;
     var y = ViewRequest.DueByDate.getFullYear();	//	minDate.setDate(minDate.getDate()+1);

     $('#div-endDate.label2').text(mm + '/' + dd + '/' + y); */
   });
};//End of ViewRequest.onload


ViewRequest.editClick = function () {
  
      window.location.href = 'EditRequest.aspx?RequestID=' + ViewRequest.RequestID;
  
};
ViewRequest.backClick = function () {
      window.location.href = 'Home.aspx';
  
};



ViewRequest.approveClick = function () {
	var IsPlanned= $('#div-isPlanned select').last().val();
	var FinPlannerGLProposal= $('#div-FinPlannerGLProposal option:selected').last().text();
	//var PlanID= $('#div-planID input').last().val();
	//var TONumber= $('#div-toNumber input').last().val();
	//var HeadCountPlan= $('#div-headCountPlan input').last().val();
	//var ClarityUpdated= $('#div-clarityUpdated input').last().val();
	//var SowStatus= $('#div-sowStatus input').last().val();
	//var SowNumber= $('#div-sowNumber input').last().val();
	var FinPlannerComments = $('#div-finPlannerComments input').last().val();
	var Status;

	// Not using this function after 09/19/2017 updates
   	/*if(ViewRequest.DraftedRequestData.Status=="Pending Director Approval")
	{
	 var datasource = { "Status": 'Pending Financial Planner Approval'};
     ViewRequest.UpdateRequestDetails(datasource);  
     } */
     
	if(ViewRequest.DraftedRequestData.Status=="Pending Financial Planner Approval")
	{
	if(IsPlanned == "" ||!IsPlanned)
   		{  alert("Enter all required fields marked with *.");
                    return;	
        }
    else if(IsPlanned == 'Yes') 
     	{ IsPlanned = 'true';  
          Status = "Approved";     	
		    
        }
   else if(IsPlanned == 'No')  
        {IsPlanned = 'false'; 
         Status = "Pending Review Committee Approval";  
        
        }
    var datasource = 	{ 	 "Status":Status,
          					 "IsPlanned": IsPlanned,
          					 "Financial_x0020_Planner_x0020_Co": FinPlannerComments,
          					 "FinPGLProposal":FinPlannerGLProposal
          					// Commented as per 08/23 demo inputs. 
                        	// "Plan_x0020_ID": PlanID,
                        	// "TO_x0020_Number": TONumber,
                      		// "Headcount_x0020_Plan_x0020_Updat": HeadCountPlan,
                      		// "Clarity_x0020_Updated": ClarityUpdated,
                       		// "SOW_x0020_Status": SowStatus,
                      		// "SOW_x0020_Number": SowNumber
          				   };  
	   ViewRequest.UpdateRequestDetails(datasource);          				   
          
	} 
	
	
	
	if(ViewRequest.DraftedRequestData.Status=="Pending Review Committee Approval"&&ViewRequest.DraftedRequestData.IsPlanned==false)
	{	  
	//Approved
	 var datasource = { "Status": 'Approved'};
     ViewRequest.UpdateRequestDetails(datasource); 
    } 
    
    /* // Not using this function after 09/19/2017 updates
    else if(ViewRequest.DraftedRequestData.Status=="Pending Review Committee Approval"&&ViewRequest.DraftedRequestData.IsPlanned==false)
     {
     //Approved for Unplanned Requests.
	 var datasource = { "Status": 'Approved'};
	 ViewRequest.UpdateTaskDetails(datasource); 
	 }   */
  
};


ViewRequest.rejectClick = function () {
	/* // Not using this function after 09/19/2017 updates
	if(ViewRequest.DraftedRequestData.Status=="Pending Review Committee Approval"&&ViewRequest.DraftedRequestData.IsPlanned==true)
	{
	//Rejected
	 var datasource = { "Status": 'Rejected'};
     ViewRequest.UpdateRequestDetails(datasource);  
	}
	 else  */
	 
	 if(ViewRequest.DraftedRequestData.Status=="Pending Review Committee Approval"&&ViewRequest.DraftedRequestData.IsPlanned==false)
     {
     //Rejected
	 var datasource = { "Status": 'Rejected'};
	 ViewRequest.UpdateRequestDetails(datasource); 
   
	 }  
   
};


ViewRequest.returnClick = function () {

    var FinPlannerComments = $('#div-finPlannerComments input').last().val();
    var FinPlannerGLProposal= $('#div-FinPlannerGLProposal option:selected').last().text();

	/*if(ViewRequest.DraftedRequestData.Status=="Pending Director Approval")
	{
	var datasource = { "Status": 'Returned'};
    ViewRequest.UpdateRequestDetails(datasource); 
    
	} */
	if(ViewRequest.DraftedRequestData.Status=="Pending Financial Planner Approval")
	{
	var datasource = { "Status": 'Returned', "Financial_x0020_Planner_x0020_Co": FinPlannerComments, "FinPGLProposal":FinPlannerGLProposal};
    ViewRequest.UpdateRequestDetails(datasource); 
	}     
};

ViewRequest.submitClick = function () {
	//var PlanID= $('#div-planID input').last().val();
	//var TONumber= $('#div-toNumber input').last().val();
	//var HeadCountPlan= $('#div-headCountPlan input').last().val();
	//var ClarityUpdated= $('#div-clarityUpdated input').last().val();
	var FinPlannerGLProposal=$('#div-FinPlannerGLProposalLabel .label2').last().text();
	var ProvisionerGLDecision= $('#div-ProvisionerGLDecision option:selected').last().text();
	var ProvisionerExplanation= $('#div-ProvisionerExplanation option:selected').last().text();
	
	if(ProvisionerGLDecision=='Select')
	{
		ProvisionerGLDecision =null;
	}
	if(ProvisionerExplanation=='Select')
	{
		ProvisionerExplanation=null;
	}

	
	var PlannerProvisionerMatchFlag;
	
	// Financial Planner and Provisioner Match flag check
	if(FinPlannerGLProposal==ProvisionerGLDecision)
	{
	PlannerProvisionerMatchFlag = true;
	}
	else {PlannerProvisionerMatchFlag = false;}
	
	var SowStatus= $('#div-sowStatus option:selected').last().text();
	var SowNumber= $('#div-sowNumber input').last().val();

	
	if(ViewRequest.DraftedRequestData.Status=="Open"||ViewRequest.DraftedRequestData.Status=="Returned")
	{
	 var datasource = { "Status": 'Pending Financial Planner Approval'};
	 ViewRequest.UpdateRequestDetails(datasource);
	}
	
	else {
	  
	if(ViewRequest.DraftedRequestData.Status=="Approved")
	{
	var IsProvisioned = $('#div-isProvisioned select').last().val();
	
	if(IsProvisioned == "" ||!IsProvisioned)
   		{  alert("Enter all required fields marked with *.");
                    return;	
        }
     else  if(IsProvisioned == 'Yes') IsProvisioned = 'true'; else IsProvisioned = 'false'; 
	} 
	
	var datasource = { 
	"IsProvisioned":IsProvisioned,
	"Status": 'Closed',
	"ProvisionerGLDecision":ProvisionerGLDecision,
	"ProvisionerExplanation":ProvisionerExplanation,
	"PlannerProvisionerMatchFlag":PlannerProvisionerMatchFlag,
	//"Plan_x0020_ID": PlanID,
	//"TO_x0020_Number": TONumber,
   // "Headcount_x0020_Plan_x0020_Updat": HeadCountPlan,
    //"Clarity_x0020_Updated": ClarityUpdated,
    "SOW_x0020_Status": SowStatus,
    "SOW_x0020_Number": SowNumber
	};
	ViewRequest.UpdateRequestDetails(datasource); 
	
	}
    
};


ViewRequest.UpdateRequestDetails = function (datasource){

var response = CRUDobj.UpdateItemUtility("ADC Approval Requests", datasource,ViewRequest.RequestID,"", "", "ADC_x0020_Approval_x0020_Requests").done(function () {
						addOverlay("Please Wait...<br/>We Are Processing Your Request.");
                    	//alert("Request " +ViewRequest.RequestID +" details are updated.");
                   		 window.location.href = 'Home.aspx';
                   		 
           	    	 }).fail(function (jqxHR, textStatus, errorThrown) {
                    alert("Page:'ViewRequest.aspx' Error:" + errorThrown)
              	  }); 
};

// Not using this function after 09/19/2017 updates
ViewRequest.UpdateTaskDetails = function (datasource){

   var dfdCurrentloggedInUser = SPUser.getCurrent();
    dfdCurrentloggedInUser.done(function (currentUser) {
	
  ViewRequest.CheckTaksForUnplannedRequest(ViewRequest.DraftedRequestData.reqID, currentUser).done(function (TaskItemID) {
   			 
   if(TaskItemID)
   {
  
   CRUDobj.UpdateItemUtility("ADC Approval Tasks", datasource,TaskItemID,"", "", "ADC_x0020_Approval_x0020_Tasks").done(function () {   
					    addOverlay("Please Wait...<br/>We Are Processing Your Request."); 
                    	alert("Request " +ViewRequest.RequestID +" details are updated.");
                   		 window.location.href = 'Home.aspx';
                   		 
           	    	 }).fail(function (jqxHR, textStatus, errorThrown) {
                    alert("Page:'ViewRequest.aspx' Error:" + errorThrown)
              	  });
   }              	   
  });
  });                  	  
};




ViewRequest.populateSelectCAMLLookup = function (element, listName, fieldName, roleName) {
    var docFieldName = ViewRequest.getFieldName(element)
    var sValue = ViewRequest.getFieldValue(docFieldName);

    var ctx = SP.ClientContext.get_current();
    
    var list = ctx.get_web().get_lists().getByTitle(listName);

    var camlQuery = new SP.CamlQuery();
    
 

	if (sValue != '')
        camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="ID"/><Value Type="Counter">' + sValue + '</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
    else
        camlQuery.set_viewXml('<View><Query><Where></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');

    var lstItems = list.getItems(camlQuery);
    ctx.load(lstItems);
    ctx.executeQueryAsync(
	function (sender, args) {
	    var selectHtml = "";
	    var distinctItems = [];
	    var ItemEnum = lstItems.getEnumerator();
	    while (ItemEnum.moveNext()) {
	    if(listName==ViewRequest.GLListName)
	    {
	     if(ItemEnum.get_current().get_item('FinancialPlannerFlag')=="1"&&roleName==ViewRequest.FinancialPlanner){
	      var itemValue = ItemEnum.get_current().get_item('ID');
	      var itemTitle = ItemEnum.get_current().get_item(fieldName); }
	      
	      if(ItemEnum.get_current().get_item('ProvisionerFlag')=="1"&&roleName==ViewRequest.Provisioner){
	      var itemValue = ItemEnum.get_current().get_item('ID');
	      var itemTitle = ItemEnum.get_current().get_item(fieldName); }

	     }
	    else {    
	        var itemValue = ItemEnum.get_current().get_item('ID');
	        var itemTitle = ItemEnum.get_current().get_item(fieldName);
	        }
			 
	        var $dupItems = $.grep(distinctItems, function (element, index) {
	            return element.value == itemValue;
	        });
	     if (!$dupItems.length)
	        	            distinctItems.push({ 'value': itemValue, 'title': itemTitle });

	    }
	    for (var i = 0; i < distinctItems.length; i++) {
	    	        selectHtml += '<option value="' + distinctItems[i].value + '">' + distinctItems[i].title + '</option>';
	    }
	    $(element).append(selectHtml);
	    $(element).attr('data', '{"listName":"' + listName + '","fieldName":"' + fieldName + '","valueFieldName":"ID"}');
 	    $(element).val(sValue);
	   // $(element).combobox(); 
	},
	function (sender, args) {
	    console.log("Page:'Request.aspx' Method:'lstRequest.populateSelectInitiator.' Error:" + args.get_message());

	});
};


ViewRequest.getFieldName=function(element){
	var fieldName='';

	switch(element)
	{
		case '#div-clarityProjectID select': fieldName='Title';
				break;

		case '#div-vendorName select': fieldName='Title';
				break;
		
		default:break;
	}
	return fieldName;
};

// Not using this function after 09/19/2017 updates
// common function Check current user details in mentioned Group 
ViewRequest.CheckTaksForUnplannedRequest=function(RequestNumber,currentUser) {
var dfd = $.Deferred();
  var RequestNumber = RequestNumber;
  var currentUser = currentUser;
  	
  	var ctx = SP.ClientContext.get_current();
    var list = ctx.get_web().get_lists().getByTitle(ViewRequest.ViewTaksListName);
    var camlQuery = new SP.CamlQuery();
    // camlQuery.set_viewXml('<View><Query><Where><And><And><Eq><FieldRef Name="Request_x0020_Number"/><Value Type="Lookup">'+RequestNumber+'</Value></Eq><Eq><FieldRef Name="Status"/><Value Type="Choice">InReview</Value></Eq><Eq></And></Eq><FieldRef Name="Approver" LookupId="TRUE" /><Value Type="Lookup">'+currentUser.get_id()+'</Value></And></Where></Query></View>');
   camlQuery.set_viewXml('<View><Query><Where><And><Eq><FieldRef Name="Request_x0020_Number"/><Value Type="Lookup">'+RequestNumber+'</Value></Eq><And><Eq><FieldRef Name="Status"/><Value Type="Choice">InReview</Value></Eq><Eq><FieldRef Name="Approver" LookupId="TRUE" /><Value Type="Lookup">'+currentUser.get_id()+'</Value></Eq></And></And></Where></Query></View>');
     var lstItems = list.getItems(camlQuery);
     ctx.load(lstItems);
     ctx.executeQueryAsync(
	  function (sender, args) {
            var pendingTask = false;
            var ItemEnum = lstItems.getEnumerator();
            while (ItemEnum.moveNext()) {
                //var itemTask = ItemEnum.get_current();
                var itemID = ItemEnum.get_current().get_item('ID');
                if (itemID)
                   {  itemID;   }
            }  
          //  alert(pendingTask); 
          dfd.resolve(itemID);
        },      
         function (sender, args) {
	    console.log("Page:'View.aspx' Method:'CheckTaksForUnplannedRequest.' Error:" + args.get_message());
     	});

        return dfd.promise();  
};

// Common function
ViewRequest.getFieldValue = function (fieldName) {
    var fieldValue = '';
    if (sessionStorage.searchQuery && sessionStorage.searchQuery != '') {
    	var paramJson =JSON.parse(sessionStorage.searchQueryJson);
    	var fieldJson= $.grep(paramJson,function(element){
			return element.name==fieldName;
		});
		if(fieldJson.length)
    		fieldValue=fieldJson[0].value;
    }
    return fieldValue;
	
};



// common function Check current user details in mentioned Group 
function IsCurrentUserMemberOfGroup(groupName, OnComplete) {

        var currentContext = new SP.ClientContext.get_current();
        var currentWeb = currentContext.get_web();

        var currentUser = currentContext.get_web().get_currentUser();
        currentContext.load(currentUser);

        var allGroups = currentWeb.get_siteGroups();
        currentContext.load(allGroups);

        var group = allGroups.getByName(groupName);
        currentContext.load(group);

        var groupUsers = group.get_users();
        currentContext.load(groupUsers);

        currentContext.executeQueryAsync(OnSuccess,OnFailure);

        function OnSuccess(sender, args) {
            var userInGroup = false;
            var groupUserEnumerator = groupUsers.getEnumerator();
            while (groupUserEnumerator.moveNext()) {
                var groupUser = groupUserEnumerator.get_current();
                if (groupUser.get_id() == currentUser.get_id()) {
                    userInGroup = true;
                    break;
                }
            }  
            OnComplete(userInGroup);
        }

        function OnFailure(sender, args) {
            OnComplete(false);
        }    
}


$(document).ready(function () {
    SPUser.getCurrent().done(function (user) {
        ViewRequest.CurrentUser = user;
        ViewRequest.init();
    })
   .fail(function (msg) {
       console.log(msg);
   });
});
	