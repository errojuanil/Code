﻿/**
 * @Author: ANIL KUMAR YERROJU
 * @Created on: 07/19/2017
 * @Last Modified: available at file properties.
 * @Application: ADC Approval Management Automation.
 * @Page Name: ADC_CRUD.
 * @summary: This scripted for doing CRUD operations against SharePoint objects.
 *		     
 **/


'use scrict'
var DDOCS= window.DDOCS|| {};
DDOCS.ListItemManager = function () {

//Get Items from sharepoint list
	var _fetchItems = function(listName,baseurl,headers,filter,CAMLExpr)
	{
	var dfd = $.Deferred();
		
	if(!baseurl && baseurl.length < 1)
		{ 
			var CurrentbaseUrl = _spPageContextInfo.webServerRelativeUrl +  "/_api/web/lists/";			
		}
		else
		{
		var CurrentbaseUrl = SP.Utilities.UrlBuilder.urlCombine(baseurl, "_api/web/lists/");			
		}
		
		CurrentbaseUrl += "GetByTitle('" + listName + "')/";
		baseurl = CurrentbaseUrl;
		//baseurl  ="http://mypod.devstage.bitwiseglobal.com/TestEmp/_api/web/lists/GetByTitle('REST')/";
		
		
		if(filter && filter.length > 1)//Filter listitem using querystring $filter parameter
		{
			baseurl+= "items"+"?"+filter;
		}
		else
		if(CAMLExpr && CAMLExpr.length > 1)//Filter listitem using CAML query
		{
		baseurl+= "GetItems";
		 
		}
		
		if(!headers && headers.length < 1)
		{
			var Defaultheaders = {
                "accept": "application/json;odata=verbose"
            };
			headers=Defaultheaders;
		}

		
		
    var requestData = { "query": {
    						"__metadata":{ "type": "SP.CamlQuery" },
    						"ViewXml": "<View><Query></Query></View>" 
           						 }
					  };
    
        var dfd = $.ajax({
            url: encodeURI(baseurl),
           
            data: requestData ,
            contentType: "application/json;odata=verbose",
            headers: {
                "accept": "application/json;odata=verbose",
                "Content-Type": "application/json; odata=verbose",
                "X-RequestDigest": $("#__REQUESTDIGEST").val()
            }
        });
        return dfd.promise();
	}
	//Read sharepoint list items: Using CAML query
	var _createItem = function(listName,data,baseurl,headers,internalListName)
	{
		var dfd = $.Deferred();
		
	if(!baseurl || baseurl.length < 1)
		{ 
			var CurrentbaseUrl = _spPageContextInfo.webServerRelativeUrl +  "/_api/web/lists/";			
		}
		else
		{
		var CurrentbaseUrl = SP.Utilities.UrlBuilder.urlCombine(baseurl, "_api/web/lists/");			
		}
		CurrentbaseUrl += "GetByTitle('" + listName + "')/items";
		baseurl = CurrentbaseUrl;
		//baseurl  ="http://mypod.devstage.bitwiseglobal.com/TestEmp/_api/web/lists/GetByTitle('REST')/items";
		
	if(!headers || headers.length < 1)
		{
			var Defaultheaders = {
                "accept": "application/json;odata=verbose",
	            "Content-Type": "application/json;odata=verbose",
	            "X-RequestDigest": $("#__REQUESTDIGEST").val()
            };
			headers=Defaultheaders;
		}
		if(internalListName)
		{
			data["__metadata"] = { "type": "SP.Data." + internalListName+ "ListItem" };
		}
		else
		{
			data["__metadata"] = { "type": "SP.Data." + listName + "ListItem" };
		}
		var itemData = JSON.stringify(data);

		
        var dfd = $.ajax({
            url: encodeURI(baseurl),
            type: "POST",
	        contentType: "application/json;odata=verbose", 
	        data: itemData,
	        headers: headers
        });
        return dfd.promise();


	}

	var _updateItem = function(listName,data,ItemID,baseurl,headers,internalListName)
	{

		var dfd = $.Deferred();
	    if(!baseurl || baseurl.length < 1)
		{ 
			var CurrentbaseUrl = _spPageContextInfo.webServerRelativeUrl +  "/_api/web/lists/";			
		}
		else
		{
			var CurrentbaseUrl = SP.Utilities.UrlBuilder.urlCombine(baseurl, "_api/web/lists/");			
		}
		CurrentbaseUrl += "GetByTitle('" + listName + "')/items('"+ItemID+"')";
		baseurl = CurrentbaseUrl;
		//baseurl  ="http://mypod.devstage.bitwiseglobal.com/TestEmp/_api/web/lists/GetByTitle('REST')/items(" + ItemID+ ")";
		
	    if(internalListName)
		{
			data["__metadata"] = { "type": "SP.Data." + internalListName+ "ListItem" };
		}
		else
		{
			data["__metadata"] = { "type": "SP.Data." + listName + "ListItem" };
		}

	        var itemData = JSON.stringify(data);
	        var headers = {
	            "accept": "application/json;odata=verbose",
                  "X-RequestDigest": $("#__REQUESTDIGEST").val(),
                  "content-type": "application/json;odata=verbose",
                  "X-HTTP-Method": 'MERGE',
                  "If-Match": '*'
                }
	        var dfd = $.ajax({
	            url: encodeURI(baseurl),
	            type: "POST",
	            contentType: "application/json;odata=verbose", 
	            data: itemData,
	            headers: headers
	        });
	        return dfd.promise();

	}
	
	//Delete list item by ID
	var _deleteItem = function(listName,ItemID,baseurl,headers)
	{
		var dfd = $.Deferred();
		
		if(!baseurl || baseurl.length < 1)
		{ 
			var CurrentbaseUrl = _spPageContextInfo.webServerRelativeUrl +  "/_api/web/lists/";			
		}
		else
		{
		var CurrentbaseUrl = SP.Utilities.UrlBuilder.urlCombine(baseurl, "_api/web/lists/");			
		}
		CurrentbaseUrl += "GetByTitle('" + listName + "')/items("+ItemID+")";
		baseurl = CurrentbaseUrl;
		//baseurl  ="http://mypod.devstage.bitwiseglobal.com/TestEmp/_api/web/lists/GetByTitle('REST')/items(" + ItemID+ ")";
		
		
		if(!headers || headers.length < 1)
		{
			var Defaultheaders = {
                "accept": "application/json;odata=verbose",
            	'X-HTTP-Method': 'DELETE',
            	'If-Match': '*',
           		"X-RequestDigest": $("#__REQUESTDIGEST").val()            };
			headers=Defaultheaders;
		}

		        
        
        var dfd = $.ajax({
            url: encodeURI(baseurl),
            type: "POST",
            contentType: "application/json;odata=verbose",
            headers: headers
        });
        
        return dfd.promise();

	}
    //move list item ti recyclebin by ID
	var _MoveItemToRecylaeBin = function (listName, ItemID, baseurl, headers) {
	    var dfd = $.Deferred();

	    if (!baseurl || baseurl.length < 1) {
	        var CurrentbaseUrl = _spPageContextInfo.webServerRelativeUrl + "/_api/web/lists/";
	    }
	    else {
	        var CurrentbaseUrl = SP.Utilities.UrlBuilder.urlCombine(baseurl, "_api/web/lists/");
	    }
	    CurrentbaseUrl += "GetByTitle('" + listName + "')/items(" + ItemID + ")/recycle()";
	    baseurl = CurrentbaseUrl;
	    //baseurl  ="http://mypod.devstage.bitwiseglobal.com/TestEmp/_api/web/lists/GetByTitle('REST')/items(" + ItemID+ ")";


	    if (!headers || headers.length < 1) {
	        var Defaultheaders = {
	            "accept": "application/json;odata=verbose",
	            'X-HTTP-Method': 'POST',
	            'If-Match': '*',
	            "X-RequestDigest": $("#__REQUESTDIGEST").val()
	        };
	        headers = Defaultheaders;
	    }



	    var dfd = $.ajax({
	        url: encodeURI(baseurl),
	        type: "POST",
	        contentType: "application/json;odata=verbose",
	        headers: headers
	    });

	    return dfd.promise();

	}
/*Utility func*/
var _getItemTypeForListname = function(listName)
	{
        
        return "SP.Data." + listName.charAt(0).toUpperCase() +  listName.slice(1)+ "ListItem";

	}



	return{
		FetchItemsUtility:_fetchItems,
		CreateItemUtility:_createItem,
		UpdateItemUtility: _updateItem,
		DeleteItemUtility: _deleteItem,
		MoveItemToRecycleBinUtility: _MoveItemToRecylaeBin
		}
}
