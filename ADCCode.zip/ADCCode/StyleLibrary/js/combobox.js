﻿/**
 * @Author: ANIL KUMAR YERROJU
 * @Created on: 07/19/2017
 * @Last Modified: available at file properties.
 * @Application: ADC Approval Management Automation.
 * @Page Name: Combobox.
 * @summary: This script file used to load/populate all drop downs.
 *		     
 **/


var comboboxExt = {};
comboboxExt.GLListName= "GL List";
comboboxExt.ProjectsListName= "Projects";
comboboxExt.IdeasListName= "Ideas";
comboboxExt.CostCenterListName= "BT Cost Center Hierarchy";
comboboxExt.SDLCUrl= "https://discoverfinancial.sharepoint.com/sites/BTPrjArtfcts";
comboboxExt.BTFinanceUrl= "https://discoverfinancial.sharepoint.com/sites/BT2016BudPlan";


comboboxExt.getResults= function (listName, fieldName, searchText,rowlimit,valueFieldName,isLookup,isRecursive,orderBy) {
    var dfd = $.Deferred();
    // Added by Anil Yerroju on 08/01/2017 for reading project list from external site.
    if (listName == comboboxExt.ProjectsListName||listName == comboboxExt.IdeasListName)
    {
   
    var ctx = new SP.ClientContext(comboboxExt.SDLCUrl);
    }
    else if(listName == comboboxExt.CostCenterListName)
    {

    var ctx = new SP.ClientContext(comboboxExt.BTFinanceUrl);

    }
    else
    {
		var ctx = SP.ClientContext.get_current();
    }
    
    var list = ctx.get_web().get_lists().getByTitle(listName);
    var camlQuery = new SP.CamlQuery();
    var query='';
    
    if(isRecursive)
    	query+='<View Scope="Recursive">';
    else
    	query+='<View>';
    	
    query+='<Query>';
    
       
    if(searchText != '')
    {
      /* if(fieldName=='Author0')
       {
       query+='<Where><And><Geq><FieldRef Name="Created"/><Value Type="DateTime"><Today OffsetDays="-180"/></Value></Geq><Contains><FieldRef Name="' + fieldName + '"/><Value Type="Text">' + searchText + '</Value></Contains></And></Where>';
        } */
        
    query+='<Where><Contains><FieldRef Name="' + fieldName + '"/><Value Type="Text">' + searchText + '</Value></Contains></Where>';
    }
   	else
   	{
   	query+='<Where></Where>';
   	}
   	
   	if(orderBy)
   		query+='<OrderBy><FieldRef Name="' + fieldName + '"/></OrderBy>';
   		
   	query+='</Query><RowLimit Paged="FALSE">' + rowlimit + '</RowLimit></View>';
   	
   	
   	camlQuery.set_viewXml(query);
    
    var lstItems = list.getItems(camlQuery);
    ctx.load(lstItems);
    ctx.executeQueryAsync(
    function (sender, args) {
        var selectOpts = "";
        var distinctItems = [];
        var ItemEnum = lstItems.getEnumerator();
        
        while (ItemEnum.moveNext()) {
        	var itemValue='';
        	var itemTitle='';
            if (valueFieldName)
            {
           		//itemValue=ItemEnum.get_current().get_item(valueFieldName);
            	//itemTitle=ItemEnum.get_current().get_item(fieldName);
             	if(listName==comboboxExt.GLListName)
	    		 {
	      		  if(ItemEnum.get_current().get_item('UserFlag')=="1")
	      			 {
	      			 itemValue=ItemEnum.get_current().get_item(valueFieldName);
            		 itemTitle=ItemEnum.get_current().get_item(fieldName); 
            		 }
            	  }
				 else
				  {
				 	itemValue=ItemEnum.get_current().get_item(valueFieldName);
            		itemTitle=ItemEnum.get_current().get_item(fieldName);
            	  } 
            }
            else if(isLookup)
            {
          	//Handling null object using below if condition on 09/15/2015 -- AK
            if(ItemEnum.get_current().get_item(fieldName) != null)
        	{       
            	
            	itemValue=ItemEnum.get_current().get_item(fieldName).get_lookupId();
            	
            	itemTitle=ItemEnum.get_current().get_item(fieldName).get_lookupValue();
            	}
            	
            }
            else
            {
            	itemValue=ItemEnum.get_current().get_item(fieldName);
            	itemTitle=ItemEnum.get_current().get_item(fieldName);
            }
           
           	var $dupItems = $.grep(distinctItems, function (element, index) {
                return element.value == itemValue;
            });
            if (!$dupItems.length)
                distinctItems.push({ 'value': itemValue,'title': itemTitle });
        }
       
        
        for (var i = 0; i < distinctItems.length; i++) {
            selectOpts += '<option value="' + distinctItems[i].value+ '">' + distinctItems[i].title+ '</option>';
        }

        var $select = $('<select>' + selectOpts + '</select>', {});
        dfd.resolve($select);
    },
    function (sender, args) {
        dfd.reject(args.get_message());
    });

    return dfd.promise();
};

(function ($) {
    $.widget( "custom.combobox", {
      _create: function() {
        this.wrapper = $( "<span>" )
          .addClass( "custom-combobox" )
          .insertAfter( this.element );
 
        this.element.hide();
        this._createAutocomplete();
        this._createShowAllButton();
      },
 
      _createAutocomplete: function() {
        var selected = this.element.children( ":selected" ),
          value = selected.val() ? selected.text() : "";
 
        this.input = $( "<input>" )
          .appendTo( this.wrapper )
          .val( value )
          .attr( "title", "" )
          .attr( "placeholder", "Select or Type.." )
          .addClass( "custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left" )
          .autocomplete({
            delay: 0,
            minLength: 0,
            source: $.proxy( this, "_source" )
          })
          .tooltip({
            tooltipClass: "ui-state-highlight"
          });
 
        this._on( this.input, {
          autocompleteselect: function( event, ui ) {
              ui.item.option.selected = true;
              this.element.val(ui.item.option.value);
              if(this.element.val()!=ui.item.option.value)
              {
              	this.element.append('<option value="'+ui.item.option.value+'">'+$(ui.item.option, {}).text()+'</option>');
              	this.element.val(ui.item.option.value);
              }
              var sData = this.element.attr('data') ? JSON.parse(this.element.attr('data')) : '';
              if (sData.valueFieldName)
                  this.element.parent().find('input').first().val(ui.item.option.value + ';#' + $(ui.item.option, {}).text());
            this._trigger( "select", event, {
              item: ui.item.option
            });
          },
 
          autocompletechange: "_removeIfInvalid"
        });
      },
 
      _createShowAllButton: function() {
        var input = this.input,
          wasOpen = false;
 
        $( "<a>" )
          .attr( "tabIndex", -1 )
          .attr( "title", "Show All Items" )
          .tooltip()
          .appendTo( this.wrapper )
          .button({
            icons: {
              primary: "ui-icon-triangle-1-s"
            },
            text: false
          })
          .removeClass( "ui-corner-all" )
          .addClass( "custom-combobox-toggle ui-corner-right" )
          .mousedown(function() {
            wasOpen = input.autocomplete( "widget" ).is( ":visible" );
          })
          .click(function() {
            input.focus();
 
            // Close if already visible
            if ( wasOpen ) {
              return;
            }
 
            // Pass empty string as value to search for, displaying all results
            input.autocomplete( "search", "" );
          });
      },
 
      _source: function (request, response) {
          var $thisSelect = this.element;
          var matcher = new RegExp($.ui.autocomplete.escapeRegex(request.term), "i");
          if ($thisSelect.attr('data')) {
              var sData = JSON.parse($thisSelect.attr('data'));
              comboboxExt.getResults(sData.listName, sData.fieldName, request.term, 50, sData.valueFieldName,sData.isLookup,sData.isRecursive,sData.orderBy)
                .done(function ($select) {
                    $thisSelect.html($select.html());
                    response($select.children("option").map(function () {
                        var text = $(this).text();
                        if (this.value && (!request.term || matcher.test(text)))
                            return {
                                label: text,
                                value: text,
                                option: this
                            };
                    }));
                })
                .fail(function (msg) {
                    var thresholdMessage = 'The attempted operation is prohibited because it exceeds the list view threshold enforced by the administrator.'
                    console.log("Page:'combobox.js' Method:'combobox._source.' Error:" + msg);
                    if (msg == thresholdMessage) {
                        comboboxExt.getResults(sData.listName, sData.fieldName, '', 100, sData.valueFieldName,sData.isLookup,sData.isRecursive,sData.orderBy)
                            .done(function ($select) {
                                $thisSelect.html($select.html());
                                response($select.children("option").map(function () {
                                    var text = $(this).text();
                                    if (this.value && (!request.term || matcher.test(text)))
                                        return {
                                            label: text,
                                            value: text,
                                            option: this
                                        };
                                }));
                            })
                            .fail(function (msg) {
                                console.log("Page:'combobox.js' Method:'combobox._source2.' Error:" + msg);
                            });
                    }
                });
          }
          else {
              response($thisSelect.children("option").map(function () {
                  var text = $(this).text();
                  if (this.value && (!request.term || matcher.test(text)))
                      return {
                          label: text,
                          value: text,
                          option: this
                      };
              }));
          }
      },
 
      _removeIfInvalid: function( event, ui ) {
 
        // Selected an item, nothing to do
        if ( ui.item ) {
          return;
        }
 
        // Search for a match (case-insensitive)
        var value = this.input.val(),
          valueLowerCase = value.toLowerCase(),
          valid = false;
        this.element.children( "option" ).each(function() {
          if ( $( this ).text().toLowerCase() === valueLowerCase ) {
            this.selected = valid = true;
            return false;
          }
        });
 
        // Found a match, nothing to do
        if ( valid ) {
          return;
        }
 
        // Remove invalid value
        this.input
          .val( "" )
          .attr( "title", value + " didn't match any item" )
          .tooltip( "open" );
        this.element.val( "" );
        this._delay(function() {
          this.input.tooltip( "close" ).attr( "title", "" );
        }, 2500 );
        this.input.autocomplete( "instance" ).term = "";
      },
 
      _destroy: function() {
        this.wrapper.remove();
        this.element.show();
      }
    });
  })( jQuery );
 
