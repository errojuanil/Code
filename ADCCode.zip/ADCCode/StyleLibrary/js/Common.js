/**
 * @Author: ANIL KUMAR YERROJU
 * @Created on: 07/19/2017
 * @Last Modified: available at file properties.
 * @Application: ADC Approval Management Automation.
 * @Page Name: COMMON.
 * @summary: Scripted with all common functions used across the application.
 *		     
 **/


var SPUser = {};

SPUser.current = null;
EmailTemplateListName = 'EmailTemplates';

SPUser.getCurrent = function () {
    var dfd = $.Deferred();
    var context = SP.ClientContext.get_current();
    SPUser.current = context.get_web().get_currentUser();
    context.load(SPUser.current);
    context.executeQueryAsync(
		Function.createDelegate(this, success),
		Function.createDelegate(this, error)
	);

    function success() {
        dfd.resolve(SPUser.current);
    }
    function error(sender, args) {
        dfd.reject(args.message)
    }
    return dfd.promise();
};

function isCurrentUserSiteCollAdmin(webUri) {

    var dfd = $.Deferred();
    var ctx = new SP.ClientContext(webUri);
    var web = ctx.get_web();
    this.currentUser = ctx.get_web().get_currentUser();
    ctx.load(this.currentUser, "IsSiteAdmin");


    ctx.executeQueryAsync(success, error);

    //ctx = null;
    //return currentUser.IsSiteAdmin;

    /* return true;*/

    function success() {
        this.issiteAdmin = ctx.get_web().get_currentUser().get_isSiteAdmin();
        dfd.resolve(this.issiteAdmin);
    }
    function error() {
        dfd.reject("Error")
    }

    return dfd.promise();

}


function getQueryStringParameter(paramToRetrieve) {
    var params = document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i++) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve) {
            return singleParam[1].split('#')[0];
        }
    }
}

//peoplePickerElementId: id of Wrapper  div
//Username: semicolon seperated list of username
//isMultiselect: bool, is people picker allowed to select multiple user
function initializePeoplePicker(peoplePickerElementId, username, isMultiselect) {

    // Create a schema to store picker properties, and set the properties.
    var schema = {};
    schema['PrincipalAccountType'] = 'User,DL,SecGroup,SPGroup';
    schema['SearchPrincipalSource'] = 15;
    schema['ResolvePrincipalSource'] = 15;
    schema['AllowMultipleValues'] = isMultiselect;
    schema['MaximumEntitySuggestions'] = 50;
    schema['Width'] = '280px';

    // Render and initialize the picker. 
    // Pass the ID of the DOM element that contains the picker, an array of initial
    // PickerEntity objects to set the picker value, and a schema that defines
    // picker properties.
    this.SPClientPeoplePicker_InitStandaloneControlWrapper(peoplePickerElementId, null, schema);
    if (username != null && username.length) {
        var peoplePicker = this.SPClientPeoplePicker.SPClientPeoplePickerDict[peoplePickerElementId + "_TopSpan"];
        peoplePicker.AddUserKeys(username);
    }
}

function getMultipleUserId(loginName, userarray) {

    var dfd = $.Deferred();
    var context = new SP.ClientContext.get_current();
    var user = context.get_web().ensureUser(loginName);
    userlogin = loginName;
    context.load(user);
    context.executeQueryAsync(
          function () {
              userarray.push(user.get_id());
              console.log("ID" + user.get_id());
              dfd.resolve();
          },
         function (sender, args) {
             dfd.reject();
             console.log("Error1::" + args.message)
         }

    );

    return dfd.promise();

}


function overlay(message) {
    $("body").append("<div id='overlay'></div>");
    $("#overlay").css({
        'position': 'fixed',
        'top': 0,
        'left': 0,
        'height': '100%',
        'width': '100%',
        'background-color': 'rgba(0,0,0,0.8)',
        'z-index': 65555,
    });
    $("body").append("<div id='modal' style='text-align:center;'><span class='preloaderimg'></span><br/><span class='loading-pop' style='display:block;'>" + message + "</span></div>");
    $("#modal").css({
        'position': 'fixed',
        'top': 'calc(50% - 64px)',
        'left': 'calc(50% - 64px)',
        'z-index': 75555, /* 1px higher than the overlay layer */
    });

}

function addOverlay(message) {
    if (!message) {
        message = "Please Wait...<br/>We are working on it"
    }

    $("body").append("<div id='overlay'></div>");
    $("#overlay").css({
        'position': 'fixed',
        'top': 0,
        'left': 0,
        'height': '100%',
        'width': '100%',
        'background-color': 'rgba(0,0,0,0.8)',
        'z-index': 1000,
    });
    $("body").append("<div id='modal' style='text-align:center;'><span class='preloaderimg'></span><br/><span class='loading-pop' style='display:block;'>" + message + "</span></div>");
    $("#modal").css({
        'position': 'fixed',
        'top': 'calc(50% - 64px)',
        'left': 'calc(50% - 64px)',
        'z-index': 1000, /* 1px higher than the overlay layer */
    });

}
function removeOverlay() {
    // $("body").remove("<div id='overlay'></div>");
    $("#overlay").remove();
    $("#overlay").hide();
    $("#modal").remove();
    $("#modal").hide();
}


function sendEmail(/*from, */to, body, subject) {

    var urlTemplate = _spPageContextInfo.webAbsoluteUrl + "/_api/SP.Utilities.Utility.SendEmail";

    var formDigest = document.getElementById("__REQUESTDIGEST").value;

    $.ajax({

        contentType: 'application/json',

        url: urlTemplate,

        type: 'POST',

        data: JSON.stringify({

            'properties': {

                '__metadata': { 'type': 'SP.Utilities.EmailProperties' },

                //'From': from,

                'To': { 'results': [to] },

                'Subject': subject,

                'Body': body

            }

        }

      ),

        headers: {

            "Accept": "application/json;odata=verbose",

            "content-type": "application/json;odata=verbose",

            "X-RequestDigest": formDigest

        },

        success: function (data) {

            var result = data.d.results;

            //var i = result.length;

        },

        error: function (err) {

            console.log("Commaon.js - sendEmail :Error: " + JSON.stringify(err));

        }

    });

}

function GetEmailTemplateByName(templateName) {
    var dfd = $.Deferred();
    var EmailTemplate = {};
    var ctx = SP.ClientContext.get_current();
    var templatelist = ctx.get_web().get_lists().getByTitle(EmailTemplateListName);
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name=\'Title\'/>' +
        '<Value Type=\'Text\'>' + templateName + '</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>');

    var Items = templatelist.getItems(camlQuery);
    ctx.load(Items);
    ctx.executeQueryAsync(
        function (sender, args) {
            var RquestEnum = Items.getEnumerator();
            while (RquestEnum.moveNext()) {

                EmailTemplate.Subject = RquestEnum.get_current().get_fieldValues().Subject;
                EmailTemplate.Body = RquestEnum.get_current().get_fieldValues().Body;
                EmailTemplate.To = RquestEnum.get_current().get_fieldValues().To;
                EmailTemplate.CC = RquestEnum.get_current().get_fieldValues().CC;
            }

            dfd.resolve(EmailTemplate);
        },
        function (sender, args) {
            dfd.reject();
            console.log("Common.js Method:'GetEmailTemplateByName.' Error:" + args.get_message());

        });
    return dfd.promise();

};//End of GetEmailTemplateByName



function SetCookie() {
    //document.cookie = "ArchiverId=";
    //alert(readCookie("ArchiverId"));
    if (readCookie("ArchiverId") == null) {
        var dfdCurrentloggedInUser = SPUser.getCurrent();
        dfdCurrentloggedInUser.done(function (currentUser) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + 100);
            document.cookie = "ArchiverId=," + currentUser.get_id() + ",; expires=" + exdate.toUTCString();
            __doPostBack('ctl00$idMyIdeasHomepage$ctl01', '__cancel');
            //__doPostBack('ctl00$idMyProjectsHomepage$ctl01','__cancel');
            setTimeout("__doPostBack('ctl00$idMyProjectsHomepage$ctl01','__cancel')", 2500);

        });
    }
}


function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}


$(document).ready(function () {
    //Browser compatibility message
    var ie_version = getIEVersion();

    var is_chrome = /chrome/i.test(navigator.userAgent);

    if ((parseInt(ie_version.major) < 10) && !is_chrome) {
        var brwMsgHtml = '<div class="brw-msg">The application is best supported in IE 10 and above versions and Chrome <a class="close-button">&nbsp;</a></div>';
        $('#s4-bodyContainer').append(brwMsgHtml);
        $("a.close-button").click(function () {
            $("div.brw-msg").fadeOut("slow");
        });
    }

    ExecuteOrDelayUntilScriptLoaded(SetCookie, "sp.js");

    var modalHTML = '<div id="openModal" class="modalDialog">' +
                           '<div style="height:auto"> <a href="#close" title="Close" class="closepopup" onclick="CloseContactUsFormClicked()">X</a>' +
                               '<div class="group">' +
                                   '<div class="col" style="width:100%" id="querySubject">' +
                                       '<label class="label1">Subject</label>' +
                                       '<label class="label2"><input type="text" placeholder="Type your subject here..." style="width:100%"/></label>' +
                                   '</div>' +
                               '</div>' +
                               '<div class="group">' +
                                   '<div class="col" style="width:100%" id="queryContent">' +
                                       '<label class="label1">Content</label>' +
                                       '<label class="label2"><textarea placeholder="Type your content here..." style="width:100%;height:50px"/></label>' +
                                   '</div>' +
                               '</div>' +
                               '<input type="button" id="SubmitContactUs" onclick="SendQuery()" class="default" value="Send" style="margin-top: 10px !important;"/> ' +
                           '</div>' +
                       '</div>';

    $('body').append(modalHTML);


});

function SendQuery() {
    var subject = $('.modalDialog #querySubject input').val();
    var content = $('.modalDialog #queryContent textarea').val().trim();
    if (subject) {
        if (content) {
            $('#SubmitContactUs')[0].removeAttribute('onclick');
            var mailBody = 'Hi,<br/><br/>@Content<br/><br/> Thanks,<br/><a href="mailto:@SendersEmail"> @SendersName</a>';
            mailBody = mailBody.replace('@Content', content);
            mailBody = mailBody.replace('@SendersName', SPUser.current.get_title());
            mailBody = mailBody.replace('@SendersEmail', SPUser.current.get_email());
            //sendEmail('enterpriseprojectmgmtoffice@discover.com',mailBody ,subject);

            AddContactUsQuestionToList(subject, content, SPUser.current.get_title()).done(function () {
                //				sendContactUsEmail(['testwf'],mailBody ,subject).done(function(){
                window.location.href = '#';
                alert('Your question was successfully submitted. You will be contacted shortly.\nThank you.');
                $('.modalDialog #querySubject input').val("");
                $('.modalDialog #queryContent textarea').val("");
                $('#SubmitContactUs').attr('onclick', 'SendQuery()');
                //}).fail(function(){});

            }).fail(function () { $('#SubmitContactUs').attr('onclick', 'SendQuery()'); });
        }
        else
            alert('Please enter some content to send.');
    }
    else
        alert('Please enter subject.');


}

function CloseContactUsFormClicked() {
    $('.modalDialog #querySubject input').val("");
    $('.modalDialog #queryContent textarea').val("");

}

function AddContactUsQuestionToList(subject, content, UserDisplayName) {
    var dfd = new $.Deferred();
    var ctx = SP.ClientContext.get_current();
    var web = ctx.get_web();
    var lists = web.get_lists();
    var ContactUsLogsList = lists.getByTitle("ContactUsLogs");
    var ListItemCreation = new SP.ListItemCreationInformation();
    var newTask = ContactUsLogsList.addItem(ListItemCreation);
    newTask.set_item("Title", subject);
    newTask.set_item("Content", content);
    newTask.set_item("From", UserDisplayName);

    newTask.update();
    ctx.load(newTask);
    ctx.executeQueryAsync(function (data) {
        dfd.resolve();
        console.log("Added entry in Contact Us List");
    }, function (sender, args) {
        console.log("Error while creating entry in Contact Us List:" + args.message);
        dfd.reject();
    });

    return dfd.promise();


}


function OpenDownloadDocument(docURL, docTitle, docFileType) {
	//var tempDiv=$('<div></div>',{});//decode escape chars
	//tempDiv.html(docTitle);
	//docTitle=tempDiv.text();
    if (isIEBrowser()) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", docURL);
        xhr.responseType = "blob";//force the HTTP response, response-type header to be blob
        xhr.onload = function () {
            var blobobj = xhr.response;//xhr.response is now a blob object
            // window.navigator.msSaveBlob(blobobj , "fileName new .pdf");
            window.navigator.msSaveOrOpenBlob(blobobj, docTitle + "." + docFileType);
        }
        xhr.send();
    }
    else {
        var anchor = document.createElement('a');
        anchor.href = docURL;
        anchor.download = docTitle + '.' + docFileType;
        anchor.click();
    }
}


function isIEBrowser() {
    return /msie/i.test(navigator.userAgent) && !/opera/i.test(navigator.userAgent);
}

function getIEVersion() {
    var agent = navigator.userAgent;
    var reg = /MSIE\s?(\d+)(?:\.(\d+))?/i;
    var matches = agent.match(reg);
    if (matches != null) {
        return { major: matches[1], minor: matches[2] };
    }
    return { major: "-1", minor: "-1" };
}

/* function sendContactUsEmail(/*from, * /to, body, subject) {

    var urlTemplate = _spPageContextInfo.webAbsoluteUrl + "/_api/SP.Utilities.Utility.SendEmail";

    var formDigest = document.getElementById("__REQUESTDIGEST").value;

    var dfd = $.ajax({

        contentType: 'application/json',

        url: urlTemplate,

        type: 'POST',

        data: JSON.stringify({

            'properties': {

                '__metadata': { 'type': 'SP.Utilities.EmailProperties' },

                //'From': from,

                'To': { 'results': to },

                'Subject': subject,

                'Body': body

            }

        }

      ),

        headers: {

            "Accept": "application/json;odata=verbose",

            "content-type": "application/json;odata=verbose",

            "X-RequestDigest": formDigest

        },

        success: function (data) {

            //var result = data.d.results;
            dfd.resolve();

            //var i = result.length;

        },

        error: function (err) {

            dfd.reject(JSON.stringify(err));
            console.log("Commaon.js - sendEmail :Error: " + JSON.stringify(err));

        }

    });

    return dfd.promise();

}*/
