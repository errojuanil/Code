﻿/**
 * @Author: ANIL KUMAR YERROJU
 * @Created on: 07/19/2017
 * @Last Modified: 12/20/2017.
 * @Reason for Modification: DEC-2017 Changes/Enhancements
 *							 Implemented Currency Format.
 *							 Replaced Date fields with Duration fields
 *							 Added new GL name drop downs for Financial Planner and Provisioner-PSM			
 * @Application: ADC Approval Management Automation.
 * @Page Name: EDIT REQUEST PAGE.
 * @summary: This page used to modify the existing request details.
 		     Modification allowed only for the request's status is Open/Returned/Pending Financial Planner Approval
 **/


var CRUDobj = DDOCS.ListItemManager();
var EditRequest = {};
EditRequest.RequestListName = 'ADC Approval Requests';
EditRequest.CostCenterListName = 'BT Cost Center Hierarchy';
EditRequest.GLNameListName = 'GL List';
EditRequest.VendorsListName = 'Vendors';
EditRequest.ProjectsListName = "Projects";
EditRequest.IdeasListName = "Ideas";
EditRequest.SOWStatusListName = 'SOW Status';
EditRequest.WorkTypeListName = 'Work Type';
EditRequest.ProjectListURL = 'https://discoverfinancial.sharepoint.com/sites/BTPrjArtfcts';
EditRequest.CostCenterListURL = 'https://discoverfinancial.sharepoint.com/sites/BT2016BudPlan';
EditRequest.IsAdditionalVendorEanbled = 'NO';
EditRequest.IdeaCheckBoxEnabled = 'NO';
EditRequest.costCenterDirectorEmail=null;
EditRequest.ccFinancialPlannerEmail=null;
EditRequest.costCenterVPEmail=null;
EditRequest.CurrentUser = null;
EditRequest.IsFromEditRequest = false;

EditRequest.RequestData = {};//For the requests which are in  draft mode

/*EditRequest.backButtonHtml = '<div class="groupbutton">' +
						            '<input type="reset" onclick="history.back();" class="reset" value="Back" name="Submit2">' +
						    	'</div>'; */


EditRequest.init = function () {
    if (document.URL.indexOf("?") >= 0) {
        EditRequest.RequestID = getQueryStringParameter("RequestID");

        if (getQueryStringParameter("EditRequest"))
            EditRequest.IsFromAllRequests = true;
        $('.requestId').text(EditRequest.RequestID);

        ExecuteOrDelayUntilScriptLoaded(EditRequest.load, "sp.js");
        
   

        $('#div-amount').hide();
        $('#div-rate').hide();
        $('#div-rate2').hide();
        
        $('#additionalVendorPanel1').hide();
        
         $('#div-durationVendor1Label').hide();
         $('#div-durationVendor1').hide();
         $('#div-durationVendor2Label').hide();
         $('#div-durationVendor2').hide();
        
        //Additional Vendor
        $('#div-amount2').hide();
		$('#div-toNumber').hide();
		$('#additionalVendorPanel1').hide();
		$('#additionalVendorPanelEdit2').hide();
	    $('#btnAdditionalVendorDisable').hide();
	    $('#btnAdditionalVendorEnable').hide();

	
	    $('#div-finPlannerCommentsPanel').hide();
        $('#div-finPlannerComments').hide();
	 	$('#div-isPlanned').hide();
	 	//$('#div-planID').hide();
		$('#div-toNumber').hide();
		$('#div-sowNumber').hide();
		$('#div-sowStatus').hide();
		$('#div-headCountPlan').hide();
		$('#div-clarityUpdated').hide();
		$('#div-controlPanel1').hide();
		$('#div-controlPanel2').hide();
		$('#div-finPlannerGLProposal').hide();
		

	 	$('#btnApprove').hide(); 
   	    $('#btnReturn').hide(); 
   	    $('#btnSubmit').hide(); 
   	    $('#btnSave').hide(); 
   	    
   	     $('#chkIdea').change(function() {
        	if ($(this).is(':checked')) { //For Idea
        		EditRequest.IdeaCheckBoxEnabled = 'YES';
        	    $('#div-clarityProjectID .label2').text('');
     	  	    $('#div-clarityProjectName input').last().val('');
				 EditRequest.populateSelectCAMLLookupProjectOrCostCenter('#div-clarityProjectName select',EditRequest.IdeasListName, 'Name',EditRequest.ProjectListURL);      	  	          	  	
      	  	  // lstRequest.populateSelectCAMLLookup('#div-clarityProjectName select', lstRequest.ideaListName, 'Name');
			   }
       	    if (!$(this).is(':checked')) { // For Project
       	    EditRequest.IdeaCheckBoxEnabled = 'NO';
       	    	$('#div-clarityProjectID .label2').text('');
				$('#div-clarityProjectName input').last().val('');
				EditRequest.populateSelectCAMLLookupProjectOrCostCenter('#div-clarityProjectName select',EditRequest.ProjectsListName, 'Name',EditRequest.ProjectListURL);
				//lstRequest.populateSelectCAMLLookup('#div-clarityProjectName select', lstRequest.prjListName, 'Name');

       	     }
		 });
		 
		 
		

        // $('#div-costCenter').on('change', function () {
         $('#div-costCenter').focusout(function () {

	   		  // $('#div-costCenterName .label2').text('');
	 		  // $('#div-costCenterDirector .label2').text('');
          		EditRequest.populateSelectCAMLCostCenter('div-costCenterName label2', EditRequest.CostCenterListName, 'Title');
		       }); 

        
        // $('#div-clarityProjectName').on('change', function () {
        $('#div-clarityProjectName').focusout(function () {
        
        if(EditRequest.IdeaCheckBoxEnabled =='YES')          
         {  EditRequest.populateSelectCAML('div-clarityProjectID label2', EditRequest.IdeasListName, 'Title');}
         if(EditRequest.IdeaCheckBoxEnabled == 'NO')
         { EditRequest.populateSelectCAML('div-clarityProjectID label2', EditRequest.ProjectsListName, 'Title');}
         

         	 //	EditRequest.populateSelectCAML('div-clarityProjectID label2', EditRequest.ProjectsListName, 'Title');
        		}); 
        	
        //$('#div-vendorName').on('change', function () {
        $('#div-vendorName').focusout(function () {
          EditRequest.populateSelectCAML('div-rate input', EditRequest.VendorsListName, 'Title');
           }); 
         
         $('#div-vendorName2').focusout(function () {
          EditRequest.populateSelectCAML('div-rate2 input', EditRequest.VendorsListName, 'Title');
           });
           
        $("#div-headCount").keypress(function( event ){
		    var key = event.which;
		    if( ! ( key >= 48 && key <= 57 ) )
		    event.preventDefault();	});
	
	 	$("#div-rate").keypress(function( event ){
    		var key = event.which;
		    if( ! ( key >= 48 && key <= 57 ) )
	        event.preventDefault();	});
	
	 	$("#div-amount").keypress(function( event ){
   			 var key = event.which;
		    if( ! ( key >= 48 && key <= 57 ) )
	        event.preventDefault();	});
	        
	    // Additional Vendor 
	         $("#div-headCount2").keypress(function( event ){
		    var key = event.which;
		    if( ! ( key >= 48 && key <= 57 ) )
		    event.preventDefault();	});
	
	 	$("#div-rate2").keypress(function( event ){
    		var key = event.which;
		    if( ! ( key >= 48 && key <= 57 ) )
	        event.preventDefault();	});
	
	 	$("#div-amount2").keypress(function( event ){
   			 var key = event.which;
		    if( ! ( key >= 48 && key <= 57 ) )
	        event.preventDefault();	});


    }
};


EditRequest.load = function () {
    EditRequest.GetRequestDetails(EditRequest.RequestID);
    

};


EditRequest.GetRequestDetails = function (RequestId) {
    var dfd = $.Deferred();
    var ctx = SP.ClientContext.get_current();
    var ApprovalList = ctx.get_web().get_lists().getByTitle(EditRequest.RequestListName);
    var RequestItem = ApprovalList.getItemById(RequestId);
    //EditRequest.isRequestInReview = false;

    ctx.load(RequestItem);
    ctx.executeQueryAsync(
		function (sender, args) {

		    var reqID = RequestItem.get_item("ID");
		    console.log("Req Title -" + RequestItem.get_item("Title"));
	       // EditRequest.RequestData["reqID"] = reqID;
	        EditRequest.RequestData["Status"] = RequestItem.get_item("Status");
  	        EditRequest.RequestData["Requestor"] = RequestItem.get_item("Author").get_lookupValue();
	        EditRequest.RequestData["RequestorId"]= RequestItem.get_item("Author").get_lookupId();
	        EditRequest.RequestData["RequestedDate"] = RequestItem.get_item("Created");
		    EditRequest.RequestData["VP"] = RequestItem.get_item("VP").get_lookupValue();
 	        EditRequest.RequestData["VPEmail"] = RequestItem.get_item("VP").get_email();
			EditRequest.RequestData["Director"] = RequestItem.get_item("Director").get_lookupValue();
 	        EditRequest.RequestData["DirectorEmail"] = RequestItem.get_item("Director").get_email();
			EditRequest.RequestData["Manager"] = RequestItem.get_item("Manager").get_lookupValue();
	        EditRequest.RequestData["ManagerEmail"] = RequestItem.get_item("Manager").get_email();
   		    EditRequest.RequestData["CostCenter"] = RequestItem.get_item("Title");
   		    EditRequest.RequestData["CostCenterName"] = RequestItem.get_item("CostCenterName");
			EditRequest.RequestData["CostCenterDirector"] = RequestItem.get_item("CostCenterDirector").get_lookupValue();
			EditRequest.RequestData["CostCenterDirectorEmail"] = RequestItem.get_item("CostCenterDirector").get_email();
			EditRequest.RequestData["CCFinancialPlanner"] = RequestItem.get_item("CCFinancialPlanner").get_lookupValue();
			EditRequest.RequestData["CCFinancialPlannerEmail"] = RequestItem.get_item("CCFinancialPlanner").get_email();
			EditRequest.RequestData["CCFinancialPlannerId"]= RequestItem.get_item("CCFinancialPlanner").get_lookupId();
			EditRequest.RequestData["CostCenterVP"] = RequestItem.get_item("CostCenterVP").get_lookupValue();
			EditRequest.RequestData["CostCenterVPEmail"] = RequestItem.get_item("CostCenterVP").get_email();
			EditRequest.RequestData["ProjectName"] = RequestItem.get_item("Clarity_x0020_ProjectName");
   		    EditRequest.RequestData["ProjectNumber"] = RequestItem.get_item("Clarity_x0020_ProjectID");
   		    if(EditRequest.RequestData["ProjectNumber"].startsWith('ID'))
 					{  $('#chkIdea').prop( "checked", true ); 					
 					}
 			else {
 				 $('#chkIdea').prop( "checked", false ); 	
 				 					}

		    EditRequest.RequestData["WorkType"] = RequestItem.get_item("Work_x0020_Type");
		    EditRequest.RequestData["GLName"] = RequestItem.get_item("GLName");		   
		    EditRequest.RequestData["FinPlannerGLProposal"] = RequestItem.get_item("FinPGLProposal");	
   		    EditRequest.RequestData["PlanID"] = RequestItem.get_item("Plan_x0020_ID");
		   // EditRequest.RequestData["Initiator"] = RequestItem.get_item("Initiator").get_lookupValue();
		   // EditRequest.RequestData["InitiatorId"] = RequestItem.get_item("Initiator").get_lookupId();
		    EditRequest.RequestData["VendorName"] = RequestItem.get_item("Vendor_x0020_Name");
		    EditRequest.RequestData["HeadCount"] = RequestItem.get_item("Head_x0020_Count");
   		    EditRequest.RequestData["Rate"] = RequestItem.get_item("Rate");
   		    EditRequest.RequestData["Amount"] = RequestItem.get_item("Amount");
   		    
   		    // Commented Date fields as per DEC-2017 Changes
   		    //EditRequest.RequestData["StartDate"] = RequestItem.get_item("Start_x0020_Date");
   		    //EditRequest.RequestData["EndDate"] = RequestItem.get_item("End_x0020_Date");

   		    // Added Duration fields as per DEC-2017 Changes.
   		     EditRequest.RequestData["DurationVendor1"] = RequestItem.get_item("DurationVendor1");
   		    
   		    // Additional Vendor Details
   		    EditRequest.RequestData["HasAdditionalVendor"] = RequestItem.get_item("HasAdditionalVendor");
   		    EditRequest.RequestData["VendorName2"] = RequestItem.get_item("Vendor_x0020_Name2");
		    EditRequest.RequestData["HeadCount2"] = RequestItem.get_item("Head_x0020_Count2");
   		    EditRequest.RequestData["Rate2"] = RequestItem.get_item("Rate2");
   		    EditRequest.RequestData["Amount2"] = RequestItem.get_item("Amount2");
   		    
   		    // Commented Date fields as per DEC-2017 Changes
   		    //EditRequest.RequestData["StartDate2"] = RequestItem.get_item("Start_x0020_Date2");
   		    //EditRequest.RequestData["EndDate2"] = RequestItem.get_item("End_x0020_Date2");
   		    
   		    // Added Duration fields as per DEC-2017 Changes.
   		     EditRequest.RequestData["DurationVendor2"] = RequestItem.get_item("DurationVendor2");

   		    EditRequest.RequestData["TONumber"] = RequestItem.get_item("TO_x0020_Number");
	  	 	EditRequest.RequestData["HeadCountPlan"] = RequestItem.get_item("Headcount_x0020_Plan_x0020_Updat");
		    EditRequest.RequestData["ClarityUpdated"] = RequestItem.get_item("Clarity_x0020_Updated");
		    EditRequest.RequestData["IsPlanned"] = RequestItem.get_item("IsPlanned");
		    EditRequest.RequestData["SOWStatus"] = RequestItem.get_item("SOW_x0020_Status");		    		    	  	 	
		    EditRequest.RequestData["SOWNumber"] = RequestItem.get_item("SOW_x0020_Number");
		    EditRequest.RequestData["RequestorComments"] = RequestItem.get_item("Requestor_x0020_Comments");
   	        EditRequest.RequestData["FinPlannerComments"] = RequestItem.get_item("Financial_x0020_Planner_x0020_Co");
		  
		   EditRequest.onload(reqID);
		       

		    dfd.resolve();
		},
		function (sender, args) {
		    dfd.reject();
		    console.log("Page:'EditRequest.aspx' Method:'EditRequest.GetRequestDetails.' Error:" + args.get_message());

		});
    return dfd.promise();


};//End of GetRequestDetails

EditRequest.onload = function (requestID) {


	  
    EditRequest.CurrentDate = new Date();
	EditRequest.CurrentDate.setHours(0,0,0,0);
	var dd, mm, y;
    var dfdCurrentloggedInUser = SPUser.getCurrent();
    dfdCurrentloggedInUser.done(function (currentUser) {
    
    
    	// Financial Planner's View.
    var abc= IsCurrentUserMemberOfGroup("ADC-FinancialPlanners", function (isCurrentUserInGroup) {
    
     if (EditRequest.RequestData.RequestorId == currentUser.get_id() && (EditRequest.RequestData.Status == 'Returned'||EditRequest.RequestData.Status == 'Open')) 
	 	{
	 	   if(EditRequest.RequestData.FinPlannerComments)
    		{  $('#div-finPlannerComments').show();
	 		   $('#div-finPlannerComments input').prop("readonly",true);
	 		  }
	 	$('#div-durationVendor1').show();
	 	$('#div-durationVendor2').show();
	 	
	 	$('#btnSubmit').show(); 
   	    $('#btnSave').show(); 
 		
		}
         
     else if(isCurrentUserInGroup&&EditRequest.RequestData.Status == 'Pending Financial Planner Approval')
   		{
   		
   		// Commented below fields as per 08/23 demo.
    	//$('#div-controlPanel1').show();
	   // $('#div-controlPanel2').show();
	    //$('#div-planID').show();
		//$('#div-toNumber').show();
		//$('#div-sowNumber').show();
		//$('#div-sowStatus').show();
		//$('#div-headCountPlan').show();
		//$('#div-clarityUpdated').show();
		
		$('#div-durationVendor1Label').show();
	 	$('#div-durationVendor2Label').show();

		$('#div-requestorComments input').prop("readonly",true);
	    $('#div-finPlannerComments').show();
	    $('#div-finPlannerCommentsPanel').show();
	    $('#div-finPlannerGLProposal').show();
	 	$('#div-isPlanned').show();
	 	$('#btnApprove').show(); 
   	    $('#btnReturn').show(); 
   	  
    	}
    	else if(EditRequest.RequestData.CCFinancialPlannerId == currentUser.get_id()&&EditRequest.RequestData.Status == 'Pending Financial Planner Approval')
   		{
   		$('#div-durationVendor1Label').show();
	 	$('#div-durationVendor2Label').show();
	 	
   		$('#div-requestorComments input').prop("readonly",true);
	    $('#div-finPlannerComments').show();
 	    $('#div-finPlannerCommentsPanel').show();
	    $('#div-finPlannerGLProposal').show();
	 	$('#div-isPlanned').show();
	 	$('#btnApprove').show(); 
   	    $('#btnReturn').show(); 
   		
   		}

    	else  {	
		 $('.enterArea').hide(); 
		 $('#btnClear').hide();
		 $('.padding-block').html('Modification for this request is not allowed.').show();		
  			   }
   	});
   
    	
    	$('#div-reqStatus .label2').text(EditRequest.RequestData.Status);
    	//if(EditRequest.RequestData.Status=='Closed')	 { 	 $('#div-reqStatus .label2').css("color", "green"); }
	 if(EditRequest.RequestData.Status=='Rejected')	 { 	 $('#div-reqStatus .label2').css("color", "red"); }
  	 if(EditRequest.RequestData.Status=='Approved')	 { 	 $('#div-reqStatus .label2').css("color", "green"); }
 	 if(EditRequest.RequestData.Status=='Pending Review Committee Approval')	 { 	 $('#div-reqStatus .label2').css("color", "green"); }
  	 if(EditRequest.RequestData.Status=='Pending Financial Planner Approval')	 { 	 $('#div-reqStatus .label2').css("color", "orange"); }
	 if(EditRequest.RequestData.Status=='Returned')	 { 	 $('#div-reqStatus .label2').css("color", "orange"); }
  	 if(EditRequest.RequestData.Status=='Open')	 { 	 $('#div-reqStatus .label2').css("color", "blue"); }

	    $('#div-requestor .label2').text(EditRequest.RequestData.Requestor);

        EditRequest.ReqDate=EditRequest.RequestData.RequestedDate;
     	dd = EditRequest.ReqDate.getDate();
    	mm = EditRequest.ReqDate.getMonth()+1;
        y = EditRequest.ReqDate.getFullYear();		
        $('#div-requestedDate .label2').text(mm + '/' + dd + '/' + y); 
	    
	    initializePeoplePicker('peoplePickerDivVP', EditRequest.RequestData.VPEmail, false);
  	    initializePeoplePicker('peoplePickerDivDirector', EditRequest.RequestData.DirectorEmail, false);
   	    initializePeoplePicker('peoplePickerDivManager', EditRequest.RequestData.ManagerEmail, false);
   		
   	 $('#div-costCenterName .label2').text(EditRequest.RequestData.CostCenterName);
   	 
     $('#div-costCenterDirector .label2').text(EditRequest.RequestData.CostCenterDirector);
		EditRequest.costCenterDirectorEmail=EditRequest.RequestData.CostCenterDirectorEmail;
		
	 $('#div-costCenterFinancialPlanner .label2').text(EditRequest.RequestData.CCFinancialPlanner);
	 	EditRequest.ccFinancialPlannerEmail=EditRequest.RequestData.CCFinancialPlannerEmail;
	 	
	 $('#div-costCenterVP .label2').text(EditRequest.RequestData.CostCenterVP);
	 	EditRequest.costCenterVPEmail=EditRequest.RequestData.CostCenterVPEmail;
  	 
	//Vendor Name
    var dfdVendorName = EditRequest.GetVendorName();
    dfdVendorName.done(function () {
       if (EditRequest.RequestData.VendorName) {
            EditRequest.VendorName= EditRequest.RequestData.VendorName? EditRequest.RequestData.VendorName: "";
           // EditRequest.WorkTypeId = EditRequest.RequestData.WorkType;
        } 

        var optionArr = $('#selectVendorName').find('option');
        var $selectVendorName= $.grep(optionArr, function (element, index) {
            return element.text == EditRequest.VendorName;

        });

        if ($selectVendorName.length)
            $('#selectVendorName').val($selectVendorName[0].value);
       // else
          //  $('#selecteWorkType').val(EditRequest.WorkTypeId);
        $('#selectVendorName').combobox();

    });

  		 
    //Work Type
    var dfdWorkType = EditRequest.GetWorkType();
    dfdWorkType.done(function () {
       if (EditRequest.RequestData.WorkType) {
            EditRequest.WorkType = EditRequest.RequestData.WorkType? EditRequest.RequestData.WorkType : "";
           // EditRequest.WorkTypeId = EditRequest.RequestData.WorkType;
        } 

        var optionArr = $('#selectWorkType').find('option');
        var $selectWorkType = $.grep(optionArr, function (element, index) {
            return element.text == EditRequest.WorkType;

        });

        if ($selectWorkType.length)
            $('#selectWorkType').val($selectWorkType[0].value);
       // else
          //  $('#selecteWorkType').val(EditRequest.WorkTypeId);
        $('#selectWorkType').combobox();

    });
    
    //GL Name for User
    var dfdGLName = EditRequest.GetGLName();
    dfdGLName.done(function () {
       if (EditRequest.RequestData.GLName) {
            EditRequest.GLName= EditRequest.RequestData.GLName? EditRequest.RequestData.GLName: "";
           // EditRequest.WorkTypeId = EditRequest.RequestData.WorkType;
        } 

        var optionArr = $('#selectGLName').find('option');
        var $selectGLName = $.grep(optionArr, function (element, index) {
            return element.text == EditRequest.GLName;

        });

        if ($selectGLName.length)
            $('#selectGLName').val($selectGLName[0].value);
       // else
          //  $('#selecteWorkType').val(EditRequest.WorkTypeId);
        $('#selectGLName').combobox();

    });
    
     //Added "GL Name for Financial Planner GL Proposal" on 12/19/2017
    var dfdFinPlannerGLProposal = EditRequest.GetFinPlannerGLProposal();
    dfdFinPlannerGLProposal.done(function () {
       if (EditRequest.RequestData.FinPlannerGLProposal) {
            EditRequest.FinPlannerGLProposal= EditRequest.RequestData.FinPlannerGLProposal? EditRequest.RequestData.FinPlannerGLProposal: "";
           // EditRequest.WorkTypeId = EditRequest.RequestData.WorkType;
        }
        else
          EditRequest.FinPlannerGLProposal='Select';

        var optionArr = $('#selectFinPlannerGLProposal').find('option');
        var $selectFinPlannerGLProposal = $.grep(optionArr, function (element, index) {
            return element.text == EditRequest.FinPlannerGLProposal;

        });

        if ($selectFinPlannerGLProposal.length)
            $('#selectFinPlannerGLProposal').val($selectFinPlannerGLProposal[0].value);
       // else
          //  $('#selecteWorkType').val(EditRequest.WorkTypeId);
        $('#selectFinPlannerGLProposal').combobox();

    });

    
    
  //SOW Status
  var dfdSOWStatus = EditRequest.GetSOWStatus();
   dfdSOWStatus.done(function () {
       if (EditRequest.RequestData.SOWStatus) {
            EditRequest.SOWStatus= EditRequest.RequestData.SOWStatus? EditRequest.RequestData.SOWStatus: "";
           // EditRequest.WorkTypeId = EditRequest.RequestData.WorkType;
        } 

        var optionArr = $('#selectSOWStatus').find('option');
        var $selectSOWStatus = $.grep(optionArr, function (element, index) {
            return element.text == EditRequest.SOWStatus;

        });

        if ($selectSOWStatus.length)
            $('#selectSOWStatus').val($selectSOWStatus[0].value);
       // else
          //  $('#selecteWorkType').val(EditRequest.WorkTypeId);
        $('#selectSOWStatus').combobox();

    });

//ProjectName
if((EditRequest.RequestData.ProjectNumber).startsWith('ID'))
 { 
 
 EditRequest.populateSelectCAMLLookupProjectOrCostCenter('#div-clarityProjectName select',EditRequest.IdeasListName, 'Name',EditRequest.ProjectListURL);
 }
else{ EditRequest.populateSelectCAMLLookupProjectOrCostCenter('#div-clarityProjectName select',EditRequest.ProjectsListName, 'Name',EditRequest.ProjectListURL);}
  var dfdProjectName = EditRequest.GetProjectName();
   dfdProjectName.done(function () {
       if (EditRequest.RequestData.ProjectName) {
            EditRequest.ProjectName= EditRequest.RequestData.ProjectName? EditRequest.RequestData.ProjectName: "";
        } 

        var optionArr = $('#selectProjectName').find('option');
        var $selectProjectName = $.grep(optionArr, function (element, index) {
            return element.text == EditRequest.ProjectName;

        });

        if ($selectProjectName.length)
            $('#selectProjectName').val($selectProjectName[0].value);
            $('#selectProjectName').combobox();

    }); 
    
  //Cost Center
  EditRequest.populateSelectCAMLLookupProjectOrCostCenter('#div-costCenter select',EditRequest.CostCenterListName, 'Title',EditRequest.CostCenterListURL);
  var dfdCostCenter = EditRequest.GetCostCenter();
   dfdCostCenter.done(function () {
       if (EditRequest.RequestData.CostCenter) {
            EditRequest.CostCenter= EditRequest.RequestData.CostCenter? EditRequest.RequestData.CostCenter: "";
           // EditRequest.WorkTypeId = EditRequest.RequestData.WorkType;
        } 

        var optionArr = $('#selectCostCenter').find('option');
        var $selectCostCenter = $.grep(optionArr, function (element, index) {
            return element.text == EditRequest.CostCenter;

        });

        if ($selectCostCenter.length)
            $('#selectCostCenter').val($selectCostCenter[0].value);
       // else
          //  $('#selecteWorkType').val(EditRequest.WorkTypeId);
        $('#selectCostCenter').combobox();

    });

     $('#div-clarityProjectID .label2').text(EditRequest.RequestData.ProjectNumber);
    
     $('#div-planID input').val(EditRequest.RequestData.PlanID);
     
     $('#div-headCount input').val(EditRequest.RequestData.HeadCount);
     
     if(EditRequest.RequestData.VendorName.startsWith('Managed'))
     { $('#div-amount input').val(EditRequest.RequestData.Amount); 
       $('#div-amount').show();	
     
     }
     else { $('#div-rate input').val(EditRequest.RequestData.Rate); $('#div-rate').show(); }
      $('#div-durationVendor1 input').val(EditRequest.RequestData.DurationVendor1.toFixed(1));
      $('#div-durationVendor1Label .label2').text(EditRequest.RequestData.DurationVendor1.toFixed(1));

     
     /* // Commented Date fields as per DEC-2017 Changes. 
     EditRequest.SDate=EditRequest.RequestData.StartDate;
     dd = EditRequest.SDate.getDate();
     mm = EditRequest.SDate.getMonth()+1;
     y = EditRequest.SDate.getFullYear();		
     $('#div-sDate input').val(mm + '/' + dd + '/' + y); 

     EditRequest.EDate=EditRequest.RequestData.EndDate;
     dd = EditRequest.EDate.getDate();
     mm = EditRequest.EDate.getMonth()+1;
     y = EditRequest.EDate.getFullYear();		
     $('#div-eDate input').val(mm + '/' + dd + '/' + y);  */
     
     // Additional Vendor Details
     if(EditRequest.RequestData.HasAdditionalVendor)
     {
     EditRequest.IsAdditionalVendorEanbled = 'YES';
     $('#btnAdditionalVendor').hide();
     $('#btnAdditionalVendorDisable').show();
    
     $('#additionalVendorPanel1').show();
	 $('#additionalVendorPanelEdit2').show();

     $('#div-headCount2 input').val(EditRequest.RequestData.HeadCount2);
     
     if(EditRequest.RequestData.VendorName2.startsWith('Managed'))
     { $('#div-amount2 input').val(EditRequest.RequestData.Amount2); 
       $('#div-amount2').show();	
     
     }
     else { $('#div-rate2 input').val(EditRequest.RequestData.Rate2); $('#div-rate2').show(); }
    
    $('#div-durationVendor2 input').val(EditRequest.RequestData.DurationVendor2.toFixed(1));
    $('#div-durationVendor2Label .label2').text(EditRequest.RequestData.DurationVendor2.toFixed(1));
     /* // Commented Date fields as per DEC-2017 Changes.
     EditRequest.SDate2=EditRequest.RequestData.StartDate2;
     dd = EditRequest.SDate2.getDate();
     mm = EditRequest.SDate2.getMonth()+1;
     y = EditRequest.SDate2.getFullYear();		
     $('#div-sDate2 input').val(mm + '/' + dd + '/' + y); 

     EditRequest.EDate2=EditRequest.RequestData.EndDate2;
     dd = EditRequest.EDate2.getDate();
     mm = EditRequest.EDate2.getMonth()+1;
     y = EditRequest.EDate2.getFullYear();		
     $('#div-eDate2 input').val(mm + '/' + dd + '/' + y); */
     
     //Additional Vendor Details..
    var dfdVendorName2 = EditRequest.GetVendorName2();
    dfdVendorName2.done(function () {
       if (EditRequest.RequestData.VendorName2) {
            EditRequest.VendorName2= EditRequest.RequestData.VendorName2? EditRequest.RequestData.VendorName2: "";
           // EditRequest.WorkTypeId = EditRequest.RequestData.WorkType;
        } 

        var optionArr = $('#selectVendorName2').find('option');
        var $selectVendorName2= $.grep(optionArr, function (element, index) {
            return element.text == EditRequest.VendorName2;

        });

        if ($selectVendorName2.length)
            $('#selectVendorName2').val($selectVendorName2[0].value);
       // else
          //  $('#selecteWorkType').val(EditRequest.WorkTypeId);
        $('#selectVendorName2').combobox();

    });

   } // End of Additional Vendor
  else if(!EditRequest.RequestData.HasAdditionalVendor)
    {
    	EditRequest.populateSelectCAMLLookupProjectOrCostCenter('#div-vendorName2 select', EditRequest.VendorsListName, 'Title');    
    }

     $('#div-toNumber input').val(EditRequest.RequestData.TONumber);
     $('#div-headCountPlan input').val(EditRequest.RequestData.HeadCountPlan);
     $('#div-clarityUpdated input').val(EditRequest.RequestData.ClarityUpdated);
    /* if(EditRequest.RequestData.IsPlanned ==1)
     $('#div-isPlanned .label2').text('Yes');
     else 
      $('#div-isPlanned .label2').text('No'); */
     $('#div-sowStatus input').val(EditRequest.RequestData.SOWStatus);
     $('#div-sowNumber input').val(EditRequest.RequestData.SOWNumber);

     $('#div-requestorComments input').val(EditRequest.RequestData.RequestorComments);
     if(EditRequest.RequestData.FinPlannerComments)
     $('#div-finPlannerComments input').val(EditRequest.RequestData.FinPlannerComments);

    
   });
};//End of EditRequest.onload


//Function for loading "Vendor Name" drop down
EditRequest.GetVendorName = function () {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
        url: url = _spPageContextInfo.webAbsoluteUrl +
         "/_api/Web/Lists/getbytitle('" + EditRequest.VendorsListName + "')/Items/",
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var VendorName= data.d.results;
        var ddlVendorName = $('#selectVendorName');
        
        for (var i = 0; i < VendorName.length; i++) {
            var option = $("<option />");
            option.attr("value", VendorName[i].ID);
            option.text(VendorName[i].Title);
            ddlVendorName.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetVendorName

// Additional Vendor Details...
//Function for loading "Vendor Name" drop down
EditRequest.GetVendorName2 = function () {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
        url: url = _spPageContextInfo.webAbsoluteUrl +
         "/_api/Web/Lists/getbytitle('" + EditRequest.VendorsListName+ "')/Items?",
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var VendorName2= data.d.results;
        var ddlVendorName2 = $('#selectVendorName2');
        
        for (var i = 0; i < VendorName2.length; i++) {
            var option = $("<option />");
            option.attr("value", VendorName2[i].ID);
            option.text(VendorName2[i].Title);
            ddlVendorName2.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetVendorName


//Function for loading "Work Type" drop down
EditRequest.GetWorkType = function () {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
        url: url = _spPageContextInfo.webAbsoluteUrl +
         "/_api/Web/Lists/getbytitle('" + EditRequest.WorkTypeListName + "')/Items/",
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var Worktype = data.d.results;
        var ddlWorkType = $('#selectWorkType');
        
        for (var i = 0; i < Worktype.length; i++) {
            var option = $("<option />");
            option.attr("value", Worktype[i].ID);
            option.text(Worktype[i].Title);
            ddlWorkType.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetWorkype


//Function for loading "GL Name" drop down for User
EditRequest.GetGLName = function () {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
        url: url = _spPageContextInfo.webAbsoluteUrl +
        // "/_api/Web/Lists/getbytitle('" + EditRequest.GLNameListName + "')/Items/",
        "/_api/Web/Lists/getbytitle('" + EditRequest.GLNameListName + "')/Items?$filter=UserFlag eq 1",
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var GLName = data.d.results;
        var ddlGLName = $('#selectGLName');
        
        for (var i = 0; i < GLName.length; i++) {
            var option = $("<option />");
            option.attr("value", GLName[i].ID);
            option.text(GLName[i].Title);
            ddlGLName.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetGLName


//Added Function for loading "GL Name" drop down for Financial Planner for GL Proposal on 12/19/2017 
EditRequest.GetFinPlannerGLProposal = function () {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
        url: url = _spPageContextInfo.webAbsoluteUrl +
        // "/_api/Web/Lists/getbytitle('" + EditRequest.GLNameListName + "')/Items/",
        "/_api/Web/Lists/getbytitle('" + EditRequest.GLNameListName + "')/Items?$filter=FinancialPlannerFlag eq 1",
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var FinPlannerGLProposal = data.d.results;
        var ddlFinPlannerGLProposal = $('#selectFinPlannerGLProposal');
        
        for (var i = 0; i < FinPlannerGLProposal.length; i++) {
            var option = $("<option />");
            option.attr("value", FinPlannerGLProposal[i].ID);
            option.text(FinPlannerGLProposal[i].Title);
            ddlFinPlannerGLProposal.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetGLName for Financial Planner GL proposal



//Function for loading "SOWStatus" drop down
EditRequest.GetSOWStatus = function () {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
        url: url = _spPageContextInfo.webAbsoluteUrl +
         "/_api/Web/Lists/getbytitle('" + EditRequest.SOWStatusListName + "')/Items/",
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var SOWStatus= data.d.results;
        var ddlSOWStatus = $('#selectSOWStatus');
        
        for (var i = 0; i < SOWStatus.length; i++) {
            var option = $("<option />");
            option.attr("value", SOWStatus[i].ID);
            option.text(SOWStatus[i].Title);
            ddlSOWStatus.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetSOWStatus

//Function for loading "Get Clarity Project Name" drop down 
/*EditRequest.GetProjectName = function () {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
        url: url = EditRequest.ProjectListURL +"/_api/Web/Lists/getbytitle('" + EditRequest.ProjectsListName + "')/Items/",
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var ProjectName= data.d.results;
        var ddlProjectName = $('#selectProjectName');
        
        for (var i = 0; i < ProjectName.length; i++) {
            var option = $("<option />");
            option.attr("value", ProjectName[i].ID);
            option.text(ProjectName[i].Name);
            ddlProjectName.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetProjectName */

EditRequest.GetProjectName = function () {
    var dfd = $.Deferred();
    var vURL;

if((EditRequest.RequestData.ProjectNumber).startsWith('ID'))
{
vURL = EditRequest.ProjectListURL +"/_api/Web/Lists/getbytitle('" + EditRequest.IdeasListName + "')/Items?$filter=Name eq '"+EditRequest.RequestData.ProjectName+"'";
}
else {
vURL = EditRequest.ProjectListURL +"/_api/Web/Lists/getbytitle('" + EditRequest.ProjectsListName + "')/Items?$filter=Name eq '"+EditRequest.RequestData.ProjectName+"'";

}

    var call = jQuery.ajax({
        url: url = vURL,
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var ProjectName= data.d.results;
        var ddlProjectName = $('#selectProjectName');
        
        for (var i = 0; i < ProjectName.length; i++) {
            var option = $("<option />");
            option.attr("value", ProjectName[i].ID);
            option.text(ProjectName[i].Name);
            ddlProjectName.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetProjectName


//
EditRequest.populateSelectCAMLLookupProjectOrCostCenter = function (element, listName, fieldName, siteURL) {
	
	//$('#selectProjectName').append(EditRequest.RequestData.ProjectName);
    var docFieldName = EditRequest.getFieldName(element)

    var sValue = EditRequest.getFieldValue(docFieldName);

   // var sUrl = "https://discoverfinancial.sharepoint.com/sites/TestBTPrjArtfcts";
    //var ctx = new SP.ClientContext(sUrl);
    if (listName == "Projects"||listName == "Ideas")
    {
    //var sUrl = siteURL;
    var ctx = new SP.ClientContext(siteURL);
    }
    else if(listName == "BT Cost Center Hierarchy")
    {
    //var sUrl = siteURL;
    var ctx = new SP.ClientContext(siteURL);
	}
	else 
	{
	var ctx = SP.ClientContext.get_current();	
	}
    
    var list = ctx.get_web().get_lists().getByTitle(listName);

    var camlQuery = new SP.CamlQuery();
    
    if (sValue != '')
        camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="ID"/><Value Type="Counter">' + sValue + '</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
    else
        camlQuery.set_viewXml('<View><Query><Where></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');

    var lstItems = list.getItems(camlQuery);
    ctx.load(lstItems);
    ctx.executeQueryAsync(
	function (sender, args) {
	    var selectHtml = "";
	    var distinctItems = [];
	    var ItemEnum = lstItems.getEnumerator();
	    while (ItemEnum.moveNext()) {
	      
	        var itemValue = ItemEnum.get_current().get_item('ID');
	        var itemTitle = ItemEnum.get_current().get_item(fieldName);
			 
	        var $dupItems = $.grep(distinctItems, function (element, index) {
	            return element.value == itemValue;
	        });
	     if (!$dupItems.length)
	        	            distinctItems.push({ 'value': itemValue, 'title': itemTitle });

	    }
	    for (var i = 0; i < distinctItems.length; i++) {
	    	        selectHtml += '<option value="' + distinctItems[i].value + '">' + distinctItems[i].title + '</option>';
	    }
	    
	    $(element).append(selectHtml);
	    $(element).attr('data', '{"listName":"' + listName + '","fieldName":"' + fieldName + '","valueFieldName":"ID"}');
 	    $(element).val(sValue);
	    $(element).combobox(); 
	},
	function (sender, args) {
	    console.log("Page:'Request.aspx' Method:'lstRequest.populateSelectInitiator.' Error:" + args.get_message());

	});
};


EditRequest.getFieldName=function(element){
	var fieldName='';

	switch(element)
	{
		case '#div-clarityProjectID select': fieldName='Title';
				break;

		case '#div-vendorName select': fieldName='Title';
				break;
		
		default:break;
	}
	return fieldName;
};
EditRequest.getFieldValue = function (fieldName) {
    var fieldValue = '';
    if (sessionStorage.searchQuery && sessionStorage.searchQuery != '') {
    	var paramJson =JSON.parse(sessionStorage.searchQueryJson);
    	var fieldJson= $.grep(paramJson,function(element){
			return element.name==fieldName;
		});
		if(fieldJson.length)
    		fieldValue=fieldJson[0].value;
    }
    return fieldValue;
	
};


//Function for loading "Get Cost Center details" drop down
EditRequest.GetCostCenter = function () {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
        url: url = EditRequest.CostCenterListURL +"/_api/Web/Lists/getbytitle('" + EditRequest.CostCenterListName + "')/Items?$filter=Title eq '"+EditRequest.RequestData.CostCenter+"'",

        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var CostCenter= data.d.results;
        var ddlCostCenter = $('#selectCostCenter');
        
        for (var i = 0; i < CostCenter.length; i++) {
            var option = $("<option />");
            option.attr("value", CostCenter[i].ID);
            option.text(CostCenter[i].Title);
            ddlCostCenter.append(option);

        }

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetCostCenter


EditRequest.populateSelectCAML = function (element, listName, fieldName) {
    //var docFieldName = lstRequest.getFieldName(element)
    
    if(listName == "Projects"||listName == "Ideas")
    {
    
    var sValue = jQuery("#div-clarityProjectName option:selected").val();

    var sUrl = EditRequest.ProjectListURL;
    var ctx = new SP.ClientContext(sUrl);
    }
    else if(listName == "Vendors")
    {
       if(element=="div-rate input"){ var sValue = jQuery("#div-vendorName option:selected").val(); }
        if(element=="div-rate2 input"){ var sValue = jQuery("#div-vendorName2 option:selected").val(); }

         var ctx = SP.ClientContext.get_current();
    }
    var list = ctx.get_web().get_lists().getByTitle(listName);
    var camlQuery = new SP.CamlQuery();
     if (sValue != '')
     {
     // if(listName == "Projects")
           camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="ID"/><Value Type="Counter">' + sValue + '</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
 	  //else camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="' + fieldName + '"/><Value Type="Text">' + sValue + '</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
      }
     
     
	
    var lstItems = list.getItems(camlQuery);
    ctx.load(lstItems);
    ctx.executeQueryAsync(
	function (sender, args) {
	    var selectHtml = "";
		
   
	     var ItemEnum = lstItems.getEnumerator();

	    while (ItemEnum.moveNext()) {
	        if(listName == "Projects"||listName == "Ideas")
    		{
    		 var itemTitle = ItemEnum.get_current().get_item('Title');
    		 $('#div-clarityProjectID .label2').text(itemTitle);
    		}
    		
    		if(listName == "Vendors")
    		{
    		  var itemVendor = ItemEnum.get_current().get_item('Title');
    		  var itemRate = ItemEnum.get_current().get_item('Rate');
    		  if(itemVendor.startsWith('Managed'))
    		  {  
    		   	if(element=="div-rate input") { $('#div-rate').hide(); $('#div-amount').show();}
    		   	if(element=="div-rate2 input") { $('#div-rate2').hide(); $('#div-amount2').show();}
  		  	
    		  }
    		  else 
    		   { 
    		    if(element=="div-rate input") { $('#div-rate').show(); $('#txtRate').val(itemRate); $('#div-amount').hide(); }
     		    if(element=="div-rate2 input") { $('#div-rate2').show(); $('#txtRate2').val(itemRate); $('#div-amount2').hide(); }

    		    } 

			 }
	      }
	},
	function (sender, args) {
	    console.log("Page:'Request.aspx' Method:'lstRequest.populateSelectCAML.' Error:" + args.get_message());

	});

};

/// Populating cost center related fields fields
EditRequest.populateSelectCAMLCostCenter = function (element, listName, fieldName) {
    //var docFieldName = lstRequest.getFieldName(element)
    
    if(listName == "BT Cost Center Hierarchy")
    {
    
    var sValue = jQuery("#div-costCenter option:selected").text();

    var ctx = new SP.ClientContext(EditRequest.CostCenterListURL);
    }
   
    var list = ctx.get_web().get_lists().getByTitle(listName);
    var camlQuery = new SP.CamlQuery();
     
 	  camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="' + fieldName + '"/><Value Type="Text">' + sValue + '</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
     	
    var lstItems = list.getItems(camlQuery);
    ctx.load(lstItems);
    ctx.executeQueryAsync(
	function (sender, args) {
	    var selectHtml = "";
		var ItemEnum = lstItems.getEnumerator();

	    while (ItemEnum.moveNext()) {
	         var costCenterName = ItemEnum.get_current().get_item('Cost_x0020_Center_x0020_Desc');
	         
         
	         var costCenterDirector = ItemEnum.get_current().get_item('Dir_x0020_Name0').get_lookupValue();
	         EditRequest.costCenterDirectorEmail = ItemEnum.get_current().get_item('Dir_x0020_Name0').get_email();
	         
	         var ccFinancialPlanner = ItemEnum.get_current().get_item('Planner').get_lookupValue();
	         EditRequest.ccFinancialPlannerEmail = ItemEnum.get_current().get_item('Planner').get_email();
	         
     	     var costCenterVP = ItemEnum.get_current().get_item('VP_x0020_Name0').get_lookupValue();
     	     EditRequest.costCenterVPEmail= ItemEnum.get_current().get_item('VP_x0020_Name0').get_email();

	         if(costCenterName)
    		 $('#div-costCenterName .label2').text(costCenterName);
    		 if(costCenterDirector)
    		 $('#div-costCenterDirector .label2').text(costCenterDirector);
    		 if(ccFinancialPlanner)
    		 $('#div-costCenterFinancialPlanner .label2').text(ccFinancialPlanner);
    		 if(costCenterVP)
    		 $('#div-costCenterVP .label2').text(costCenterVP);
    		 }
	},
	function (sender, args) {
	    console.log("Page:'Request.aspx' Method:'lstRequest.populateSelectCAML.' Error:" + args.get_message());

	});

};

EditRequest.EnableAdditionalVendor= function (RequestType) {
 
   if (RequestType == "Enable")
    { 
     EditRequest.IsAdditionalVendorEanbled='YES';
     $('#btnAdditionalVendorDisable').show();
     $('#additionalVendorPanel1').show();
	 $('#additionalVendorPanelEdit2').show();
	 $('#btnAdditionalVendor').hide();	
	 $('#div-rate2').show();	 
    }
	    
   else if (RequestType == "Disable")
	    {
	     EditRequest.IsAdditionalVendorEanbled='NO';
	    $('#btnAdditionalVendor').show();
	    $('#additionalVendorPanel1').hide();
	    $('#additionalVendorPanelEdit2').hide();
	    $('#btnAdditionalVendorDisable').hide();
   
	   }
	  
};//End of EditRequest.EnableAdditionalVendor



//EditRequest.SubmitRequest
EditRequest.SubmitRequest = function (RequestType) {
    if (RequestType == "Save")
    {  EditRequest.UpdateRequestDetails(RequestType);
    }
    else if (RequestType == "Approve")
    {   EditRequest.UpdateRequestDetails(RequestType);
    }
    else if (RequestType == "Return")
    {   EditRequest.UpdateRequestDetails(RequestType);
    }
     else if (RequestType == "Back")
    {    window.location.href = 'ViewRequest.aspx?RequestID='+EditRequest.RequestID;
    }
    else
    {   EditRequest.UpdateRequestDetails(RequestType);      
    }   

};//End of EditRequest.SubmitRequest


EditRequest.UpdateRequestDetails = function (RequestType){
    
    var MgrInfo = [];
	var DirInfo = [];
	var VPInfo = [];
	var peoplepickerManagerInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-manager .sp-peoplepicker-topLevel').attr('id')];
    var peoplepickerDirectorInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-director .sp-peoplepicker-topLevel').attr('id')];
    var peoplepickerVPInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-vp .sp-peoplepicker-topLevel').attr('id')];
    var peoplepickerCostCenterDirectorInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-costCenterDirector .sp-peoplepicker-topLevel').attr('id')];
    
    var FromDate, ToDate, Status, ProjectID, ProjectName, CostCenter, CostCenterName, CostCenterDirector,
     CCFinancialPlanner, CostCenterVP, WorkType, GLName, PlanID, HeadCount, VendorName,DurationVendor1, DurationVendor2, Rate, EstMonthlySpend,
     Amount, TONumber, HeadCountPlan, ClarityUpdated, IsPlanned, SowStatus, SowNumber, RequestorComments, FinPlannerComments,
     FinPlannerGLProposal;
        
        
	ProjectID= $('#div-clarityProjectID .label2').text();
	ProjectName = $('#div-clarityProjectName input').last().val();
	CostCenter= $('#div-costCenter input').last().val();
	CostCenterName = $('#div-costCenterName .label2').text();
	CostCenterDirector = $('#div-costCenterDirector .label2').text();
	CCFinancialPlanner = $('#div-costCenterFinancialPlanner .label2').text();
	CostCenterVP = $('#div-costCenterVP .label2').text();
	WorkType = $('#div-workType input').last().val();
	GLName= $('#div-glName input').last().val();
	HeadCount= $('#div-headCount input').last().val();
	VendorName= $('#div-vendorName input').last().val();
	Rate= $('#div-rate input').last().val();
	Amount= $('#div-amount input').last().val();
	
	//Commented PSM fields
	PlanID= $('#div-planID input').last().val();
	//TONumber= $('#div-toNumber input').last().val();
	//HeadCountPlan= $('#div-headCountPlan input').last().val();
	//ClarityUpdated= $('#div-clarityUpdated input').last().val();
	IsPlanned= $('#div-isPlanned select').last().val();
	
	SowStatus= $('#div-sowStatus input').last().val();
	SowNumber= $('#div-sowNumber input').last().val();
	RequestorComments = $('#div-requestorComments input').last().val();
	FinPlannerComments = $('#div-finPlannerComments input').last().val();
	FinPlannerGLProposal= $('#div-finPlannerGLProposal input').last().val();
	
	
	
	if(RequestType== 'Save')
	{
	
	 Status = 'Open';
	 IsPlanned = 'false'; 
	 DurationVendor1= $('#div-durationVendor1 input').last().val();
	 DurationVendor2= $('#div-durationVendor2 input').last().val();
	     
      // Duration field validation for Vendor1.
        if(!DurationVendor1)
        {
        alert("Enter all required fields marked with *.");
                    return;	
        }
        else if(DurationVendor1.indexOf('.') != -1)
        {
         	var noOfDigits = DurationVendor1.length;
         	 var dots = 0;
             for(var i=0; i<noOfDigits; i++) {
             	if(DurationVendor1[i]=='.') dots++;
            	 if(dots>1) {
               	 	alert("Duration field allows only one dot, enter data correctly");
               		 return; }
               		
               	 else if(DurationVendor1.indexOf('.')+2!=noOfDigits)
         			{
        				 alert("Duration field allows only one digit after decimal, enter data correctly");
         				 return;	
           		    }
           }        
         } // End of validation for Vendor1 Duration.
         
         
         
	 
	 
	}
	if(RequestType== 'Submit')
	{Status= 'Pending Financial Planner Approval';
	 IsPlanned = 'false'; 
	 DurationVendor1= $('#div-durationVendor1 input').last().val();
	 DurationVendor2= $('#div-durationVendor2 input').last().val();
	   // Duration field validation for Vendor1.
        if(!DurationVendor1)
        {
        alert("Enter all required fields marked with *.");
                    return;	
        }
        else if(DurationVendor1.indexOf('.') != -1)
        {
         	var noOfDigits = DurationVendor1.length;
         	 var dots = 0;
             for(var i=0; i<noOfDigits; i++) {
             	if(DurationVendor1[i]=='.') dots++;
            	 if(dots>1) {
               	 	alert("Duration field allows only one dot, enter data correctly");
               		 return; }
               		
               	 else if(DurationVendor1.indexOf('.')+2!=noOfDigits)
         			{
        				 alert("Duration field allows only one digit after decimal, enter data correctly");
         				 return;	
           		    }
           }        
         } // End of validation for Vendor1 Duration.
     
	}
	
	
	if(RequestType== 'Approve')
	{
		DurationVendor1= $('#div-durationVendor1Label .label2').text();
		DurationVendor2= $('#div-durationVendor2Label .label2').text();
	   
		if(IsPlanned == "" ||!IsPlanned)
   		{  alert("Enter all required fields marked with *.");
                    return;	
        }
        
     	else if(IsPlanned == 'Yes')
     	{ Status= 'Approved'; IsPlanned = 'true'; }
     	
     	else if(IsPlanned == 'No')
     	{ Status= 'Pending Review Committee Approval'; IsPlanned = 'false'; }
    }
    if(RequestType== 'Return')
	{Status = 'Returned';
	 IsPlanned = 'false'; 
	}
 
     /* // Commented Date fields as per DEC-2017 Changes
    if ($("#datepickerfrom").val()) {
        FromDate = new Date($("#datepickerfrom").val());
    }
    if ($("#datepickerto").val()) {
        ToDate = new Date($("#datepickerto").val());
    }  */
    
    if(!peoplepickerManagerInfo.HasResolvedUsers()||!peoplepickerDirectorInfo.HasResolvedUsers()||!peoplepickerVPInfo.HasResolvedUsers())
        {  alert("Enter all required fields marked with *.");
                     return;	
        }
      
   
    if(!CostCenter||!ProjectName||!WorkType||!GLName||!HeadCount||!VendorName)
   		{  alert("Enter all required fields marked with *.");
                    return;	
        }
     
     /* // Commented Date fields as per DEC-2017 Changes
    if (FromDate == null || ToDate == null) {
          alert("Enter all required fields marked with *.");
        	return;	
	    }
    else if (ToDate < FromDate) {
        alert("End date should be greater that or equal to Start date");
        return;	
	    } 
	    
	  //Total Amount calculation for Non-Managed Vendors 
	  
	   Duration = (ToDate-FromDate)/(1000 * 60 * 60 * 24);
	   Duration = Duration/30.5; */
	  //Duration = ToDate.diff(FromDate, 'days');  
	  if(!VendorName.startsWith('Managed'))
    	{
    	 if(!Rate)
    		{  alert("Enter all required fields marked with *.");
                    return;	
       		}
       		else {EstMonthlySpend = Rate*HeadCount*170;
       		 	  Amount = EstMonthlySpend*DurationVendor1; }
    	}
   	  else 	{  
   	  		if(!Amount)
    		{  alert("Enter all required fields marked with *."); return; }
    		else { Amount; Rate=0; }
          }
          
         //Additional Vendor Details
    	var VendorName2, Rate2, HeadCount2, EstMonthlySpend2, Amount2, FromDate2, ToDate2; 
   		
   	    VendorName2= $('#div-vendorName2 input').last().val();
		HeadCount2= $('#div-headCount2 input').last().val();
		Rate2= $('#div-rate2 input').last().val();
		Amount2= $('#div-amount2 input').last().val();

     if(EditRequest.IsAdditionalVendorEanbled=='YES')
     {  
     	if(RequestType== 'Save'||RequestType== 'Submit')
     	{
 		       
         // Duration field validation for Vendor2.
        if(!DurationVendor2)
        {
        alert("Enter all required fields marked with * for Additional Vendor.");
                    return;	
        }
        else if(DurationVendor2.indexOf('.') != -1)
        {
         	var noOfDigits = DurationVendor2.length;
         	 var dots = 0;
             for(var i=0; i<noOfDigits; i++) {
             	if(DurationVendor2[i]=='.') dots++;
            	 if(dots>1) {
               	 	alert("Duration field allows only one dot, enter data correctly for Additional Vendor.");
               		 return; }
               		
               	 else if(DurationVendor2.indexOf('.')+2!=noOfDigits)
         			{
        				 alert("Duration field allows only one digit after decimal, enter data correctly for Additional Vendor.");
         				 return;	
           		    }
           }        
         } // End of validation for Vendor2 Duration.
         
         }
 
     	 /*	// Commented Date fields as per DEC-2017 Changes		
     	 if ($("#datepickerfrom2").val()) {
       	 FromDate2 = new Date($("#datepickerfrom2").val());  }
       	 
    	 if ($("#datepickerto2").val()) {
         ToDate2 = new Date($("#datepickerto2").val()); } 

        if(!VendorName2||!HeadCount2)
   		{  alert("Enter all required fields marked with * for Additional Vendor.");
                    return;	
      	 }
       	if (FromDate2 == null || ToDate2 == null) {
          alert("Enter all required fields marked with * for Additional Vendor.");
        	return;	
	    }
       else if (ToDate2 < FromDate2) {
        alert("Additional Vendor's End date should be greater that or equal to Start date");
        return;	
	    } 
	   //Additional Vendor -- Total Amount calculation for Non-Managed Vendors 
       Duration2 = (ToDate2-FromDate2)/(1000 * 60 * 60 * 24);
	   Duration2 = Duration2/30.5; */
 	  if(!VendorName2.startsWith('Managed'))
    	{
    	 if(!Rate2)
    		{  alert("Enter all required fields marked with * for Additional Vendor.");
                    return;	
       		}
       		else {
       			  EstMonthlySpend2 = Rate2*HeadCount2*170;
       		 	  Amount2 = EstMonthlySpend2*DurationVendor2;
       		 	  }
    	}
   	   else 
   	    {  
   	  		if(!Amount2)
    		{  alert("Enter all required fields marked with * for Additional Vendor."); return; }
    		else { Amount2; Rate2=0; }
        } 
        
      }
          getUserId(EditRequest.costCenterVPEmail).done(function (CostCenterVPID) {
          getUserId(EditRequest.ccFinancialPlannerEmail).done(function (CCFinancialPlannerID) {
           getUserId(EditRequest.costCenterDirectorEmail).done(function (CostCenterDirectorID) {
            
            MgrInfo = peoplepickerManagerInfo.GetAllUserInfo();
            getUserId(MgrInfo[0].Description).done(function (managerid) {

            DirInfo = peoplepickerDirectorInfo.GetAllUserInfo();
        	getUserId(DirInfo[0].Description).done(function (directorid) {
            
      		VPInfo= peoplepickerVPInfo.GetAllUserInfo();
  			getUserId(VPInfo[0].Description).done(function (vpid) {
  			
  			addOverlay("Please Wait...<br/>We Are Processing Your Request.");
		
		  if(EditRequest.IsAdditionalVendorEanbled=='YES')
        	{
	           var datasource =
                   {
                   		
                		"VPId": vpid,
                        "DirectorId": directorid,
                        "ManagerId": managerid,
                        "CostCenterDirectorId":CostCenterDirectorID,
                        "CCFinancialPlannerId":CCFinancialPlannerID,
                        "CostCenterVPId":CostCenterVPID,
                        "Title": CostCenter,
                        "CostCenterName":CostCenterName, 
						"Status": Status,
                        "Clarity_x0020_ProjectID": ProjectID,
                        "Clarity_x0020_ProjectName": ProjectName,
                        "Work_x0020_Type": WorkType,
                        // Vendor Details
                        "Vendor_x0020_Name": VendorName,
                        "DurationVendor1": DurationVendor1, // Added duration filed as per DEC-2017 Changes
                        //"Start_x0020_Date": FromDate, // Commented Date fields as per DEC-2017 Changes
                        //"End_x0020_Date": ToDate, 	// Commented Date fields as per DEC-2017 Changes
                        "Head_x0020_Count": HeadCount,
                        "Rate": Rate,
                        "Amount": Amount,

                        // Additional Vendor Details
                        "HasAdditionalVendor": 'true',
                        "Vendor_x0020_Name2": VendorName2,
                        "DurationVendor2": DurationVendor2,  // Added duration filed as per DEC-2017 Changes
                        //"Start_x0020_Date2": FromDate2, // Commented Date fields as per DEC-2017 Changes
                        //"End_x0020_Date2": ToDate2,	  // Commented Date fields as per DEC-2017 Changes
                        "Head_x0020_Count2": HeadCount2,
                        "Rate2": Rate2,
                        "Amount2": Amount2,
                        "GLName": GLName,
                        "FinPGLProposal": FinPlannerGLProposal, 
                       	"Requestor_x0020_Comments": RequestorComments,
                       	"Financial_x0020_Planner_x0020_Co": FinPlannerComments,
                        "Plan_x0020_ID": PlanID
                  };
              }

		  
		  else if(EditRequest.IsAdditionalVendorEanbled=='NO')
        		  {	        		
	           var datasource =
                   {
                   		
                		"VPId": vpid,
                        "DirectorId": directorid,
                        "ManagerId": managerid,
                        "CostCenterVPId":CostCenterVPID,
                        "CCFinancialPlannerId":CCFinancialPlannerID,
                        "CostCenterDirectorId":CostCenterDirectorID,
                        "Title": CostCenter,
                        "CostCenterName":CostCenterName, 
                        "DurationVendor1": DurationVendor1,  // Added duration filed as per DEC-2017 Changes
                        //"Start_x0020_Date": FromDate,	// Commented Date fields as per DEC-2017 Changes
                       // "End_x0020_Date": ToDate,
                        "Status": Status,
                        "Clarity_x0020_ProjectID": ProjectID,
                        "Clarity_x0020_ProjectName": ProjectName,
                        "Work_x0020_Type": WorkType,
                        "Head_x0020_Count": HeadCount,
                        "Rate": Rate,
                        "Amount": Amount,
                        "Vendor_x0020_Name": VendorName,
                        "GLName": GLName, 
                        "FinPGLProposal": FinPlannerGLProposal,
                       	"Requestor_x0020_Comments": RequestorComments,
                       	"Financial_x0020_Planner_x0020_Co": FinPlannerComments,
						
						// Additional Vendor
						"HasAdditionalVendor":'false',
						"Amount2": 0,
                     	"Plan_x0020_ID": PlanID,
                        //"TO_x0020_Number": TONumber,
                      	//"Headcount_x0020_Plan_x0020_Updat": HeadCountPlan,
                      	//"Clarity_x0020_Updated": ClarityUpdated,
                       	"IsPlanned": IsPlanned,
                      	"SOW_x0020_Status": SowStatus,
                      	"SOW_x0020_Number": SowNumber

                  };
                }
               var response = CRUDobj.UpdateItemUtility("ADC Approval Requests", datasource,EditRequest.RequestID,"", "", "ADC_x0020_Approval_x0020_Requests").done(function () {         
             		
                    //alert("Request Deatails are updated.");
                    window.location.href = 'Home.aspx';
                   //ClearFields();
                   // __doPostBack('ctl00$PlaceHolderMain$g_03d15d1e_76fa_435f_bc36_7f899054e860$ctl01','__cancel')
	                            
                }).fail(function (jqxHR, textStatus, errorThrown) {
                    alert("1Page:'EditRequest.aspx' Error:" + errorThrown)
                }); 
            }).fail(function (jqxHR, textStatus, errorThrown) {
                alert("2Page:'EditRequest.aspx' Error:" + errorThrown)
               
            });
            
             }).fail(function (jqxHR, textStatus, errorThrown) {
            alert("3Page:'EditRequest.aspx' Error:" + errorThrown)
        });
        
        
         }).fail(function (jqxHR, textStatus, errorThrown) {
            alert("4Page:'EditRequest.aspx' Error:" + errorThrown)
        });
        
     }).fail(function (jqxHR, textStatus, errorThrown) {
          alert("5Page:'EditRequest.aspx' Error:" + errorThrown)
      });
   }).fail(function (jqxHR, textStatus, errorThrown) {
          alert("6Page:'EditRequest.aspx' Error:" + errorThrown)
  });
  
  }).fail(function (jqxHR, textStatus, errorThrown) {
          alert("7Page:'EditRequest.aspx' Error:" + errorThrown)
  });


 //   }
}


//Common Get the user ID.
function getUserId(loginName) {

    var dfd = $.Deferred();
    var context = new SP.ClientContext.get_current();
    var user = context.get_web().ensureUser(loginName);
    userlogin = loginName;
    context.load(user);
    context.executeQueryAsync(
          function () {
              dfd.resolve(user.get_id());
          },
         function (sender, args) {
             dfd.reject();
             console.log("Error1:")
         }

    );

    return dfd.promise();

}

//Common Check current user details in mentioned Group 
function IsCurrentUserMemberOfGroup(groupName, OnComplete) {

        var currentContext = new SP.ClientContext.get_current();
        var currentWeb = currentContext.get_web();

        var currentUser = currentContext.get_web().get_currentUser();
        currentContext.load(currentUser);

        var allGroups = currentWeb.get_siteGroups();
        currentContext.load(allGroups);

        var group = allGroups.getByName(groupName);
        currentContext.load(group);

        var groupUsers = group.get_users();
        currentContext.load(groupUsers);

        currentContext.executeQueryAsync(OnSuccess,OnFailure);

        function OnSuccess(sender, args) {
            var userInGroup = false;
            var groupUserEnumerator = groupUsers.getEnumerator();
            while (groupUserEnumerator.moveNext()) {
                var groupUser = groupUserEnumerator.get_current();
                if (groupUser.get_id() == currentUser.get_id()) {
                    userInGroup = true;
                    break;
                }
            }  
            OnComplete(userInGroup);
        }

        function OnFailure(sender, args) {
            OnComplete(false);
        }    
}



$(document).ready(function () {

	$('#datepickerfrom').datetimepicker({
        timepicker: false,
        format: 'm/d/Y',  });
         
    $('#datepickerto').datetimepicker({
        timepicker: false,
        format: 'm/d/Y',  });
        
    $('#datepickerfrom2').datetimepicker({
        timepicker: false,
        format: 'm/d/Y',  });
         
    $('#datepickerto2').datetimepicker({
        timepicker: false,
        format: 'm/d/Y',  });


    SPUser.getCurrent().done(function (user) {
        EditRequest.CurrentUser = user;
        EditRequest.init();
    })
   .fail(function (msg) {
       console.log(msg);
   });
   
});
