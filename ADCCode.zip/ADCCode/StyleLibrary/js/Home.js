﻿/**
 * @Author: Anil Kumar Yerroju
 * @Created on: 07/19/2017
 * @Last Modified: available at file properties.
 * @Application: ADC Approval Management Automation.
 * @summary: This page displays user submitted and user involved requests to the user.
 			 Along with a "Request Status" filter.
 * 
 **/

SP.SOD.executeFunc('sp.js', 'SP.ClientContext', ready);
function ready() {
    // some code here
}
// Constants
ADCApprovalList ="ADC Approval Requests";

SearchRequest = function () {
	var filterStatus =   $('#div-RequestStatus option:selected').text();
	if(filterStatus=="Select")
	{   alert("Please select status filter");
		return false;
	}
	else
	{
	$('#FilterGrid').empty();
    $('#RequestGrid').empty();
	DefaultLoad();

	}
};

PopulateClear = function () {
  //$('#ddlRequestStatus').val("Select");
 //$('#FilterGrid').empty();
 //$('#RequestGrid').empty();
 __doPostBack('ctl00$PlaceHolderMain$g_03d15d1e_76fa_435f_bc36_7f899054e860$ctl01','__cancel')

		  
};


// Function to append the list data to HTML grid.
function GenerateTableFromJson(objArray) {
          

 var tableContent = '<table id="RequestTable" style="width:100%"><thead><tr>' +
 '<td><b>Request Number</b></td>' + 
 '<td><b>Request Status</b></td>'+ 
 '<td><b>Approval Pending With</b></td>'+ 
 '<td><b>Requested By</b></td>'+ 
 '<td><b>Requested Date</b></td>'+ 
 '<td><b>Cost Center</b></td>'+ 
  '<td><b>GLName</b></td>'+ 
// '<td><b>Clarity Project Name</b></td>'+ 
 '<td><b>Clarity Project No</b></td>'+ 

// '<td><b>Work Type</b></td>'+ 
//'<td><b>Vendor Name</b></td>'+
// '<td><b>Resource Count</b></td>'+  
// '<td><b>Rate</b></td>'+ 
 '<td><b>Total Amount($)</b></td>'+ 
 
// '<td><b>Start Date</b></td>'+ 
// '<td><b>End Date</b></td>'+ 
// '<td><b>Is Planned?</b></td>'+ 

 '</tr></thead><tbody>';
 var comp="";
 var listItemEnumerator = collectionListItem.getEnumerator();
        
    while (listItemEnumerator.moveNext()) {
    	var oListItem = listItemEnumerator.get_current(); 
 tableContent += '<tr>';

 tableContent += '<td nowrap="true">'+'<a href="../SitePages/ViewRequest.aspx?RequestID='+oListItem.get_item('ID')+'" >'+oListItem.get_item('ID')+'</a></td>'; 
 tableContent += '<td nowrap="true">' + oListItem.get_item('Status') + '</td>';
 
 var reqStatus = oListItem.get_item('Status');
 var reviewerName = null;
 
 /*// Commented after 09/19 Demo..
 if(reqStatus == 'Pending Director Approval')
 { reviewerName = oListItem.get_item('CostCenterDirector').get_lookupValue();
 }
 else */
 
 if(reqStatus == 'Pending Financial Planner Approval')
 {
   reviewerName =  oListItem.get_item('CCFinancialPlanner').get_lookupValue();
 }
 else if(reqStatus == 'Pending Review Committee Approval')
 { reviewerName = oListItem.get_item('CostCenterVP').get_lookupValue();
 }
 else if(reqStatus == 'Approved')
 { reviewerName = "PSM Team";
 }
 else if(reqStatus == 'Open'||reqStatus == 'Returned'||reqStatus == 'Rejected'||reqStatus == 'Closed')
 { reviewerName = "N/A";
 }
 
 tableContent += '<td nowrap="true">' + reviewerName  + '</td>';
 tableContent += '<td nowrap="true">' + oListItem.get_item('Author').get_lookupValue() + '</td>';
 
 var  dateformat = 'MM/dd/yyyy';
 var RequestedDate = oListItem.get_item('Created') ? (new Date(oListItem.get_item('Created'))).format(dateformat ) != '01/01/1900' ? (new Date(oListItem.get_item('Created'))).format(dateformat) : '' : '';
 tableContent += '<td nowrap="true">' + RequestedDate + '</td>';

 tableContent += '<td nowrap="true">' + oListItem.get_item('Title') + '</td>';  
 tableContent += '<td nowrap="true">' + oListItem.get_item('GLName') + '</td>';
// tableContent += '<td nowrap="true">' + oListItem.get_item('Clarity_x0020_ProjectName') + '</td>';
 tableContent += '<td nowrap="true">' + oListItem.get_item('Clarity_x0020_ProjectID') + '</td>';

// tableContent += '<td nowrap="true">' + oListItem.get_item('Work_x0020_Type') + '</td>';   
// tableContent += '<td nowrap="true">' + oListItem.get_item('Vendor_x0020_Name') + '</td>';
// tableContent += '<td nowrap="true">' + oListItem.get_item('Head_x0020_Count') + '</td>'; 
// tableContent += '<td nowrap="true">' + oListItem.get_item('Rate') + '</td>';
 var Amount = oListItem.get_item('TotalAmount');

   if(Amount)
	//Amount = Amount.toFixed(0);
	Amount = Math.round(Amount);
   else Amount=0;
 
 Amount = (Amount+ "").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
   
 tableContent += '<td nowrap="true"> $' + Amount + '</td>';

 
 var startDate = oListItem.get_item('Start_x0020_Date') ? (new Date(oListItem.get_item('Start_x0020_Date'))).format(dateformat ) != '01/01/1900' ? (new Date(oListItem.get_item('Start_x0020_Date'))).format(dateformat) : '' : '';
 //tableContent += '<td nowrap="true">' + startDate + '</td>';
  
 var EndDate = oListItem.get_item('End_x0020_Date') ? (new Date(oListItem.get_item('End_x0020_Date'))).format(dateformat ) != '01/01/1900' ? (new Date(oListItem.get_item('End_x0020_Date'))).format(dateformat) : '' : '';
 //tableContent += '<td nowrap="true">' + EndDate + '</td>';

 var IsPlanned =  oListItem.get_item('IsPlanned');
 if(IsPlanned==true)
 { IsPlanned='Yes'; } 
 else  IsPlanned='No';
 //tableContent += '<td nowrap="true">' + IsPlanned + '</td>';
 tableContent += '</tr>';
 }
  return tableContent;
  
} 


// Function to append the list data to HTML grid.
function GenerateTableFromRest(Requests) {

 var tableContent = '<table id="RequestTable" style="width:100%"><thead><tr>' +
 '<td><b>Request Number</b></td>' + 
 '<td><b>Request Status</b></td>'+ 
 '<td><b>Approval Pending With</b></td>'+ 
 '<td><b>Requested By</b></td>'+ 
 '<td><b>Requested Date</b></td>'+ 
 '<td><b>Cost Center</b></td>'+ 
  '<td><b>GLName</b></td>'+ 
// '<td><b>Clarity Project Name</b></td>'+ 
 '<td><b>Clarity Project No</b></td>'+ 

// '<td><b>Work Type</b></td>'+ 
// '<td><b>Vendor Name</b></td>'+
// '<td><b>Resource Count</b></td>'+ 
// '<td><b>Rate</b></td>'+ 
 '<td><b>Total Amount($)</b></td>'+ 
  
 //'<td><b>Start Date</b></td>'+ 
 //'<td><b>End Date</b></td>'+ 
 //'<td><b>Is Planned?</b></td>'+ 

 '</tr></thead><tbody>';
 
 
 
for (var i = 0; i < Requests.length; i++) { 
 	//getUser(Requests[i].AuthorId).done(function(RequestorTitle){ 
 	tableContent += '<tr>';

 	tableContent += '<td nowrap="true">'+'<a href="../SitePages/ViewRequest.aspx?RequestID='+Requests[i].ID+'" >'+Requests[i].ID+'</a></td>'; 
 	tableContent += '<td nowrap="true">' + Requests[i].Status + '</td>';
 
 	var reqStatus = Requests[i].Status;
 	var reviewerName = null;
 
 	if(reqStatus == 'Pending Financial Planner Approval')
 		{
 		  reviewerName =  Requests[i].CCFinancialPlanner.Title;//.get_lookupValue();
 		}
 	else if(reqStatus == 'Pending Review Committee Approval')
 		{ reviewerName = Requests[i].CostCenterVP.Title;//.get_lookupValue();
 		
 		}
 	else if(reqStatus == 'Approved')
 		{ reviewerName = "PSM Team";
 		}
 	else if(reqStatus == 'Open'||reqStatus == 'Returned'||reqStatus == 'Rejected'||reqStatus == 'Closed')
 		{ reviewerName = "N/A";
 		}
 

 	tableContent += '<td nowrap="true">' + reviewerName  + '</td>';
 	
 		tableContent += '<td nowrap="true">' + Requests[i].Author.Title + '</td>';
 	
 	 var  dateformat = 'MM/dd/yyyy';
 	var RequestedDate = Requests[i].Created ? (new Date(Requests[i].Created)).format(dateformat ) != '01/01/1900' ? (new Date(Requests[i].Created)).format(dateformat) : '' : '';
 	tableContent += '<td nowrap="true">' + RequestedDate + '</td>';
	tableContent += '<td nowrap="true">' + Requests[i].Title + '</td>';  
    tableContent += '<td nowrap="true">' + Requests[i].GLName + '</td>';
	// tableContent += '<td nowrap="true">' + oListItem.get_item('Clarity_x0020_ProjectName') + '</td>';
    tableContent += '<td nowrap="true">' + Requests[i].Clarity_x0020_ProjectID + '</td>';
	//tableContent += '<td nowrap="true">' + Requests[i].Work_x0020_Type + '</td>';   
	//tableContent += '<td nowrap="true">' + Requests[i].Vendor_x0020_Name + '</td>';
	//tableContent += '<td nowrap="true">' + Requests[i].Head_x0020_Count + '</td>'; 
	//tableContent += '<td nowrap="true">' + Requests[i].Rate + '</td>';
	var Amount = Requests[i].TotalAmount;
    if(Amount)
	//Amount = Amount.toFixed(0);
	Amount = Math.round(Amount);
    else Amount=0;
 	 Amount = (Amount+ "").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
   
	tableContent += '<td nowrap="true"> $' + Amount + '</td>';
	
   // var startDate = Requests[i].Start_x0020_Date ? (new Date(Requests[i].Start_x0020_Date)).format(dateformat ) != '01/01/1900' ? (new Date(Requests[i].Start_x0020_Date)).format(dateformat) : '' : '';
	//tableContent += '<td nowrap="true">' + startDate + '</td>';
   // var EndDate = Requests[i].End_x0020_Date ? (new Date(Requests[i].End_x0020_Date)).format(dateformat ) != '01/01/1900' ? (new Date(Requests[i].End_x0020_Date)).format(dateformat) : '' : '';
	//tableContent += '<td nowrap="true">' + EndDate + '</td>';
	//var IsPlanned =  Requests[i].IsPlanned;
	//if(IsPlanned==true)
	//{ IsPlanned='Yes'; } 
	//else  IsPlanned='No';
	//tableContent += '<td nowrap="true">' + IsPlanned + '</td>'; 
	tableContent += '</tr>';
	// });
  } // end of for loop

  return tableContent;
   
 
} 



// Loading requests on page load
PopulateRequest = function (currentUser) {
	var dfd = $.Deferred();
 	var filterStatus =   $('#div-RequestStatus option:selected').text();
	siteUrl = _spPageContextInfo.siteAbsoluteUrl;
	var RestUrl = siteUrl +"/_vti_bin/listdata.svc/ADCApprovalRequests";
	var clientContext = SP.ClientContext.get_current()
	var oList = clientContext.get_web().get_lists().getByTitle('ADC Approval Requests');
    var camlQuery = new SP.CamlQuery();
    
		 if(!(filterStatus=='Select'))
    	{  
    	$('#FilterGrid').empty();
     	$('#FilterGrid').css("display", "block");
        $('#RequestGrid').css("display", "none");
     	camlQuery.set_viewXml('<View><Query><Where>'
     							 +'<And>'
     							 +'<Eq><FieldRef Name="Status"/><Value Type="Choice">'+ filterStatus +'</Value></Eq>'
     							 +'<Or>'
    							 +'<In>'
    							  +'<FieldRef Name="Status"/>'
      								+'<Values>'
							          +'<Value Type="Choice">Pending Financial Planner Approval</Value>'
        							  +'<Value Type="Choice">Pending Review Committee Approval</Value>'
        							  +'<Value Type="Choice">Approved</Value>'
        							  +'<Value Type="Choice">Rejected</Value>'
        							  +'<Value Type="Choice">Closed</Value>'
       								+'</Values>'
  								  +'</In>'   							
    							+'<And>'
    							+'<Eq><FieldRef Name="Author" LookupId="TRUE" /><Value Type="Lookup">'+currentUser.get_id()+'</Value></Eq>'
								//+'<Eq><FieldRef Name="Status"/><Value Type="Choice">Open</Value></Eq>'
								+'<In>'
    							  +'<FieldRef Name="Status"/>'
      								+'<Values>'
      								+'<Value Type="Choice">Open</Value>'
        							  +'<Value Type="Choice">Returned</Value>'
       								+'</Values>'
								+'</In>' 
								+'</And>'
    							+'</Or>' 
     							+'</And>'
     							+'</Where><OrderBy><FieldRef Name = "ID" Ascending = "FALSE"/></OrderBy></Query><RowLimit Paged="FALSE">500</RowLimit></View>');	 
    	}
    	else
    	{
    	camlQuery.set_viewXml('<View><Query><Where>'
    							+'<Or>'
    							 +'<In>'
    							  +'<FieldRef Name="Status"/>'
      								+'<Values>'
							        // +'<Value Type="Choice">Returned</Value>'
        							  +'<Value Type="Choice">Pending Financial Planner Approval</Value>'
        							  +'<Value Type="Choice">Pending Review Committee Approval</Value>'
        							  +'<Value Type="Choice">Approved</Value>'
        							  +'<Value Type="Choice">Rejected</Value>'
        							  +'<Value Type="Choice">Closed</Value>'
       								+'</Values>'
  								  +'</In>'   							
    							+'<And>'
    							+'<Eq><FieldRef Name="Author" LookupId="TRUE" /><Value Type="Lookup">'+currentUser.get_id()+'</Value></Eq>'
    							+'<In>'
    							  +'<FieldRef Name="Status"/>'
      								+'<Values>'
      								+'<Value Type="Choice">Open</Value>'
        							  +'<Value Type="Choice">Returned</Value>'
       								+'</Values>'
								+'</In>' 
								+'</And>'
    							+'</Or>' 
    							+'</Where><OrderBy><FieldRef Name = "ID" Ascending = "FALSE"/></OrderBy><Where></Where></Query><RowLimit Paged="FALSE">500</RowLimit></View>');	
   		 } 
	      
    collectionListItem= oList.getItems(camlQuery);        
    clientContext.load(collectionListItem);  
             
    clientContext.executeQueryAsync(onFetchQuerySucceeded, onFetchQueryFailed);
    
   function onFetchQuerySucceeded() {
	    if(collectionListItem.get_count() > 0)
	    {	    	
	     //construct HTML Table from the JSON Data
		  $('#RequestGrid').append(GenerateTableFromJson(collectionListItem));
  		  if(!(filterStatus=='Select'))
    		{  $('#FilterGrid').append(GenerateTableFromJson(collectionListItem));
   			}
   		  dfd.resolve();
	     }
	 	 else {  $('#FilterGrid').append('<Center><b>No records available</b></Center>'); }	 	
     }
   function onFetchQueryFailed() {  }
   removeOverlay();
};

// Loading user specific requests on page load
PopulateUserSpecificRequest = function (currentUser) {
	var dfd = $.Deferred();
	var clientContext = SP.ClientContext.get_current();
 	var filterStatus =   $('#div-RequestStatus option:selected').text();
 	 /* if(!(filterStatus=='Select'))
    	{  
    	
    	//var oList = clientContext.get_web().get_lists().getByTitle('ADC Approval Requests')+"'/Items?$filter=Status eq '"+filterStatus +"'";
    	
    	var oListF = "https://discoverfinancial.sharepoint.com/sites/ADCApprovalMgmtDev/_api/web/lists/getbytitle('ADC Approval Requests')/items?$filter=Status eq '"+filterStatus +"'";
    	
    	 $('#RequestGrid').empty();
     	 $('#FilterGrid').css("display", "block");
         $('#RequestGrid').css("display", "none");
         }
         
         else
         {  */
           //siteUrl = _spPageContextInfo.siteAbsoluteUrl; 
          var oList = clientContext.get_web().get_lists().getByTitle('ADC Approval Requests');
        // }
	 
     	var camlQuery = new SP.CamlQuery();
		camlQuery.set_viewXml('<View><Query><Where>'
					    		+'<Or>'
					    		+'<Or>'
					    		+'<Or>'
    							+'<Eq><FieldRef Name="Author" LookupId="TRUE" /><Value Type="Lookup">'+currentUser.get_id()+'</Value></Eq>'
    							+'<Eq><FieldRef Name="CostCenterDirector" LookupId="TRUE" /><Value Type="Lookup">'+currentUser.get_id()+'</Value></Eq>'
    							+'</Or>' 
    							+'<Eq><FieldRef Name="CCFinancialPlanner" LookupId="TRUE" /><Value Type="Lookup">'+currentUser.get_id()+'</Value></Eq>'
    							+'</Or>'
    							+'<Eq><FieldRef Name="CostCenterVP" LookupId="TRUE" /><Value Type="Lookup">'+currentUser.get_id()+'</Value></Eq>'
    							+'</Or>' 
    						 	+'</Where><OrderBy><FieldRef Name = "ID" Ascending = "FALSE"/></OrderBy><Where></Where></Query><RowLimit Paged="FALSE">500</RowLimit></View>');	
    
    collectionListItem= oList.getItems(camlQuery);   
    clientContext.load(collectionListItem);  
    clientContext.executeQueryAsync(onFetchQuerySucceeded, onFetchQueryFailed);
   function onFetchQuerySucceeded() {
	    if(collectionListItem.get_count() > 0)
	    {	    	
	     //construct HTML Table from the JSON Data
		  $('#RequestGrid').append(GenerateTableFromJson(collectionListItem));
  		  if(!(filterStatus=='Select'))
    		{  $('#FilterGrid').append(GenerateTableFromJson(collectionListItem));
   			}
   		  dfd.resolve();
	     }
	 	 else {  $('#FilterGrid').append('<Center><b>No records available</b></Center>'); }	 	
     }
   function onFetchQueryFailed() { //alert('filed'); 
    }
   removeOverlay();
};


PopulateUserSpecificRequestFilter = function (currentUser) {
    var dfd = $.Deferred();
    $('#RequestGrid').empty();
     	 $('#FilterGrid').css("display", "block");
         $('#RequestGrid').css("display", "none");

   	var filterStatus =   $('#div-RequestStatus option:selected').text();
    var call = jQuery.ajax({
       url: url = _spPageContextInfo.webAbsoluteUrl+"/_api/web/lists/getbytitle('"+ADCApprovalList+"')/items?$select=*,Author/Title,CCFinancialPlanner/Title,CostCenterVP/Title&$expand=Author/Id,CCFinancialPlanner/Id,CostCenterVP/Id&$filter=((Status eq '"+filterStatus +"') and ((AuthorId eq '"+currentUser.get_id()+"') or (CostCenterDirectorId eq '"+currentUser.get_id()+"') or (CCFinancialPlanner eq '"+currentUser.get_id()+"')   or (CostCenterVPId eq '"+currentUser.get_id()+"')))&$orderby= ID desc",
        type: "GET",
        datatype: "json",
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var Requests= data.d.results;
               
        if(Requests.length > 0) {
             $('#FilterGrid').append(GenerateTableFromRest(Requests));
       }
        else {  $('#FilterGrid').append('<Center><b>No records available</b></Center>'); }	  

        dfd.resolve(data);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of PopulateUserSpecificRequestFilter
 

// common function Check current user details in mentioned Group 
function IsCurrentUserMemberOfGroup(groupName, OnComplete) {

        var currentContext = new SP.ClientContext.get_current();
        var currentWeb = currentContext.get_web();

        var currentUser = currentContext.get_web().get_currentUser();
        currentContext.load(currentUser);

        var allGroups = currentWeb.get_siteGroups();
        currentContext.load(allGroups);

        var group = allGroups.getByName(groupName);
        currentContext.load(group);

        var groupUsers = group.get_users();
        currentContext.load(groupUsers);

        currentContext.executeQueryAsync(OnSuccess,OnFailure);

        function OnSuccess(sender, args) {
            var userInGroup = false;
            var groupUserEnumerator = groupUsers.getEnumerator();
            while (groupUserEnumerator.moveNext()) {
                var groupUser = groupUserEnumerator.get_current();
                if (groupUser.get_id() == currentUser.get_id()) {
                    userInGroup = true;
                    break;
                }
            }  
            OnComplete(userInGroup);
        }

        function OnFailure(sender, args) {
            OnComplete(false);
        }    
}//End

// Get dispay name
/*function getUser(userid){
  var returnValue;
  jQuery.ajax({
   url: _spPageContextInfo.webAbsoluteUrl + "/_api/web/GetUserById(" + userid+ ")",
   type: "GET",
   headers: { "Accept": "application/json;odata=verbose" },
   success: function(data) {
           var dataResults = data.d;
      //get login name  
      var loginName  = dataResults.LoginName.split('|')[1];
      alert("Name"+loginName);
      //get display name
      alert("title"+dataResults.Title);
      return dataResults.Title;
   }
   
 });
}*/

getUser = function (userid) {
    var dfd = $.Deferred();
    var call = jQuery.ajax({
       url: _spPageContextInfo.webAbsoluteUrl + "/_api/web/GetUserById(" + userid+ ")",

        type: "GET",
        datatype: "json",
        async: false,
        headers:
            {
                Accept: "application/json;odata=verbose"
            }
    });

    call.done(function (data) {
        var UserDetails= data.d;
        //alert("details"+UserDetails);
        var UserTitle = UserDetails.Title;
        alert("title"+UserTitle);
        
       //})

        dfd.resolve(UserTitle);

    }).fail(function (data) {
        dfd.reject();
    });

    return dfd.promise();
};// End of GetProjectName


DefaultLoad = function () {
var dfdCurrentloggedInUser = SPUser.getCurrent();
    dfdCurrentloggedInUser.done(function (currentUser) {
    // addOverlay("Loading Data..Please Wait..");	
    var filterStatus =   $('#div-RequestStatus option:selected').text();
    IsCurrentUserMemberOfGroup("ADC Approval Management - Owners", function (isCurrentUserInGroup) {
	if(isCurrentUserInGroup)
    {
		PopulateRequest(currentUser);

	} 
	else
		{
		 IsCurrentUserMemberOfGroup("ADC-Provisioner-PSM", function (isCurrentUserInGroup) {
		  if(isCurrentUserInGroup)
    	   {
     		PopulateRequest(currentUser);

	 	   } 
	 	  else {
	 	 	   IsCurrentUserMemberOfGroup("ADC-ReviewCommitte-VPs", function (isCurrentUserInGroup) {
			   if(isCurrentUserInGroup)
   				 {
     				PopulateRequest(currentUser);

				 } 
				else
				 {
				  IsCurrentUserMemberOfGroup("ADC-FinancialPlanners", function (isCurrentUserInGroup) {
  		           if(isCurrentUserInGroup)
    				{ 
	 				PopulateRequest(currentUser);

					} 
				   else
				     {	
				      if(!(filterStatus=='Select'))
    					{ 	PopulateUserSpecificRequestFilter(currentUser); }
    				  else
    				    {   PopulateUserSpecificRequest(currentUser); }
				     }    
	 			  }); // end of ADC-FinancialPlanners
		 		  } // end of else 
			}); //end of ADC-ReviewCommitte-VPs
	 	   
	 	    } //end of else
	 	 }); // end of ADC-Provisioner-PS
	   
     } // end of main else 
   }); // end of ADC Approval Management - Development Owners

 }); //end of login user
 
 
};
$(document).ready(function() {
   
	DefaultLoad(); 	
 });

