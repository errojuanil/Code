﻿/**
 * @Author: ANIL KUMAR YERROJU
 * @Created on: 07/19/2017
 * @Last Modified: 12/20/2017
 * @Modified Reason: DEC-2017 Enhancements/Changes.
 *					 Additional changes like "Replacing Duration fields with Start date and End date for both Vendors".
 *					 Modified Currency format for all Curency fileds.
 *					 Modified "GL Name" list to pull only requestor data. 
 * @Application: ADC Approval Management Automation.
 * @Page Name: NEW REQUEST PAGE.
 * @summary: This page used to submit new request.
 *		     
 **/


var lstRequest={};

var CRUDobj = DDOCS.ListItemManager();

lstRequest.prjListName = "Projects";
lstRequest.ideaListName = "Ideas";
lstRequest.vendorsListName = "Vendors";
lstRequest.gLListName = "GL List";
lstRequest.costCenterListName = "BT Cost Center Hierarchy";
lstRequest.sowStatus = "SOW Status";
lstRequest.workType = "Work Type";
lstRequest.BTFinaceURL = "https://discoverfinancial.sharepoint.com/sites/BT2016BudPlan";
lstRequest.SdlcURL = "https://discoverfinancial.sharepoint.com/sites/BTPrjArtfcts";
lstRequest.IsAdditionalVendorEanbled = 'NO';
lstRequest.IdeaCheckBoxEnabled = 'NO';
lstRequest.costCenterDirectorEmail=null;
lstRequest.ccFinancialPlannerEmail=null;
lstRequest.costCenterVPEmail=null;




lstRequest.init=function(){
	
	lstRequest.populateSelectCAMLLookup('#div-clarityProjectName select', lstRequest.prjListName, 'Name');
	lstRequest.populateSelectCAMLLookup('#div-vendorName select', lstRequest.vendorsListName, 'Title');
	lstRequest.populateSelectCAMLLookup('#div-vendorName2 select', lstRequest.vendorsListName, 'Title');
	lstRequest.populateSelectCAMLLookup('#div-glName select', lstRequest.gLListName , 'Title');
	lstRequest.populateSelectCAMLLookup('#div-costCenter select', lstRequest.costCenterListName, 'Title');
	//lstRequest.populateSelectCAMLLookup('#div-sowStatus select', lstRequest.sowStatus, 'Title');
	lstRequest.populateSelectCAMLLookup('#div-workType select', lstRequest.workType, 'Title');
	
	 $('#chkIdea').change(function() {
        	if ($(this).is(':checked')) { //For Idea
        		lstRequest.IdeaCheckBoxEnabled = 'YES';
        	    $('#div-clarityProjectID .label2').text('');
      	  	    $('#div-clarityProjectName input').last().val('');
      	  	          	  	
      	  	   lstRequest.populateSelectCAMLLookup('#div-clarityProjectName select', lstRequest.ideaListName, 'Name');
			   }
       	    if (!$(this).is(':checked')) { // For Project
       	    lstRequest.IdeaCheckBoxEnabled = 'NO';
       	    	$('#div-clarityProjectID .label2').text('');
				 $('#div-clarityProjectName input').last().val('');
				lstRequest.populateSelectCAMLLookup('#div-clarityProjectName select', lstRequest.prjListName, 'Name');

       	     }
		 });
	
	$('#div-amount').hide();
	$('#div-amount2').hide();
	$('#div-toNumber').hide();
	$('#additionalVendorPanel1').hide();
	$('#additionalVendorPanel2').hide();
    $('#btnAdditionalVendorDisable').hide();
    

	
	
		$('#div-costCenter').focusout(function () {
		  	$('#div-costCenterName .label2').text('');
		 	$('#div-costCenterDirector .label2').text('');
		  	$('#div-costCenterFinancialPlanner .label2').text('');
  	      	$('#div-costCenterVP .label2').text('');
          	lstRequest.populateSelectCAMLCostCenter('div-costCenterName label2', lstRequest.costCenterListName, 'Title');
       }); 
    

	    $('#div-vendorName').focusout(function () {
	       lstRequest.populateSelectCAML('div-rate input', lstRequest.vendorsListName, 'Title');
	       
	       
           }); 
           
        $('#div-vendorName2').focusout(function () {
	       lstRequest.populateSelectCAML('div-rate2 input', lstRequest.vendorsListName, 'Title');
	       
           }); 

		
         

      $('#div-clarityProjectName').focusout(function () {
        
         
         if(lstRequest.IdeaCheckBoxEnabled =='YES')          
         {  lstRequest.populateSelectCAML('div-clarityProjectID label2', lstRequest.ideaListName, 'Title');}
         if(lstRequest.IdeaCheckBoxEnabled == 'NO')
         { lstRequest.populateSelectCAML('div-clarityProjectID label2', lstRequest.prjListName, 'Title');}
         
         
         }); 
    
    
    $("#div-headCount").keypress(function( event ){
 	    var key = event.which;
	    if( ! ( key >= 48 && key <= 57 ) )
        event.preventDefault(); 				});
   
   $("#div-headCount2").keypress(function( event ){
 	    var key = event.which;
	    if( ! ( key >= 48 && key <= 57 ) )
        event.preventDefault(); 				});

	
    $("#div-rate").keypress(function( event ){
   		 var key = event.which;
	    if( ! ( key >= 48 && key <= 57 ) )
        event.preventDefault();			});
    
     $("#div-rate2").keypress(function( event ){
   		 var key = event.which;
	    if( ! ( key >= 48 && key <= 57 ) )
        event.preventDefault();			});

	
	$("#div-amount").keypress(function( event ){
    	var key = event.which;
    	if( ! ( key >= 48 && key <= 57 ) )
        event.preventDefault();  	});
    
    $("#div-amount2").keypress(function( event ){
    	var key = event.which;
    	if( ! ( key >= 48 && key <= 57 ) )
        event.preventDefault();  	});
        
      $("#div-durationVendor1").keypress(function( event ){
    	var key = event.which;
    	if( ! ( key >= 48 && key <= 57 ) )
    	if ((key  != 46 || $(this).val().indexOf('.') != -1) && (key  < 48 || key  > 57))
        event.preventDefault();  	});
        
        
      $("#div-durationVendor2").keypress(function( event ){
    	var key = event.which;
    	if ((key  != 46 || $(this).val().indexOf('.') != -1) && (key  < 48 || key  > 57))
        event.preventDefault();  	});




	
	$('#clrBtn').on('click',function(){
	
	ClearFields();
	
	
	});	
};


lstRequest.getFieldQuery = function (queryJson, index) {
    var query = '<' + queryJson[index].comparer + '>';
    if (queryJson[index].isLookup)
        query += '<FieldRef Name="' + queryJson[index].name + '" LookupId="TRUE"/>';
    else
        query += '<FieldRef Name="' + queryJson[index].name + '"/>';
    query += '<Value Type="' + queryJson[index].type + '">' + queryJson[index].value + '</Value>' +
			'</' + queryJson[index].comparer + '>';

    return query;
};


lstRequest.populateSelectCAML = function (element, listName, fieldName) {
    var docFieldName = lstRequest.getFieldName(element)
    
    
    if(listName == lstRequest.prjListName||listName == lstRequest.ideaListName)
    {
    
    var sValue = jQuery("#div-clarityProjectName option:selected").val();
		

    var ctx = new SP.ClientContext(lstRequest.SdlcURL);
    }
    else if(listName == lstRequest.vendorsListName)
    { 
        if(element=="div-rate input"){ var sValue = jQuery("#div-vendorName option:selected").val(); }
        if(element=="div-rate2 input"){ var sValue = jQuery("#div-vendorName2 option:selected").val(); }
        
         var ctx = SP.ClientContext.get_current();
    }
    var list = ctx.get_web().get_lists().getByTitle(listName);
    var camlQuery = new SP.CamlQuery();
    
   // alert(sValue);
     if (sValue != '')
     {
     

           camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="ID"/><Value Type="Counter">' + sValue + '</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
 	 
      }
     
     
	
    var lstItems = list.getItems(camlQuery);
    ctx.load(lstItems);
    ctx.executeQueryAsync(
	function (sender, args) {
	    var selectHtml = "";
		
   
	     var ItemEnum = lstItems.getEnumerator();

	    while (ItemEnum.moveNext()) {
	        if(listName ==lstRequest.prjListName||listName == lstRequest.ideaListName)
    		{
    		
    		 var itemTitle = ItemEnum.get_current().get_item('Title');
    		 $('#div-clarityProjectID .label2').text(itemTitle);
    		}
    		
    		if(listName == lstRequest.vendorsListName)
    		{

    		  var itemVendor = ItemEnum.get_current().get_item('Title');
    		  var itemRate = ItemEnum.get_current().get_item('Rate');

    		 if(itemVendor.startsWith('Managed'))
    		  {  
    		   	if(element=="div-rate input") { $('#div-rate').hide(); $('#div-amount').show();}
    		   	if(element=="div-rate2 input") { $('#div-rate2').hide(); $('#div-amount2').show();}
  		  	
    		  }
    		  else 
    		   { 
    		    if(element=="div-rate input") { $('#div-rate').show(); $('#txtRate').val(itemRate); $('#div-amount').hide(); }
     		    if(element=="div-rate2 input") { $('#div-rate2').show(); $('#txtRate2').val(itemRate); $('#div-amount2').hide(); }

    		    } 
			 }
	      }
	},
	function (sender, args) {
	    console.log("Page:'Request.aspx' Method:'lstRequest.populateSelectCAML.' Error:" + args.get_message());

	});

};

// For loading drop downs.
lstRequest.populateSelectCAMLLookup = function (element, listName, fieldName) {
    var docFieldName = lstRequest.getFieldName(element)

    var sValue = lstRequest.getFieldValue(docFieldName);

    if (listName == lstRequest.prjListName||listName == lstRequest.ideaListName)
    {


    var ctx = new SP.ClientContext(lstRequest.SdlcURL);
    }
    else if(listName == lstRequest.costCenterListName)
    {

    var ctx = new SP.ClientContext(lstRequest.BTFinaceURL);

    }
    else
    {
		var ctx = SP.ClientContext.get_current();
    }
    var list = ctx.get_web().get_lists().getByTitle(listName);

    var camlQuery = new SP.CamlQuery();
    
    
						    
    
    if(listName == lstRequest.prjListName&&sValue != '')
	 camlQuery.set_viewXml('<View><Query><Where>'
	 						+'<And>'
	 						  +'<Eq><FieldRef Name="ID"/><Value Type="Counter">' + sValue + '</Value></Eq>'
	 						   +'<Neq><FieldRef Name="CloseCancel"/><Value Type="Choice">Cancel</Value></Neq></And>'
	 						    +'</Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');

      

   else if(listName == lstRequest.ideaListName&&sValue != '')
	 camlQuery.set_viewXml('<View><Query><Where>'
	 						+'<And>'
	 						  +'<Eq><FieldRef Name="ID"/><Value Type="Counter">' + sValue + '</Value></Eq>'
	 						   +'<Neq><FieldRef Name="Status"/><Value Type="Text">Converted</Value></Neq></And>'
	 						    +'</Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');

        
    
    else if(listName == lstRequest.costCenterListName)
	 camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="Active_x003f_"/><Value Type="Text">Yes</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');

	else if(listName == lstRequest.costCenterListName&&sValue != '')
	 camlQuery.set_viewXml('<View><Query><Where><And><Eq><FieldRef Name="ID"/><Value Type="Counter">' + sValue + '</Value></Eq><Eq><FieldRef Name="Active_x003f_"/><Value Type="Text">Yes</Value></Eq></And></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
	 

	else if (sValue != '')
        camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="ID"/><Value Type="Counter">' + sValue + '</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
    else
        camlQuery.set_viewXml('<View><Query><Where></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');

    var lstItems = list.getItems(camlQuery);
    ctx.load(lstItems);
    ctx.executeQueryAsync(
	function (sender, args) {
	    var selectHtml = "";
	    var distinctItems = [];
	    var ItemEnum = lstItems.getEnumerator();
	    while (ItemEnum.moveNext()) {
	      
	        var itemValue = ItemEnum.get_current().get_item('ID');
	        var itemTitle = ItemEnum.get_current().get_item(fieldName);
			 
	        var $dupItems = $.grep(distinctItems, function (element, index) {
	            return element.value == itemValue;
	        });
	     if (!$dupItems.length)
	        	            distinctItems.push({ 'value': itemValue, 'title': itemTitle });

	    }
	    for (var i = 0; i < distinctItems.length; i++) {
	    	        selectHtml += '<option value="' + distinctItems[i].value + '">' + distinctItems[i].title + '</option>';
	    }
	    $(element).append(selectHtml);
	    $(element).attr('data', '{"listName":"' + listName + '","fieldName":"' + fieldName + '","valueFieldName":"ID"}');
 	    $(element).val(sValue);
	    $(element).combobox(); 
	},
	function (sender, args) {
	    console.log("Page:'Request.aspx' Method:'lstRequest.populateSelectInitiator.' Error:" + args.get_message());

	});
};



/// Populating cost center related fields fields
lstRequest.populateSelectCAMLCostCenter = function (element, listName, fieldName) {
    var docFieldName = lstRequest.getFieldName(element)
    
    if(listName == lstRequest.costCenterListName)
    {
    
    var sValue = jQuery("#div-costCenter option:selected").text();

    var sUrl = "https://discoverfinancial.sharepoint.com/sites/BT2016BudPlan";
    var ctx = new SP.ClientContext(sUrl);
    }
   
    var list = ctx.get_web().get_lists().getByTitle(listName);
    var camlQuery = new SP.CamlQuery();
     
 	  camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="' + fieldName + '"/><Value Type="Text">' + sValue + '</Value></Eq></Where></Query><RowLimit Paged="FALSE">50</RowLimit></View>');
     	
    var lstItems = list.getItems(camlQuery);
    ctx.load(lstItems);
    ctx.executeQueryAsync(
	function (sender, args) {
	    var selectHtml = "";
		var ItemEnum = lstItems.getEnumerator();

	    while (ItemEnum.moveNext()) {
	         var costCenterName = ItemEnum.get_current().get_item('Cost_x0020_Center_x0020_Desc');
	         var costCenterDirector = ItemEnum.get_current().get_item('Dir_x0020_Name0').get_lookupValue();
	         lstRequest.costCenterDirectorEmail = ItemEnum.get_current().get_item('Dir_x0020_Name0').get_email();
	         
	         var ccFinancialPlanner = ItemEnum.get_current().get_item('Planner').get_lookupValue();
	         lstRequest.ccFinancialPlannerEmail = ItemEnum.get_current().get_item('Planner').get_email();

     	     var costCenterVP = ItemEnum.get_current().get_item('VP_x0020_Name0').get_lookupValue();
     	     lstRequest.costCenterVPEmail = ItemEnum.get_current().get_item('VP_x0020_Name0').get_email();

	         if(costCenterName)
    		 $('#div-costCenterName .label2').text(costCenterName);
    		 if(costCenterDirector)
    		 $('#div-costCenterDirector .label2').text(costCenterDirector);
    		 if(ccFinancialPlanner){
    		 $('#div-CCFinancialPlanner .label1').text(ccFinancialPlanner);
    		 $('#div-costCenterFinancialPlanner .label2').text(ccFinancialPlanner); }
    		 if(costCenterVP)
    		 $('#div-costCenterVP .label2').text(costCenterVP);
    		 }
    		 
    		 


	},
	function (sender, args) {
	    console.log("Page:'Request.aspx' Method:'lstRequest.populateSelectCAML.' Error:" + args.get_message());

	});

};



lstRequest.getFieldName=function(element){
	var fieldName='';

	switch(element)
	{
		case '#div-clarityProjectID select': fieldName='Title';
				break;
    	case '#div-clarityProjectName select': fieldName='Name';
				break;


		case '#div-vendorName select': fieldName='Title';
				break;
		
		default:break;
	}
	return fieldName;
};

lstRequest.getFieldValue = function (fieldName) {
    var fieldValue = '';
    if (sessionStorage.searchQuery && sessionStorage.searchQuery != '') {
    	var paramJson =JSON.parse(sessionStorage.searchQueryJson);
    	var fieldJson= $.grep(paramJson,function(element){
			return element.name==fieldName;
		});
		if(fieldJson.length)
    		fieldValue=fieldJson[0].value;
    }
    return fieldValue;
	
};

lstRequest.getQuery=function(queryJson,index,isPrjNumQuery)
{	
	var queryString='';
	var operator='And';
	if(index<queryJson.length)
	{
		switch(index)
		{
			case queryJson.length-1: 
					queryString+=lstRequest.getFieldQuery(queryJson,0);
					break;
			case queryJson.length-2:
					if(!(isPrjNumQuery))
					{
						operator='Or';
						queryString+='<'+operator+'>'+
								'<And>'+
									lstRequest.getFieldQuery(queryJson,queryJson.length-1)+
									'<IsNull>'+
										'<FieldRef Name="'+queryJson[queryJson.length-2].name+'"/>'+
									'</IsNull>'+
								'</And>' +
                                lstRequest.getFieldQuery(queryJson, queryJson.length - 2) +
							'</'+operator+'>';
					}
					else
						operator='And';
						queryString+='<'+operator+'>'+
								lstRequest.getFieldQuery(queryJson,queryJson.length-2)+
								lstRequest.getFieldQuery(queryJson,queryJson.length-1)+
							'</'+operator+'>';
					break;
			default:queryString+='<'+operator+'>'+
									lstRequest.getQuery(queryJson,index+1,isPrjNumQuery)+
									lstRequest.getFieldQuery(queryJson,index)+
								'</'+operator+'>';
					break;
	
		}
	}
	
	return queryString; 
};

lstRequest.EnableAdditionalVendor= function (RequestType) {
 
   if (RequestType == "Enable")
    { 
     lstRequest.IsAdditionalVendorEanbled='YES';
     $('#btnAdditionalVendorDisable').show();
     $('#additionalVendorPanel1').show();
	 $('#additionalVendorPanel2').show();
	 $('#btnAdditionalVendor').hide();	    }
	    
   else if (RequestType == "Disable")
	    {
	     lstRequest.IsAdditionalVendorEanbled='NO';
	    $('#btnAdditionalVendor').show();
	    $('#additionalVendorPanel1').hide();
	    $('#additionalVendorPanel2').hide();
	    $('#btnAdditionalVendorDisable').hide();
   
	   }
	  
};//End of lstRequest.EnableAdditionalVendor


lstRequest.SubmitRequest = function (RequestType) {
    if ((RequestType == "Save")||(RequestType == "Submit"))
    { 
    //
        lstRequest.InsertRequestDetails(RequestType);
    }
    else if (RequestType == "Back")
    {
  
       window.location.href = 'Home.aspx';
    }
	/*else 
    {
    
        lstRequest.InsertRequestDetails(RequestType);
     
    }  */  

};//End of lstRequest.SubmitRequest

lstRequest.InsertRequestDetails = function (RequestType){
    //addOverlay('Loading Data..');
    
	var MgrInfo = [];
	var DirInfo = [];
	var VPInfo = [];
	var peoplepickerManagerInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-manager .sp-peoplepicker-topLevel').attr('id')];
    var peoplepickerDirectorInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-director .sp-peoplepicker-topLevel').attr('id')];
    var peoplepickerVPInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-vp .sp-peoplepicker-topLevel').attr('id')];
   //var peoplepickerCostCenterDirectorInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-costCenterDirector .sp-peoplepicker-topLevel').attr('id')];
   //var peoplepickerCCFinancialPlannerInfo = SPClientPeoplePicker.SPClientPeoplePickerDict[$('#div-CCFinancialPlanner .sp-peoplepicker-topLevel').attr('id')];
    
    var FromDate, ToDate, Status, ProjectID, ProjectName, CostCenter, CostCenterName, CostCenterDirector, CCFinancialPlanner, WorkType, GLName, PlanID, HeadCount, VendorName,
        DurationVendor1, Rate, EstMonthlySpend, Amount, TONumber, HeadCountPlan, ClarityUpdated, IsPlanned, SowStatus, SowNumber, RequestorComments;
       
    	
        
	ProjectID= $('#div-clarityProjectID .label2').text();
	ProjectName = $('#div-clarityProjectName input').last().val();
	CostCenter= $('#div-costCenter input').last().val();
	CostCenterName = $('#div-costCenterName .label2').text();
	CostCenterDirector = $('#div-costCenterDirector .label2').text();
	CCFinancialPlanner = $('#div-CCFinancialPlanner .label1').text();
	CostCenterVP = $('#div-costCenterVP .label2').text();
	WorkType = $('#div-workType input').last().val();
	GLName= $('#div-glName input').last().val();

	//Vendor
	VendorName= $('#div-vendorName input').last().val();
	HeadCount= $('#div-headCount input').last().val();
	Rate= $('#div-rate input').last().val();
	Amount= $('#div-amount input').last().val();
	DurationVendor1= $('#div-durationVendor1 input').last().val();
	
	
	//Commented PSM fields
	PlanID= $('#div-planID input').last().val();
	//TONumber= $('#div-toNumber input').last().val();
	//HeadCountPlan= $('#div-headCountPlan input').last().val();
	//ClarityUpdated= $('#div-clarityUpdated input').last().val();
	//IsPlanned= $('#div-isPlanned select').last().val();
	//SowStatus= $('#div-sowStatus input').last().val();
	//SowNumber= $('#div-sowNumber input').last().val();
	RequestorComments = $('#div-requestorComments input').last().val();
	if(RequestType== 'Save') Status = 'Open'; else Status= 'Pending Financial Planner Approval';
	
	
	
	
	/* //Commented PSM fields
	if(IsPlanned == "" ||!IsPlanned)
   		{  alert("Enter all required fields marked with *.");
                    return;	
        }
     else  if(IsPlanned == 'Yes') IsPlanned = 'true'; else IsPlanned = 'false'; */
     
     /* // Commented Date field as per Dec-2017 Changes.
    if ($("#datepickerfrom").val()) {
        FromDate = new Date($("#datepickerfrom").val());
    }
    if ($("#datepickerto").val()) {
        ToDate = new Date($("#datepickerto").val());
    }  */
    
       
    if(!peoplepickerManagerInfo.HasResolvedUsers()||!peoplepickerDirectorInfo.HasResolvedUsers()||!peoplepickerVPInfo.HasResolvedUsers())
        {  alert("Enter all required fields marked with *.");
                     return;	
        }
      
   
    if(!CostCenter||!ProjectName||!WorkType||!GLName||!HeadCount||!VendorName)
   		{  alert("Enter all required fields marked with *.");
                    return;	
        }
        
        // Duration field validation for Vendor1.
        if(!DurationVendor1)
        {
        alert("Enter all required fields marked with *.");
                    return;	
        }
        else if(DurationVendor1.indexOf('.') != -1)
        {
         	var noOfDigits = DurationVendor1.length;
         	 var dots = 0;
             for(var i=0; i<noOfDigits; i++) {
             	if(DurationVendor1[i]=='.') dots++;
            	 if(dots>1) {
               	 	alert("Duration field allows only one dot, enter data correctly");
               		 return; }
               		
               	 else if(DurationVendor1.indexOf('.')+2!=noOfDigits)
         			{
        				 alert("Duration field allows only one digit after decimal, enter data correctly");
         				 return;	
           		    }
           }        
         } // End of validation for Vendor1 Duration.
     /* // Commented Date field as per Dec-2017 Changes.
    if (FromDate == null || ToDate == null) {
          alert("Enter all required fields marked with *.");
        	return;	
	    }
    else if (ToDate < FromDate) {
        alert("End date should be greater that or equal to Start date");
        return;	
	    } */
	    
	  //Total Amount calculation for Non-Managed Vendors 
	  // Duration = (ToDate-FromDate)/(1000 * 60 * 60 * 24); // Commented Date fields as per DEC-2017 changes.
	  // Duration = Duration/30.5;

	  if(!VendorName.startsWith('Managed'))
    	{
    	 if(!Rate)
    		{  alert("Enter all required fields marked with *.");
                    return;	
       		}
       		else {EstMonthlySpend = Rate*HeadCount*170;
       		 	  Amount = EstMonthlySpend*DurationVendor1; }
    	}
   	   else 
   	    {  
   	  		if(!Amount)
    		{  alert("Enter all required fields marked with *."); return; }
    		else { Amount; Rate=0; }
        }
        
      
      //Additional Vendor Details
    	var VendorName2, Rate2, HeadCount2, DurationVendor2, EstMonthlySpend2, Amount2, FromDate2, ToDate2; 
   		
   	    VendorName2= $('#div-vendorName2 input').last().val();
		HeadCount2= $('#div-headCount2 input').last().val();
		Rate2= $('#div-rate2 input').last().val();
		Amount2= $('#div-amount2 input').last().val();
		DurationVendor2= $('#div-durationVendor2 input').last().val();

     if(lstRequest.IsAdditionalVendorEanbled=='YES')
     {  
        /* // Commented Date field as per Dec-2017 Changes.			
     	 if ($("#datepickerfrom2").val()) {
       	 FromDate2 = new Date($("#datepickerfrom2").val());  }
       	 
    	 if ($("#datepickerto2").val()) {
         ToDate2 = new Date($("#datepickerto2").val()); } */
         
        // Duration field validation for Vendor2.
        if(!DurationVendor2)
        {
        alert("Enter all required fields marked with * for Additional Vendor.");
                    return;	
        }
        else if(DurationVendor2.indexOf('.') != -1)
        {
         	var noOfDigits = DurationVendor2.length;
         	 var dots = 0;
             for(var i=0; i<noOfDigits; i++) {
             	if(DurationVendor2[i]=='.') dots++;
            	 if(dots>1) {
               	 	alert("Duration field allows only one dot, enter data correctly for Additional Vendor.");
               		 return; }
               		
               	 else if(DurationVendor2.indexOf('.')+2!=noOfDigits)
         			{
        				 alert("Duration field allows only one digit after decimal, enter data correctly for Additional Vendor.");
         				 return;	
           		    }
           }        
         } // End of validation for Vendor2 Duration.


        if(!VendorName2)
   		{  alert("Enter all required fields marked with * for Additional Vendor.");
                    return;	
      	  }
      	 /* // Commented Date field as per Dec-2017 Changes.
       	if (FromDate2 == null || ToDate2 == null) {
          alert("Enter all required fields marked with * for Additional Vendor.");
        	return;	
	    }
       else if (ToDate2 < FromDate2) {
        alert("Additional Vendor's End date should be greater that or equal to Start date");
        return;	
	    } */
	   //Additional Vendor -- Total Amount calculation for Non-Managed Vendors 
        //Duration2 = (ToDate2-FromDate2)/(1000 * 60 * 60 * 24); // Commented Date field as per Dec-2017 Changes.
	    //Duration2 = Duration2/30.5; // Commented Date field as per Dec-2017 Changes.
 	  if(!VendorName2.startsWith('Managed'))
    	{
    	 if(!Rate2)
    		{  alert("Enter all required fields marked with * for Additional Vendor.");
                    return;	
       		}
       		else {
       			  EstMonthlySpend2 = Rate2*HeadCount2*170;
       		 	  Amount2 = EstMonthlySpend2*DurationVendor2;
       		 	  }
    	}
   	   else 
   	    {  
   	  		if(!Amount2)
    		{  alert("Enter all required fields marked with * for Additional Vendor."); return; }
    		else { Amount2; Rate2=0; }
        } 
        
      } // End of Additional Vendor if Condition.
        
         
           getUserId(CostCenterVP).done(function (CostCenterVPID) {
           getUserId(CCFinancialPlanner).done(function (CCFinancialPlannerID) {
          
          
           getUserId(lstRequest.costCenterDirectorEmail).done(function (costCenterDirectorID) {

            
            MgrInfo = peoplepickerManagerInfo.GetAllUserInfo();
            getUserId(MgrInfo[0].Description).done(function (managerid) {

            DirInfo = peoplepickerDirectorInfo.GetAllUserInfo();
        	getUserId(DirInfo[0].Description).done(function (directorid) {
            
      		VPInfo= peoplepickerVPInfo.GetAllUserInfo();
  			getUserId(VPInfo[0].Description).done(function (vpid) {
  			
		   addOverlay("Please Wait...<br/>We Are Processing Your Request.");			  			
        		
        	if(lstRequest.IsAdditionalVendorEanbled=='YES')
        	{
	           var datasource =
                   {
                   		
                		"VPId": vpid,
                        "DirectorId": directorid,
                        "ManagerId": managerid,
                        "CostCenterDirectorId":costCenterDirectorID,
                        "CCFinancialPlannerId":CCFinancialPlannerID,
                        "CostCenterVPId":CostCenterVPID,
                        "Title": CostCenter,
                        "CostCenterName":CostCenterName, 
						"Status": Status,
                        "Clarity_x0020_ProjectID": ProjectID,
                        "Clarity_x0020_ProjectName": ProjectName,
                        "Work_x0020_Type": WorkType,
                        // Vendor Details
                        "Vendor_x0020_Name": VendorName,
                        "DurationVendor1":DurationVendor1, //Added Duration field as per Dec-2017 Changes.
                        //"Start_x0020_Date": FromDate, // Commented Date field as per Dec-2017 Changes.
                        //"End_x0020_Date": ToDate,	 	// Commented Date field as per Dec-2017 Changes.
                        "Head_x0020_Count": HeadCount,
                        "Rate": Rate,
                        "Amount": Amount,
                        "HasAdditionalVendor":'true',
                        // Additional Vendor Details
                        "Vendor_x0020_Name2": VendorName2,
                        "DurationVendor2":DurationVendor2, //Added Duration field as per Dec-2017 Changes.
                        //"Start_x0020_Date2": FromDate2, // Commented Date field as per Dec-2017 Changes.
                        //"End_x0020_Date2": ToDate2,  // Commented Date field as per Dec-2017 Changes.
                        "Head_x0020_Count2": HeadCount2,
                        "Rate2": Rate2,
                        "Amount2": Amount2,
                        "GLName": GLName, 
                       	"Requestor_x0020_Comments": RequestorComments,
                        "Plan_x0020_ID": PlanID
                  };
              }
                  
              else if(lstRequest.IsAdditionalVendorEanbled=='NO')
        		  {
	          		 var datasource =
                  		{
                   		
                		"VPId": vpid,
                        "DirectorId": directorid,
                        "ManagerId": managerid,
                        "CostCenterDirectorId":costCenterDirectorID,
                        "CCFinancialPlannerId":CCFinancialPlannerID,
                        "CostCenterVPId":CostCenterVPID,
                        "Title": CostCenter,
                        "CostCenterName":CostCenterName, 
						"Status": Status,
                        "Clarity_x0020_ProjectID": ProjectID,
                        "Clarity_x0020_ProjectName": ProjectName,
                        "Work_x0020_Type": WorkType,
                        "HasAdditionalVendor":'false',
                        // Vendor Details
                        "Vendor_x0020_Name": VendorName,
                        "DurationVendor1": DurationVendor1, //Added Duration field as per Dec-2017 Changes.
                        //"Start_x0020_Date": FromDate, // Commented Date field as per Dec-2017 Changes.
                        //"End_x0020_Date": ToDate,	    // Commented Date field as per Dec-2017 Changes.
                        "Head_x0020_Count": HeadCount,
                        "Rate": Rate,
                        "Amount": Amount,
                        "GLName": GLName, 
                       	"Requestor_x0020_Comments": RequestorComments,
                        "Plan_x0020_ID": PlanID
                  };
				}
                        

               var response = CRUDobj.CreateItemUtility("ADC Approval Requests", datasource, "", "", "ADC_x0020_Approval_x0020_Requests").done(function () {

                    //alert("Request Deatails are saved.");
                    window.location.href = 'Home.aspx';
                   //ClearFields();
                   // __doPostBack('ctl00$PlaceHolderMain$g_03d15d1e_76fa_435f_bc36_7f899054e860$ctl01','__cancel')
	                            
                }).fail(function (jqxHR, textStatus, errorThrown) {
                    alert("1Page:'Request.aspx' Error:" + errorThrown)
                }); 
           	 }).fail(function (jqxHR, textStatus, errorThrown) {
                alert("2Page:'Request.aspx' Error:" + errorThrown)
               
            });
            
             }).fail(function (jqxHR, textStatus, errorThrown) {
            alert("3Page:'Request.aspx' Error:" + errorThrown)
         });
        
        
         }).fail(function (jqxHR, textStatus, errorThrown) {
            alert("4Page:'Request.aspx' Error:" + errorThrown)
        });
        
     }).fail(function (jqxHR, textStatus, errorThrown) {
          alert("5Page:'Request.aspx' Error:" + errorThrown)
      });
    }).fail(function (jqxHR, textStatus, errorThrown) {
          alert("6Page:'Request.aspx' Error:" + errorThrown)
   });
  }).fail(function (jqxHR, textStatus, errorThrown) {
          alert("7Page:'Request.aspx' Error:" + errorThrown)
 });

  
 //   } 
}


// Get the user ID.
function getUserId(loginName) {

    var dfd = $.Deferred();
    var context = new SP.ClientContext.get_current();
    var user = context.get_web().ensureUser(loginName);
    userlogin = loginName;
    context.load(user);
    context.executeQueryAsync(
          function () {
              dfd.resolve(user.get_id());
          },
         function (sender, args) {
             dfd.reject();
             console.log("Error1:")
         }

    );

    return dfd.promise();

}


// Clearing People picker values
var requestPeoplePicker= {};
requestPeoplePicker.clearValues = function (peoplePickerId) {
    var ppobject = SPClientPeoplePicker.SPClientPeoplePickerDict[peoplePickerId];
    usersobject = ppobject.GetAllUserInfo();
    usersobject.forEach(function (index) {
        ppobject.DeleteProcessedUser(usersobject[index]);
    });
};



function ClearFields()
	{		//window.location.reload();
	
		$('#div-clarityProjectID .label2').text('');
		$('#div-clarityProjectName select').val('');
		$('#div-vendorName select').val('');
		$('#div-rate').val('');
		$('#div-rate2').val('');
		$('#div-amount').val('');
		$('#div-amount2').val('');
		$('#div-costCenterName .label2').text('');
		$('#div-costCenterDirector .label2').text('');
		$('#div-costCenterFinancialPlanner .label2').text('');
		$('#div-costCenterVP .label2').text('');
		$('#div-glName select').val('');
		$('#div-costCenter select').val('');		
		$('#div-sowStatus select').val('');
    	$('#div-workType select').val('');
	    requestPeoplePicker.clearValues($('#div-vp .sp-peoplepicker-topLevel').attr('id'));
  	    requestPeoplePicker.clearValues($('#div-director .sp-peoplepicker-topLevel').attr('id'));
  	    requestPeoplePicker.clearValues($('#div-manager .sp-peoplepicker-topLevel').attr('id'));
  	    }


$(document).ready(function () {
	
	ExecuteOrDelayUntilScriptLoaded(lstRequest.init, "sp.js")
	
	// Vendor
    $('#datepickerfrom').datetimepicker({
        timepicker: false,
        format: 'm/d/Y',
    });
         
    $('#datepickerto').datetimepicker({
        timepicker: false,
        format: 'm/d/Y',
    });

    $('#datepickerfrom').on('change', function () {
          var selected = $(this).val();
            $('#datepickerto').val(selected);
    });
    
    $('#datepickerto').on('change', function () {
       
    });
    
    // Additional Vendor
	 $('#datepickerfrom2').datetimepicker({
        timepicker: false,
        format: 'm/d/Y',
    });
         
    $('#datepickerto2').datetimepicker({
        timepicker: false,
        format: 'm/d/Y',
    });

    $('#datepickerfrom2').on('change', function () {
          var selected = $(this).val();
            $('#datepickerto2').val(selected);
    });
    
    $('#datepickerto2').on('change', function () {
       
    });
       
       
});

  





