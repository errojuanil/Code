﻿using CrossSolar.Domain;

namespace CrossSolar.Repository
{
    public interface IAnalyticsRepository : IGenericRepository<OneHourElectricity>
    {
    }
}