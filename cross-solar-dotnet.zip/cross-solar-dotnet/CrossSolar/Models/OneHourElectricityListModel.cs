﻿using System.Collections.Generic;

namespace CrossSolar.Models
{
    public class OneHourElectricityListModel
    {
        public IEnumerable<OneHourElectricityModel> OneHourElectricitys { get; set; }
    }
}