﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Rally Rest API for .NET")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Rally Software, Inc.")]
[assembly: AssemblyProduct("Rally Rest API for .NET")]
[assembly: AssemblyCopyright("Copyright © Rally Software 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("1e578685-62b9-44b4-97ff-8b2d49bab134")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("3.0.1.0")]
[assembly: AssemblyFileVersion("3.0.1.0")]

[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Rally.RestApi.Test, PublicKey=0024000004800000940000000602000000240000525341310004000001000100a94bfacc7d8802c720773e9c39f73874c8afdecccfa6c6c1d59fc7ce4fbb0417249f12781168855a9bc8403632decc1b88c1e0f91c01b14af97e087a8d3f62d4f79399760b15d3cb0711723abfd2718494460ade8c3aa2d3450ac05b62987fb1fd3bca54e35706b8de19a2f89aba65c9741ec9046d36a317e09fdc660bbd18bc")]
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Rally.RestApi.UiForWinforms, PublicKey=0024000004800000940000000602000000240000525341310004000001000100a94bfacc7d8802c720773e9c39f73874c8afdecccfa6c6c1d59fc7ce4fbb0417249f12781168855a9bc8403632decc1b88c1e0f91c01b14af97e087a8d3f62d4f79399760b15d3cb0711723abfd2718494460ade8c3aa2d3450ac05b62987fb1fd3bca54e35706b8de19a2f89aba65c9741ec9046d36a317e09fdc660bbd18bc")]
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Rally.RestApi.UiForWpf, PublicKey=0024000004800000940000000602000000240000525341310004000001000100a94bfacc7d8802c720773e9c39f73874c8afdecccfa6c6c1d59fc7ce4fbb0417249f12781168855a9bc8403632decc1b88c1e0f91c01b14af97e087a8d3f62d4f79399760b15d3cb0711723abfd2718494460ade8c3aa2d3450ac05b62987fb1fd3bca54e35706b8de19a2f89aba65c9741ec9046d36a317e09fdc660bbd18bc")]
