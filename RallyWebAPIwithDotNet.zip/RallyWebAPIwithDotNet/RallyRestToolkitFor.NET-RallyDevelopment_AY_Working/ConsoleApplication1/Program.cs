﻿using RallyConnector.Classes;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Text;
using System.Data;
using Rally.RestApi;
using Rally.RestApi.Response;
using Rally.RestApi.Json;
using Rally.RestApi.Connection;
using Rally.RestApi.Auth;
using Rally.RestApi.Web;
using System.Threading.Tasks;
using System.Dynamic;

using System.Configuration;
using System.Net;

using System.IO;

using System.Xml.Linq;

namespace RallyConnector
{
    class Program
    {
        static string _rallyAuthenticateApiKey = string.Empty;
        static string _workSpaceID = string.Empty;
        static string _rallyItemsForQuerying = string.Empty;
        static string _queryOperator1 = string.Empty;
        static string _attribute1 = string.Empty;
        static string _value1 = string.Empty;
        static string _logFilePath = string.Empty;
        static string _csvFilePath = string.Empty;
        static string _FileLocation = string.Empty;
        static string _FileName = string.Empty;
        static string _FileType = string.Empty;
        static string _UserDisabledFlag = string.Empty;
        // static string _featureActualEndDate = string.Empty;
        // static string _featureActualEndDateOperator = string.Empty;




        static void Main(string[] args)
        {
            Common objCommon = new Common();
            Results objRes = new Results();
            RallyRestApi restApi = new RallyRestApi();

            // Reading Xml file to get the input parameters like Url, User Name
            checkConfiguration();
            ConfigHelper config = XmlHelper.ParseConfigXML();
            initializeConfiguration(config.configParams);


            restApi.AuthenticateWithApiKey(_rallyAuthenticateApiKey);
            string abc = _rallyItemsForQuerying;

            Console.WriteLine("server: " + restApi.ConnectionInfo.Server.ToString());
            Console.WriteLine("\n Api Keys: " + restApi.ConnectionInfo.ApiKey.ToString());
            Console.WriteLine("\n UserName: " + restApi.ConnectionInfo.UserName.ToString());


            //get the current subscription
            // DynamicJsonObject subscription = restApi.GetSubscription("Workspaces");

            //query the Workspaces collection
            //QueryResult queryWorkSpace = objCommon.RequestAQuery(subscription["Workspaces"], restApi, "");


            // Portfolio Items:
            if (_rallyItemsForQuerying == "ProjectTeamInfo")
            {
                _rallyItemsForQuerying = "Project";
            }
            else if (_rallyItemsForQuerying == "ProjectInfo")
            {
                _rallyItemsForQuerying = "Projects";
            }
            else if (_rallyItemsForQuerying == "PortfolioInfo")
            {
                _rallyItemsForQuerying = "portfolioitem/initiative";
            }
            else if (_rallyItemsForQuerying == "FeatureInfo" && (_attribute1 == null || _queryOperator1 == null || _value1 == null))
            {
                _rallyItemsForQuerying = "portfolioitem/feature";
            }
            else if (_rallyItemsForQuerying == "FeatureInfo" && (_attribute1 != null && _queryOperator1 != null && _value1 != null))
            {
                _rallyItemsForQuerying = "portfolioitem/feature";
                //_rallyItemsForQuerying = "portfolioitem/feature?query=(" + _attribute1 + " " + _queryOperator1 + " " + _value1 + ")";
            }

            QueryResult portfolioItems = RequestAQuery(_rallyItemsForQuerying, restApi, _workSpaceID);


            if (_rallyItemsForQuerying == "HierarchicalRequirement")
            {
                objRes.DisplayHierarchicalItems(portfolioItems, restApi);
            }
            else if (_rallyItemsForQuerying == "Projects")
            {
                objRes.DisplayProjectItemsWithIterationsReleasesAndTeammembers(portfolioItems, restApi);
            }
            else if (_rallyItemsForQuerying == "Project")
            {
                StringBuilder sbProjectWiseMembers;
                sbProjectWiseMembers = objRes.DisplayProjectAndTeamMembers(portfolioItems, restApi, _UserDisabledFlag);
                File.WriteAllText(_FileLocation + _FileName + "." + _FileType, sbProjectWiseMembers.ToString());
            }

            else if (_rallyItemsForQuerying == "portfolioitem/initiative")
            {
                StringBuilder sb;
                sb = objRes.DisplayPortfolioItems(portfolioItems, restApi);
                File.WriteAllText(_FileLocation + _FileName + "." + _FileType, sb.ToString());

            }

            else if (_rallyItemsForQuerying == "portfolioitem/feature" && (_attribute1 == null || _queryOperator1 == null || _value1 == null))
            {
                StringBuilder sb;
                sb = objRes.DisplayFeatureInformation(portfolioItems, restApi, _workSpaceID);
                File.WriteAllText(_FileLocation + _FileName + "." + _FileType, sb.ToString());

            }
            else if (_rallyItemsForQuerying == "portfolioitem/feature" && (_attribute1 != null && _queryOperator1 != null && _value1 != null))
            {
                StringBuilder sb;
                sb = objRes.DisplayFeatureInformation(portfolioItems, restApi, _workSpaceID);
                File.WriteAllText(_FileLocation + _FileName + "." + _FileType, sb.ToString());

            }





        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="rallyAttributeName"></param>
        /// <param name="restApi"></param>
        /// <param name="workSpaceRef"></param>
        /// <returns></returns>

        private static QueryResult RequestAQuery(dynamic rallyAttributeName, RallyRestApi restApi, string workSpaceRef)
        {
            Request requestedAttribute;


            requestedAttribute = new Request(rallyAttributeName);


            if (_queryOperator1 != string.Empty)
            {
                if (_attribute1 != string.Empty)
                {
                    if (_value1 != string.Empty)
                    {
                        string operatorValue = OperatorCheck(_queryOperator1);

                        Query.Operator op = Query.GetOperator2(operatorValue);
                        requestedAttribute.Query = new Query(_attribute1, op, _value1);
                    }
                }
            }
            requestedAttribute.Workspace = workSpaceRef;
            QueryResult queryResult = restApi.Query(requestedAttribute);
            return queryResult;
        }


        /// <summary>
        /// Initialize configuration
        /// </summary>
        /// <param name="configParams"></param>
        private static void initializeConfiguration(Dictionary<string, string> configParams)
        {
            _rallyAuthenticateApiKey = configParams.Where(x => x.Key == "rallyAuthenticateApiKey").FirstOrDefault().Value;
            _workSpaceID = configParams.Where(x => x.Key == "workSpaceID").FirstOrDefault().Value;
            _rallyItemsForQuerying = configParams.Where(x => x.Key == "rallyItemsForQuerying").FirstOrDefault().Value;
            _logFilePath = configParams.Where(x => x.Key == "logFilePath").FirstOrDefault().Value;
            _csvFilePath = configParams.Where(x => x.Key == "csvFilePath").FirstOrDefault().Value;

            _attribute1 = configParams.Where(x => x.Key == "attribute1").FirstOrDefault().Value;
            _queryOperator1 = configParams.Where(x => x.Key == "queryOperator1").FirstOrDefault().Value;
            _value1 = configParams.Where(x => x.Key == "value1").FirstOrDefault().Value;
            _FileLocation = configParams.Where(x => x.Key == "FileLocation").FirstOrDefault().Value;
            _FileName = configParams.Where(x => x.Key == "FileName").FirstOrDefault().Value;
            _FileType = configParams.Where(x => x.Key == "FileType").FirstOrDefault().Value;
            _UserDisabledFlag = configParams.Where(x => x.Key == "UserDisabledFlag").FirstOrDefault().Value;


        }
        /// <summary>
        /// Check Configuration and prompt user if anything is blank
        /// </summary>
        private static void checkConfiguration()
        {
            try
            {
                if (ConfigHelper.IsConfigured)
                {
                    Console.WriteLine("Already Configured. Moving On...");
                }
                else
                {
                    Console.WriteLine("App not configured. Please specify below details to configure App.");
                    //LogHelper.sb.AppendLine("App not configured. Getting Configuration Details");
                    XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);

                    xDoc.Save(Constants.CONFIG_XML_PATH);
                    Console.WriteLine("Configuration Done!!");
                    WriteToLogFile("Configuration Done!!");
                }
            }
            catch (Exception ex)
            {
                WriteToLogFile("ERROR from checkConfiguration " + ex);
            }
        }

        /// <summary>
        /// OperatorCheck
        /// </summary>
        /// <param name="operatorValue"></param>
        /// <returns></returns>
        private static string OperatorCheck(string operatorValue)
        {
            switch (operatorValue)
            {
                case "LessThan": { operatorValue = "<"; } break;
                case "LessThanOrEqualTo": { operatorValue = "<="; } break;
                case "GreaterThan": { operatorValue = ">"; } break;
                case "GreaterThanOrEqualTo": { operatorValue = ">="; } break;
            }
            return operatorValue;


        }
        /// <summary>
        /// Write logs to text file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string WriteToLogFile(string data)
        {
            try
            {

                FileStream fs = new FileStream(_logFilePath + "logs.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("[" + DateTime.Now + "]" + data);
                sw.Close();
                fs.Close();
                return "log written successfully";
            }
            catch
            {
                return "failed to write log";
            }
        }
    }

}
