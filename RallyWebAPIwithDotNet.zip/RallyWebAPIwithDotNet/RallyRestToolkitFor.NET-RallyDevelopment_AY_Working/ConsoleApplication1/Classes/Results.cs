﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using System.Data;
using Rally.RestApi;
using Rally.RestApi.Response;
using Rally.RestApi.Json;
using Rally.RestApi.Connection;
using Rally.RestApi.Auth;
using Rally.RestApi.Web;
using System.IO;


namespace RallyConnector
{
    public class Results
    {
        Common objCommon = new Common();


        public StringBuilder DisplayPortfolioItems(QueryResult portfolioItems, RallyRestApi restApi)
        {
            // UserStory
            string userStoryName = null;
            string iterationName = null;
            string iterationStartDate = null;
            string iterationEndDate = null;
            string releaseName = null;
            string releaseStartDate = null;
            string releaseDate = null;
            string userStoryOwner = null;

            // Feature 
            string featureOwner = null;
            string featureReleaseName = null;
            string featureReleaseDate = null;
            string featureActualStartDate = null;
            string featureActualEndDate = null;
            string featurePlannedStartDate = null;
            string featurePlannedEndDate = null;
            string featureState = null;

            //Initiative
            string initiativeName = null;
            string initiativeOwner = null;
            string initiativeState = null;
            string initiativePreliminaryEstimate = null;
            string initiativeActualStartDate = null;
            string initiativeActualEndDate = null;
            string initiativePlannedStartDate = null;
            string initiativePlannedEndDate = null;
            var sbUserStory = new StringBuilder();
            var sbFeature = new StringBuilder();
            /*   sbFeature.AppendFormat
                                   (
                                    "{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15},{16} "
                                   , "UserStoryID", "UserStoryName", "Created Date"
                                   , "Last Updated Date", "AcceptedDate", "FlowState"
                                   , "TaskActualTotal", "TaskRemainingTotal"
                                   , "TaskEstimateTotal", "TaskStatus"
                                   , "Project", "Workspace", "c_DFSKanbanStatusNew"
                                   , "initiativeID", "initiativeName", "featureID", "featureName"
                                   ); */


            sbUserStory.AppendFormat

                   ("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17} , {18}, {19}, {20}, {21}, {22}, {23}, {24},{25},{26}, {27}, {28}, {29}, {30}, {31}, {32}, {33}, {34},{35}, {36}, {37}, {38}, {39}, {40},{41}, {42}, {43}, {44},{45}, {46}, {47}, {48},{49}, {50}"
                                , "UserStoryID", "UserStoryName", "CreationDate", "Last Updated Date"
                                , "AcceptedDate", "FlowState"
                                , "TaskActualTotal", "TaskRemainingTotal", "TaskEstimateTotal", "TaskStatus"
                                , "Project", "Workspace", "c_DFSKanbanStatusNew"
                                , "Release Name"
                                , "Release Date"
                                , "ReleaseStartDate"
                                , "IterationName"
                                , "IterationStartDate"
                                , "IterationEndDate"
                                , "userStoryOwner"
                                , "FeatureID", "Feature Name"
                                , "Feature Owner", "Value Score", "Risk Score", "Feature State"
                                , "WSJF Score", "Expedite", "Refined Estimate"
                                , "Release Name", "Release Date"
                                , "Planned Start Date", "Planned End Date"
                                , "Actual Start Date", "Actual End Date"
                                , "initiativeID", "initiative Name"
                                , "initiative Owner", "I Value Score", "I Risk Score", "initiative State"
                                , "I WSJF Score", "I Expedite", "I Refined Estimate"
                                , "I Planned Start Date", "I Planned End Date"
                                , "I Actual Start Date", "I Actual End Date"
                                , "Preliminary Estimate", "Preliminary Estimate Value"
                                , "Ready"

                                );


            sbUserStory.AppendLine();


            foreach (var initiative in portfolioItems.Results)
            {



                Console.Write("\n------------------------------------------------------------------------------");
                Console.Write("\n \nInitiative ID: " + initiative["FormattedID"]);
                //Console.Write("\n \nInitiative name: " + initiative["_refObjectName"]);
                //Console.Write("\n \nInitiative Owner: " + initiative["Owner"]["_refObjectName"]);
                // Console.Write("\n \nProject Name: " + initiative["Project"]["_refObjectName"]);
                // Console.Write("\n \nClarity Project ID: " + initiative["c_ClarityProjectID"]);


                //sb.AppendFormat("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}", initiative["FormattedID"], initiative["_refObjectName"], "", "","", "", "", "");
                //sb.AppendLine();

                if (initiative["Children"]["Count"] > 0)
                {
                    QueryResult featureData = objCommon.RequestAQuery(initiative["Children"], restApi, "");

                    foreach (var feature in featureData.Results)
                    {
                        // Console.Write("\n\n  Feature ID: " + feature["FormattedID"]);

                        /*     sbFeature.AppendFormat("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}"
                               ,initiative["FormattedID"], initiative["_refObjectName"], feature["FormattedID"]
                               ,feature["_refObjectName"],"", "", "", "");
                              sbFeature.AppendLine();  */

                        if (feature["UserStories"]["Count"] > 0)
                        {

                            QueryResult UserStories = objCommon.RequestAQuery(feature["UserStories"], restApi, "");
                            foreach (var userStory in UserStories.Results)
                            {
                                if (userStory["Release"] != null)
                                {
                                    releaseName = userStory["Release"]["_refObjectName"];
                                    if (releaseName.Contains(','))
                                    {
                                        releaseName = releaseName.Replace(',', ' ');
                                    }
                                    releaseDate = userStory["Release"]["ReleaseDate"];
                                    releaseStartDate = userStory["Release"]["ReleaseStartDate"];

                                }

                                if (userStory["Iteration"] != null)
                                {
                                    iterationName = userStory["Iteration"]["_refObjectName"];
                                    if (iterationName.Contains(','))
                                    {
                                        iterationName = iterationName.Replace(',', ' ');
                                    }

                                    iterationStartDate = userStory["Iteration"]["StartDate"];
                                    iterationEndDate = userStory["Iteration"]["EndDate"];

                                }
                                if (userStory["Owner"] != null)
                                {
                                    userStoryOwner = userStory["Owner"]["_refObjectName"];

                                }


                                userStoryName = userStory["_refObjectName"];

                                if (userStoryName.Contains(','))
                                {
                                    userStoryName = userStoryName.Replace(',', ' ');
                                }

                                string featureName;

                                // Feature Details
                                featureName = feature["_refObjectName"];

                                if (featureName.Contains(','))
                                {
                                    featureName = featureName.Replace(',', ' ');
                                }

                                if (feature["Owner"] != null)
                                {
                                    featureOwner = feature["Owner"]["_refObjectName"];
                                }

                                if (feature["Release"] != null)
                                {
                                    featureReleaseName = feature["Release"]["_refObjectName"];
                                    if (featureReleaseName.Contains(','))
                                    {
                                        featureReleaseName = featureReleaseName.Replace(',', ' ');
                                    }
                                    featureReleaseDate = feature["Release"]["ReleaseDate"];
                                }
                                if (feature["State"] != null)
                                {
                                    featureState = feature["State"]["_refObjectName"];

                                }
                                if (feature["ActualStartDate"] != null)
                                {
                                    featureActualStartDate = feature["ActualStartDate"];

                                }
                                if (feature["ActualEndDate"] != null)
                                {
                                    featureActualEndDate = feature["ActualEndDate"];

                                }


                                if (feature["PlannedStartDate"] != null)
                                {
                                    featurePlannedStartDate = feature["PlannedStartDate"];

                                }
                                if (feature["PlannedEndDate"] != null)
                                {
                                    featurePlannedEndDate = feature["PlannedEndDate"];

                                }

                                //Initiave
                                initiativeName = initiative["_refObjectName"];

                                if (initiativeName.Contains(','))
                                {
                                    initiativeName = initiativeName.Replace(',', ' ');
                                }

                                if (initiative["Owner"] != null)
                                {
                                    initiativeOwner = initiative["Owner"]["_refObjectName"];
                                }
                                if (initiative["State"] != null)
                                {
                                    initiativeState = initiative["State"]["_refObjectName"];
                                }
                                if (initiative["PreliminaryEstimate"] != null)
                                {
                                    initiativePreliminaryEstimate = initiative["PreliminaryEstimate"]["_refObjectName"];
                                }
                                if (initiative["ActualStartDate"] != null)
                                {
                                    initiativeActualStartDate = initiative["ActualStartDate"];

                                }
                                if (initiative["ActualEndDate"] != null)
                                {
                                    initiativeActualEndDate = initiative["ActualEndDate"];

                                }


                                if (initiative["PlannedStartDate"] != null)
                                {
                                    initiativePlannedStartDate = initiative["PlannedStartDate"];

                                }
                                if (initiative["PlannedEndDate"] != null)
                                {
                                    initiativePlannedEndDate = initiative["PlannedEndDate"];

                                }



                                sbUserStory.AppendFormat
                               ("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17} , {18}, {19}, {20}, {21}, {22}, {23}, {24},{25},{26}, {27}, {28}, {29}, {30}, {31}, {32}, {33}, {34},{35}, {36}, {37}, {38}, {39}, {40},{41}, {42}, {43}, {44},{45}, {46}, {47}, {48},{49}, {50}"
                                , userStory["FormattedID"], userStoryName
                                , userStory["CreationDate"]
                                , userStory["LastUpdateDate"], userStory["AcceptedDate"]
                                , userStory["FlowState"]["_refObjectName"]
                               , userStory["TaskActualTotal"], userStory["TaskRemainingTotal"]
                               , userStory["TaskEstimateTotal"], userStory["TaskStatus"]
                                , userStory["Project"]["_refObjectName"], userStory["Workspace"]["_refObjectName"]
                                , userStory["c_DFSKanbanStatusNew"]
                                , releaseName
                                , releaseDate
                                , releaseStartDate
                                , iterationName
                                , iterationStartDate
                                , iterationEndDate
                                , userStoryOwner

                                , feature["FormattedID"], featureName
                                , featureOwner, feature["ValueScore"]
                                , feature["RiskScore"], featureState
                                , feature["WSJFScore"], feature["Expedite"]
                                , feature["RefinedEstimate"]
                                , featureReleaseName, featureReleaseDate
                                , featurePlannedStartDate, featurePlannedEndDate
                                , featureActualStartDate, featureActualEndDate
                                , initiative["FormattedID"], initiative["_refObjectName"]
                                , initiativeOwner, initiative["ValueScore"], initiative["RiskScore"]
                                , initiativeState
                                , initiative["WSJFScore"], initiative["Expedite"], initiative["RefinedEstimate"]
                                , initiativePlannedStartDate, initiativePlannedEndDate
                                , initiativeActualStartDate, initiativeActualEndDate
                                , initiativePreliminaryEstimate, initiative["PreliminaryEstimateValue"]
                                , initiative["Ready"]


                                );
                                sbUserStory.AppendLine();

                                if (userStory["Tasks"]["Count"] > 0)
                                {
                                    QueryResult tasks = objCommon.RequestAQuery(userStory["Tasks"], restApi, "");
                                    foreach (var task in tasks.Results)
                                    {

                                        //Console.Write("\n\n    Task ID: " + task["FormattedID"]);
                                        // Console.Write("\n    Task Name: " + task["_refObjectName"]);
                                        //  sb.AppendFormat("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}", initiative["FormattedID"], initiative["_refObjectName"], feature["FormattedID"], feature["_refObjectName"],
                                        //  userStory["FormattedID"], userStory["_refObjectName"], task["FormattedID"], task["_refObjectName"]);
                                        // sb.AppendLine();

                                    }

                                }

                                if (userStory["Defects"]["Count"] > 0)
                                {
                                    QueryResult defects = objCommon.RequestAQuery(userStory["Defects"], restApi, "");
                                    foreach (var defect in defects.Results)
                                    {
                                        // Console.Write("\n\n     Defects ID: " + defect["FormattedID"]);
                                        // Console.Write("\n     Defects Name: " + defect["_refObjectName"]);
                                    }

                                }
                            }

                        }
                    }

                }



            }
            return sbUserStory;
            // File.WriteAllText(@"Y:\Agile Rally\Working\UserStories.csv", sb.ToString());
            // File.AppendAllText(@"Y:\Agile Rally\Working\test7.csv", sb.ToString());

        }

        public void DisplayHierarchicalItems(QueryResult hierarchicalItems, RallyRestApi restApi)
        {
            var sb = new StringBuilder();
            sb.AppendFormat

                   ("{0}| {1}| {2}| {3} | {4} | {5} | {6} | {7} | {8} | {9} | {10} | {11} | {12} "
                                , "UserStoryID", "UserStoryName", "Created Date", "Last Updated Date", "AcceptedDate", "FlowState"
                                , "TaskActualTotal", "TaskRemainingTotal", "TaskEstimateTotal", "TaskStatus"
                                , "Project", "Workspace", "c_DFSKanbanStatusNew"
                // , "initiativeID", "initiativeName", "featureID", "featureName"
                                );


            sb.AppendLine();
            foreach (var userStory in hierarchicalItems.Results)
            {

                Console.Write("\n------------------------------------------------------------------------------");
                Console.Write("\n \n US ID: " + userStory["FormattedID"]);
                // Console.Write("\n \n US ID: " + portfolioItem["_refObjectName"]);
                sb.AppendFormat
                              ("{0}| {1}| {2}| {3} | {4} | {5} | {6} | {7} | {8} | {9} | {10} | {11} | {12} "
                              , userStory["FormattedID"], userStory["_refObjectName"], userStory["CreationDate"], userStory["LastUpdateDate"], userStory["AcceptedDate"]
                              , userStory["FlowState"]["_refObjectName"]
                             , userStory["TaskActualTotal"], userStory["TaskRemainingTotal"], userStory["TaskEstimateTotal"], userStory["TaskStatus"]
                              , userStory["Project"]["_refObjectName"], userStory["Workspace"]["_refObjectName"], userStory["c_DFSKanbanStatusNew"]
                    // , initiative["FormattedID"], initiative["_refObjectName"], feature["FormattedID"], feature["_refObjectName"]
                              );
                sb.AppendLine();


                /*  if (userStory["Tasks"]["Count"] > 0)
                  {
                      QueryResult taskData = objCommon.RequestAQuery(userStory["Tasks"], restApi, "");

                      foreach (var task in taskData.Results)
                      {
                          Console.Write("\n Task ID: " + task["FormattedID"]);
                          Console.Write("\n Task Name: " + task["_refObjectName"]);
                      }


                  }

                  if (userStory["Defects"]["Count"] > 0)
                  {
                      QueryResult defectsData = objCommon.RequestAQuery(userStory["Defects"], restApi, "");

                      foreach (var defect in defectsData.Results)
                      {
                          Console.Write("\n Defects Name: " + defect["_refObjectName"]);
                      }

                  }

                  if (userStory["Milestones"]["Count"] > 0)
                  {
                      QueryResult mileStoneData = objCommon.RequestAQuery(userStory["Milestones"], restApi, "");

                      foreach (var mileStone in mileStoneData.Results)
                      {
                          Console.Write("\n Milestone Name: " + mileStone["_refObjectName"]);
                      }


                  }
                  if (userStory["Release"] != null)
                  {

                      Console.Write("\n Release Name: " + userStory["Release"]["_refObjectName"]);

                  }

                  */

            }
            //File.WriteAllText(@"Y:\Agile Rally\Working\test7.xls", sb.ToString());
            File.WriteAllText(@"Y:\Agile Rally\Working\test7.csv", sb.ToString());
            Console.ReadKey();
        }

        public void DisplayProjectItemsWithIterationsReleasesAndTeammembers(QueryResult projectResults, RallyRestApi restApi)
        {

            foreach (var projectData in projectResults.Results)
            {
                Console.Write("\n------------------------------------------------------------------------------");
                Console.Write("\n \n Project Name: " + projectData["_refObjectName"]);
                Console.Write("\n Workspace Name:" + projectData["Workspace"]["_refObjectName"]);
                if (projectData["Parent"] != null)
                {
                    Console.Write("\n Parent Project:" + projectData["Parent"]["_refObjectName"]);
                }


                //Iterations 
                if (projectData["Iterations"]["Count"] > 0)
                {

                    QueryResult iterationResults = objCommon.RequestAQuery(projectData["Iterations"], restApi, "");
                    Console.WriteLine("\n \n Iteration of " + projectData["_refObjectName"]);
                    foreach (var sprint in iterationResults.Results)
                    {
                        Console.WriteLine("\n" + sprint["_refObjectName"]);
                    }

                }
                else
                {
                    Console.WriteLine("\n No Iterations available for this project");
                }

                //Releases 
                if (projectData["Releases"]["Count"] > 0)
                {
                    QueryResult ReleaseResults = objCommon.RequestAQuery(projectData["Releases"], restApi, "");
                    Console.WriteLine("\n Release of " + projectData["_refObjectName"]);
                    foreach (var sprint in ReleaseResults.Results)
                    {
                        Console.WriteLine("\n " + sprint["_refObjectName"]);
                    }

                }
                else
                {
                    Console.WriteLine("\n No releases available for this project");
                }


                // Team Members
                if (projectData["TeamMembers"]["Count"] > 0)
                {

                    QueryResult teamMembersResults = objCommon.RequestAQuery(projectData["TeamMembers"], restApi, "");
                    Console.WriteLine("\n Team Members of " + projectData["_refObjectName"]);
                    foreach (var teamMember in teamMembersResults.Results)
                    {
                        Console.WriteLine(teamMember["UserName"]);
                    }
                }

                else
                {
                    Console.WriteLine("\n No TeamMembers available for this project");
                }
                // Console.ReadKey();


            }

        }

        public StringBuilder DisplayProjectAndTeamMembers(QueryResult projectResults, RallyRestApi restApi, string userDisabledFlag)
        {
            string projectName = null;
            string parentProjectName = null;
            // string Level3ProjectName = null;
            //  string ProjectName = null;
            string projectOwner = null;
            string userDisplayName = null;
            string userEmailAddress = null;
            string userRole = null;
            string isUserDisabled = null;
            string userDepartment = null;
            string userLastLoginDate = null;
            var sbProjectWiseMembers = new StringBuilder();

            sbProjectWiseMembers.AppendFormat

                   ("{0}, {1}, {2}, {3} , {4} , {5} , {6} , {7} , {8} "
                                , "Project Name", "Parent Project Name", "Project Owner", "Team Member Display Name", "Team Member Email Address", "Team Member Role"
                                , "Disabled Flag", "Department name", "Last Login Date"

                                );


            sbProjectWiseMembers.AppendLine();

            foreach (var projectData in projectResults.Results)
            {
                Console.Write("\n------------------------------------------------------------------------------");
                Console.Write("\n \n Project Name: " + projectData["_refObjectName"]);
                Console.Write("\n Workspace Name:" + projectData["Workspace"]["_refObjectName"]);
                if (projectData["_refObjectName"] != null)
                {
                    projectName = projectData["_refObjectName"];
                    if (projectName.Contains(','))
                    { projectName = projectName.Replace(',', ' '); }
                }

                if (projectData["Parent"] != null)
                {
                    if (projectData["Parent"] != null)
                    {
                        parentProjectName = projectData["Parent"]["_refObjectName"];
                        if (parentProjectName.Contains(','))
                        { parentProjectName = parentProjectName.Replace(',', ' '); }
                    }
                    else { parentProjectName = "n/a"; }
                    if (projectData["Owner"] != null)
                    {
                        projectOwner = projectData["Owner"]["_refObjectName"];
                    }
                    else { projectOwner = "n/a"; }


                    // Console.Write("\n LEVEL1 Parent Project:" + projectData["Parent"]["_refObjectName"]);


                    // Team Members
                    if (projectData["TeamMembers"]["Count"] > 0)
                    {

                        QueryResult teamMembersResults = objCommon.RequestAQuery(projectData["TeamMembers"], restApi, "");
                        // Console.WriteLine("\n LEVEL1 Team Members of " + projectData["_refObjectName"]);
                        foreach (var teamMember in teamMembersResults.Results)
                        {
                            if (teamMember["_refObjectName"] != null)
                            {

                                userDisplayName = teamMember["_refObjectName"];
                                if (userDisplayName.Contains(','))
                                { userDisplayName = userDisplayName.Replace(',', ' '); }
                            }
                            else { userDisplayName = "n/a"; }
                            if (teamMember["EmailAddress"] != null)
                            {
                                userEmailAddress = teamMember["EmailAddress"];
                            }
                            else { userEmailAddress = "n/a"; }
                            if (teamMember["Role"] != null)
                            {
                                userRole = teamMember["Role"];
                                if (userRole.Contains(','))
                                { userRole = userRole.Replace(',', ' '); }
                            }
                            else { userRole = "n/a"; }
                            if (teamMember["Disabled"] != null)
                            {
                                isUserDisabled = Convert.ToString(teamMember["Disabled"]);
                            }
                            else { isUserDisabled = "n/a"; }
                            if (teamMember["Department"] != null)
                            {
                                userDepartment = teamMember["Department"];
                                if (userDepartment.Contains(','))
                                { userDepartment = userDepartment.Replace(',', ' '); }
                            }
                            else { userDepartment = "n/a"; }
                            if (teamMember["LastLoginDate"] != null)
                            {
                                userLastLoginDate = teamMember["LastLoginDate"];
                            }
                            else { userLastLoginDate = "n/a"; }
                            //Console.WriteLine(teamMember["UserName"]);
                            if (userDisabledFlag == "Yes")
                            {
                                if (isUserDisabled == "True")
                                {
                                    sbProjectWiseMembers.AppendFormat

                                      ("{0}, {1}, {2}, {3} , {4} , {5} , {6} , {7} , {8} "
                                       , projectName, parentProjectName, projectOwner
                                       , userDisplayName, userEmailAddress, userRole
                                       , isUserDisabled, userDepartment, userLastLoginDate

                                       );

                                    sbProjectWiseMembers.AppendLine();
                                }
                            }
                            else if (userDisabledFlag == "No")
                            {
                                if (isUserDisabled == "False")
                                {
                                    sbProjectWiseMembers.AppendFormat

                                      ("{0}, {1}, {2}, {3} , {4} , {5} , {6} , {7} , {8} "
                                       , projectName, parentProjectName, projectOwner
                                       , userDisplayName, userEmailAddress, userRole
                                       , isUserDisabled, userDepartment, userLastLoginDate

                                       );

                                    sbProjectWiseMembers.AppendLine();
                                }
                            }
                            else if (userDisabledFlag == "All")
                            {
                                sbProjectWiseMembers.AppendFormat

                                  ("{0}, {1}, {2}, {3} , {4} , {5} , {6} , {7} , {8} "
                                   , projectName, parentProjectName, projectOwner
                                   , userDisplayName, userEmailAddress, userRole
                                   , isUserDisabled, userDepartment, userLastLoginDate

                                   );

                                sbProjectWiseMembers.AppendLine();
                            }
                        }
                    }

                    else
                    {
                        sbProjectWiseMembers.AppendFormat

                                ("{0}, {1}, {2}, {3} , {4} , {5} , {6} , {7} , {8} "
                                 , projectName, parentProjectName, projectOwner
                                 , "", "", ""
                                 , "", "", ""

                                 );

                        sbProjectWiseMembers.AppendLine();
                    }
                }


            }  // End of ProjectDataLevel1
            return sbProjectWiseMembers;

        }


        internal StringBuilder DisplayFeatureInformation(QueryResult portfolioItems, RallyRestApi restApi, string workSpace)
        {

            // Feature 
            string rallyProjectName = null;
            string rallyParentProjectName = null;
            string featureID = null;
            string featureName = null;
            string initiativeID = null;
            string initiativeName = null;
            string State = null;
            DateTime actualEndDate = DateTime.Now;
            string deploymentDate = null;
            string releaseName = null;
            DateTime releaseStartDate = DateTime.Now;
            DateTime releaseEndDate = DateTime.Now;
            string plannedStartDate = null;
            string plannedEndDate = null;
            string actualStartDate = null;
            int preliminaryEstimate = 0;
            int refinedEstimate = 0;
            string featureOwner = null;


            string releaseRef = null;
            string projectRef = null;
            string initiativeRef = null;

            //For future purpose
            // string investmentCategory = null;
            //int valueScore = 0;
            // int riskScore = 0;
            //decimal WSJFScore = 0;
            // int userStoryCount = 0;


            var sbFeature = new StringBuilder();

            sbFeature.AppendFormat
                                ("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17}"


                               , "Project Name", "Parent Project Name", "FeatureID", "Feature Name"
                               , "initiativeID", "initiative Name", "State"
                               , "Actual End Date", "Deployment Date"
                               , "Release Name", "Release start Date", "Release Date"
                               , "Planned Start Date", "Planned End Date"
                               , "Actual Start Date", "Preliminary Estimate"
                               , "Refined Estimate", "Feature Owner"

                              // , "Value Score", "Risk Score", "WSJF Score", "Investment Category", "# of Stories"

                               );

            sbFeature.AppendLine();

            Console.Write("\n------------------------------------------------------------------------------");
            foreach (var feature in portfolioItems.Results)
            {
                // Actual End Date IF Block
                if (feature["ActualEndDate"] != null)
                {
                    actualEndDate = Convert.ToDateTime(feature["ActualEndDate"]);
                    // Relese block
                    if (feature["Release"] != null)
                    {
                        releaseName = feature["Release"]["_refObjectName"];
                        if (releaseName.Contains(','))
                        {
                            releaseName = releaseName.Replace(',', ' ');
                        }
                        Request releaseRequest = new Request("release");
                        releaseRef = feature["Release"]["_ref"];

                        releaseRef = releaseRef.Substring(releaseRef.LastIndexOf("release"), releaseRef.Length - releaseRef.LastIndexOf("release"));
                        releaseRef = releaseRef.Remove(0, 8);

                        releaseRequest.Query = new Query("ObjectID", Query.Operator.Equals, releaseRef);

                        releaseRequest.Workspace = workSpace;

                        // Make request and process results 
                        QueryResult releaseResults = restApi.Query(releaseRequest);
                        foreach (var releaseData in releaseResults.Results)
                        {
                            if (releaseData["ReleaseDate"] != null)
                            {
                                releaseEndDate = Convert.ToDateTime(releaseData["ReleaseDate"]);
                                //releaseEndDate = releaseEndDate.ToString()
                            }
                            if (releaseData["ReleaseStartDate"] != null)
                            {
                                releaseStartDate = Convert.ToDateTime(releaseData["ReleaseStartDate"]);
                               // releaseStartDate = releaseStartDate.ToString("mm/dd/yyyy");

                            }
                        }

                        // Actual End Date greater than PI Dates (Release Start and Release Date)
                        if (actualEndDate >= releaseStartDate && actualEndDate <= releaseEndDate)
                        {
                            //Rally Team/Project Name
                            if (feature["Project"] != null)
                            {
                                rallyProjectName = feature["Project"]["_refObjectName"];
                            }
                            featureID = feature["FormattedID"];
                            featureName = feature["_refObjectName"];
                            if (featureName.Contains(','))
                            {
                                featureName = featureName.Replace(',', ' ');
                            }

                            Request requestParentProject = new Request("project");
                            projectRef = feature["Project"]["_ref"];

                            projectRef = projectRef.Substring(projectRef.LastIndexOf("project"), projectRef.Length - projectRef.LastIndexOf("project"));
                            projectRef = projectRef.Remove(0, 8);
                            requestParentProject.Query = new Query("ObjectID", Query.Operator.Equals, projectRef);

                            requestParentProject.Workspace = workSpace;


                            QueryResult projectResults = restApi.Query(requestParentProject);
                            foreach (var parentProject in projectResults.Results)
                            {
                                //initiativeID = parentProject["FormattedID"];
                                rallyParentProjectName = parentProject["Parent"]["_refObjectName"];
                            }
                            if (rallyParentProjectName.Contains(','))
                            {
                                rallyParentProjectName = rallyParentProjectName.Replace(',', ' ');
                            }



                            if (feature["Owner"] != null)
                            {
                                featureOwner = feature["Owner"]["_refObjectName"];

                            }

                            //Initiave
                            if (feature["Parent"] != null)
                            {
                                Request requestInitiative = new Request("portfolioitem/initiative");
                                initiativeRef = feature["Parent"]["_ref"];

                                initiativeRef = initiativeRef.Substring(initiativeRef.LastIndexOf("initiative"), initiativeRef.Length - initiativeRef.LastIndexOf("initiative"));
                                initiativeRef = initiativeRef.Remove(0, 11);
                                requestInitiative.Query = new Query("ObjectID", Query.Operator.Equals, initiativeRef);

                                requestInitiative.Workspace = workSpace;


                                QueryResult initiativeResults = restApi.Query(requestInitiative);
                                foreach (var initiative in initiativeResults.Results)
                                {
                                    initiativeID = initiative["FormattedID"];
                                    initiativeName = initiative["_refObjectName"];
                                }
                                if (initiativeName.Contains(','))
                                {
                                    initiativeName = initiativeName.Replace(',', ' ');
                                }

                            }
                            if (feature["State"] != null)
                            {
                                State = feature["State"]["_refObjectName"];

                            }

                            if (feature["PreliminaryEstimateValue"] != null)
                            {
                                preliminaryEstimate = feature["PreliminaryEstimateValue"];

                            }

                            if (feature["c_DeploymentDate"] != null)
                            {
                                deploymentDate = feature["c_DeploymentDate"];

                            }
                            //For future use
                            // valueScore = feature["ValueScore"];
                            // riskScore = feature["RiskScore"];
                            //  WSJFScore = feature["WSJFScore"];
                            //refinedEstimate RefinedEstimate  
                            refinedEstimate = feature["RefinedEstimate"];


                            if (feature["PlannedStartDate"] != null)
                            {
                                plannedStartDate = feature["PlannedStartDate"];

                            }
                            if (feature["PlannedEndDate"] != null)
                            {
                                plannedEndDate = feature["PlannedEndDate"];

                            }
                            if (feature["ActualStartDate"] != null)
                            {
                                actualStartDate = feature["ActualStartDate"];

                            }

                            //deploymentDate
                            if (feature["c_DeploymentDate"] != null)
                            {
                                deploymentDate = feature["c_DeploymentDate"];

                            }



                            sbFeature.AppendFormat
                           ("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17}"


                            , rallyProjectName, rallyParentProjectName, featureID, featureName
                            , initiativeID, initiativeName, State
                            , actualEndDate, deploymentDate
                            , releaseName, releaseStartDate, releaseEndDate
                            , plannedStartDate, plannedEndDate
                            , actualStartDate, preliminaryEstimate, refinedEstimate, featureOwner
                                //,investmentCategory, valueScore, riskScore, WSJFScore,
                            );
                            sbFeature.AppendLine();

                        } // Actual End Date greater than PI Dates (Release Start and Release Date)

                    } // End of Release block

                } // Actual End Date IF Block

            }

            return sbFeature;
        }
    }
}
