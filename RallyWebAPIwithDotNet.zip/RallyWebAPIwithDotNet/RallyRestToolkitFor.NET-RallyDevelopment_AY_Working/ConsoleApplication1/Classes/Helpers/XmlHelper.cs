﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace RallyConnector.Classes
{
   public class XmlHelper
    {



        public static Dictionary<string, string> getConfigParams(XDocument xDoc)
        {
            Dictionary<string, string> configParams = (from p in xDoc.Descendants("param")
                                                       select new KeyValuePair<string, string>
                                                           (p.Attribute("key").Value,
                                                             p.Attribute("value").Value
                                                           ))
                    .ToDictionary(x => x.Key, x => x.Value);


            return configParams;
        }

        public static ConfigHelper ParseConfigXML()
        {
            Console.WriteLine("Loading Config XML from path " + Constants.CONFIG_XML_PATH);
            //LogHelper.sb.sb.AppendLine("Loading Config XML from path " + Constants.CONFIG_XML_PATH);

            XDocument xDoc = XDocument.Load(Constants.CONFIG_XML_PATH);
            Console.WriteLine("Config XML loaded Sucessfully!!");
            //LogHelper.sb.sb.AppendLine("Config XML loaded Sucessfully!!");

            ConfigHelper config = new ConfigHelper();

            Console.WriteLine("Getting Config parameters..");
            //LogHelper.sb.sb.AppendLine("Getting Config parameters..");
            config.configParams = getConfigParams(xDoc);
            Console.WriteLine("Getting Config parameters Done.");
            //LogHelper.sb.sb.AppendLine("Getting Config parameters Done.");

            //config.IdeaColumns = getColumns(xDoc,"IdeaColumns");
            //config.ProjectColumns = getColumns(xDoc, "ProjectColumns");

            return config;
        }


    }
}
