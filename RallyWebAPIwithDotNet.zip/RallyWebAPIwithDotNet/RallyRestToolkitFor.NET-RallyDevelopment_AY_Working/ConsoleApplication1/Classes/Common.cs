﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Data;
using System.Text;
using Rally.RestApi;
using Rally.RestApi.Response;
using Rally.RestApi.Json;
using Rally.RestApi.Connection;
using Rally.RestApi.Auth;
using Rally.RestApi.Web;
using System.Threading.Tasks;
using System.Dynamic;

namespace RallyConnector
{
    public class Common
    {
        Request requestedAttribute;

        public QueryResult RequestAQuery(dynamic rallyAttributeName, RallyRestApi restApi, string workSpaceRef)
        {
           
            requestedAttribute = new Request(rallyAttributeName);
                        
            requestedAttribute.Workspace = workSpaceRef;
            QueryResult queryResult = restApi.Query(requestedAttribute);
            return queryResult;
        }



    }
}
